import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Rumble Auto-Uploader - Anime RSS to Rumble",
  description: "Automatically download anime torrents from Nyaa.si and upload to Rumble.com with all subtitles.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-100 text-slate-900 antialiased">{children}</body>
    </html>
  );
}
