import { NextResponse } from 'next/server';
import { db } from '@/db';
import { uploads, platformUploads } from '@/db/schema';
import { and, eq } from 'drizzle-orm';
import { extractStreamUrl } from '@/lib/rumble';

/**
 * GET /api/streams?id=123          -> by upload id
 * GET /api/streams?video_id=abc    -> by rumble video id
 * GET /api/streams?url=...         -> by rumble page url (returns direct HLS)
 * GET /api/streams?refresh=1       -> force-refresh stream URL
 *
 * Returns JSON { stream_url, rumble_url, embed_url, thumbnail, title, ... }
 */
export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const id = searchParams.get('id');
  const videoId = searchParams.get('video_id');
  const url = searchParams.get('url');
  const refresh = searchParams.get('refresh') === '1';

  let upload = null;
  if (id) {
    const uid = Number(id);
    [upload] = await db.select().from(uploads).where(eq(uploads.id, uid)).limit(1);
  } else if (videoId) {
    [upload] = await db
      .select()
      .from(uploads)
      .where(eq(uploads.rumbleVideoId, videoId))
      .limit(1);
  }

  let streamUrl: string | null = upload?.rumbleStreamUrl || null;
  let rumbleUrl = upload?.rumbleUrl || null;
  const rumbleEmbedUrl = upload?.rumbleEmbedUrl || null;
  const thumbnail = upload?.rumbleThumbnail || null;
  const title = upload?.title || null;

  if ((!streamUrl || refresh) && (url || rumbleUrl)) {
    streamUrl = await extractStreamUrl(url || rumbleUrl || '');
    if (streamUrl && upload) {
      await db
        .update(uploads)
        .set({ rumbleStreamUrl: streamUrl, updatedAt: new Date() })
        .where(eq(uploads.id, upload.id));
    }
  }

  if (!streamUrl && url) {
    streamUrl = await extractStreamUrl(url);
  }

  // Copies of this episode on other platforms.
  const mirrors = upload?.feedItemId
    ? (
        await db
          .select()
          .from(platformUploads)
          .where(and(eq(platformUploads.feedItemId, upload.feedItemId), eq(platformUploads.status, 'done')))
      )
    : [];
  const { playerUrlWithSubs } = await import('@/lib/providers');
  const { publicBaseUrl, getSubtitleTracks } = await import('@/lib/subtitle-store');
  const base = publicBaseUrl(req);
  const mirrorList = await Promise.all(
    mirrors.map(async (m) => ({
      platform: m.platform,
      url: m.url,
      embed_url: await playerUrlWithSubs(m, base),
      subtitles: m.subtitleStatus,
    }))
  );
  const subtitleFiles =
    upload?.feedItemId && base
      ? (await getSubtitleTracks(upload.feedItemId)).map((t) => ({ lang: t.lang, label: t.label, vtt: `${base}/api/subs/${t.id}.vtt`, srt: `${base}/api/subs/${t.id}.srt` }))
      : [];

  return NextResponse.json({
    mirrors: mirrorList,
    subtitle_files: subtitleFiles,
    id: upload?.id ?? null,
    video_id: upload?.rumbleVideoId ?? videoId ?? null,
    title,
    rumble_url: rumbleUrl || url || null,
    embed_url: rumbleEmbedUrl,
    thumbnail,
    stream_url: streamUrl,
    hls_url: streamUrl,
    m3u8_url: streamUrl,
    status: upload?.status ?? streamUrl ? 'live' : 'unknown',
    subtitles: upload?.subtitlesUploaded ?? [],
  });
}
