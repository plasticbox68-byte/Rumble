import { NextResponse } from 'next/server';
import { getConfig, setConfig } from '@/lib/config';
import { notifyConfigChanged } from '@/lib/scheduler';

export async function GET() {
  const cfg = await getConfig();
  return NextResponse.json(cfg);
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const updated = await setConfig(body);
  // Kick off an immediate cycle and re-arm the timer in the background.
  notifyConfigChanged().catch((e) => console.error('Failed to notify scheduler:', e));
  return NextResponse.json(updated);
}
