import { db } from '@/db';
import { subtitleTracks } from '@/db/schema';
import { eq } from 'drizzle-orm';

// GET /api/subs/12.vtt or /api/subs/12.srt — public subtitle files for external players.
export async function GET(_req: Request, { params }: { params: Promise<{ file: string }> }) {
  const { file } = await params;
  const m = file.match(/^(\d+)\.(vtt|srt)$/);
  if (!m) return new Response('Not found', { status: 404 });
  const [track] = await db.select().from(subtitleTracks).where(eq(subtitleTracks.id, Number(m[1]))).limit(1);
  if (!track) return new Response('Not found', { status: 404 });
  const isVtt = m[2] === 'vtt';
  return new Response(isVtt ? track.vtt : track.srt, {
    headers: {
      'Content-Type': isVtt ? 'text/vtt; charset=utf-8' : 'application/x-subrip; charset=utf-8',
      'Access-Control-Allow-Origin': '*',
      'Cache-Control': 'public, max-age=86400',
      'Content-Disposition': `inline; filename="${track.label}.${track.lang}.${m[2]}"`,
    },
  });
}
