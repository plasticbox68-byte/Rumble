import { NextResponse } from 'next/server';
import { db } from '@/db';
import { downloads } from '@/db/schema';
import { desc, eq } from 'drizzle-orm';

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const feedItemId = searchParams.get('feedItemId');
  const base = db.select().from(downloads);
  const rows = feedItemId
    ? await base.where(eq(downloads.feedItemId, Number(feedItemId)))
    : await base.orderBy(desc(downloads.id)).limit(100);
  return NextResponse.json({ downloads: rows });
}
