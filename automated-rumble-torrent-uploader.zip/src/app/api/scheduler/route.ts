import { NextResponse } from 'next/server';
import { getStatus, runCycle } from '@/lib/scheduler';

export async function GET() {
  try {
    const status = await getStatus();
    return NextResponse.json(status);
  } catch (e) {
    return NextResponse.json(
      { error: (e as Error).message },
      { status: 500 }
    );
  }
}

export async function POST() {
  try {
    const result = await runCycle();
    const status = await getStatus();
    return NextResponse.json({ ok: true, result, status });
  } catch (e) {
    return NextResponse.json(
      { ok: false, error: (e as Error).message },
      { status: 500 }
    );
  }
}
