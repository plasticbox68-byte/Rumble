import { NextResponse } from 'next/server';
import { getConfig } from '@/lib/config';
import path from 'path';

export async function POST(req: Request) {
  try {
    // Playwright reads this at import time; set it before importing the browser module.
    process.env.PLAYWRIGHT_BROWSERS_PATH = path.join(process.cwd(), '.playwright-browsers');
    const body = await req.json().catch(() => ({}));
    const cfg = await getConfig();

    const email = body.email !== undefined ? body.email : cfg.rumbleEmail;
    const password = body.password !== undefined ? body.password : cfg.rumblePassword;
    const cookies = body.cookies !== undefined ? body.cookies : cfg.rumbleSessionCookies;

    const { testRumbleLogin } = await import('@/lib/rumble-browser');
    const result = await testRumbleLogin({ email, password, cookies });
    return NextResponse.json(result);
  } catch (e) {
    return NextResponse.json(
      { ok: false, message: (e as Error).message },
      { status: 500 }
    );
  }
}
