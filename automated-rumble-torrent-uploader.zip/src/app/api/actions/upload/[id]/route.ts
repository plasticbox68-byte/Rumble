import { NextResponse } from 'next/server';
import { processItemUpload } from '@/lib/pipeline';

export async function POST(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const feedItemId = Number(id);
  if (!Number.isFinite(feedItemId)) {
    return NextResponse.json({ error: 'Invalid id' }, { status: 400 });
  }
  try {
    const result = await processItemUpload(feedItemId);
    return NextResponse.json({
      success: true,
      upload_id: result.uploadId,
      rumble_url: result.rumbleUrl,
      stream_url: result.streamUrl,
    });
  } catch (e) {
    return NextResponse.json(
      { success: false, error: (e as Error).message },
      { status: 500 }
    );
  }
}
