import { NextResponse } from 'next/server';
import { runCycle, getStatus } from '@/lib/scheduler';

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  // Manual trigger: always runs a poll; only processes backlog if requested (default true).
  // runCycle() itself respects the autoDownload/autoUpload settings when processing the backlog.
  // To force processing regardless of auto flags, we'll run a cycle and then optionally run the
  // backlog with download/upload forced on.
  const forceProcess = body.forceProcess === true;
  const result = await runCycle();
  if (forceProcess) {
    const { processBacklog } = await import('@/lib/pipeline');
    const extra = await processBacklog({ download: true, upload: true });
    result.downloaded += extra.downloaded;
    result.uploaded += extra.uploaded;
    result.errors.push(...extra.errors);
  }
  const status = await getStatus();
  return NextResponse.json({ ok: true, result, status });
}
