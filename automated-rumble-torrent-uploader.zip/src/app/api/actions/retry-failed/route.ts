import { NextResponse } from 'next/server';
import { retryFailedUploads } from '@/lib/pipeline';

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const limit = Math.max(1, Math.min(200, Number(body.limit) || 50));
  try {
    const result = await retryFailedUploads(limit, body.feedItemId ? Number(body.feedItemId) : undefined);
    return NextResponse.json({ ok: true, ...result });
  } catch (e) {
    return NextResponse.json({ ok: false, error: (e as Error).message }, { status: 500 });
  }
}
