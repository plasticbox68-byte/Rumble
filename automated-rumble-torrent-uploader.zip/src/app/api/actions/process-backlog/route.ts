import { NextResponse } from 'next/server';
import { processBacklog } from '@/lib/pipeline';

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const result = await processBacklog({
    download: body.download !== false,
    upload: body.upload !== false,
    force: !!body.force,
  });
  return NextResponse.json(result);
}
