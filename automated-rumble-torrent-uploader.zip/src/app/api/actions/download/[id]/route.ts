import { NextResponse } from 'next/server';
import { processItemDownload, processItemUpload } from '@/lib/pipeline';
import { getConfig, isRumbleConfigured } from '@/lib/config';

export async function POST(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const feedItemId = Number(id);
  if (!Number.isFinite(feedItemId)) {
    return NextResponse.json({ error: 'Invalid id' }, { status: 400 });
  }
  try {
    const result = await processItemDownload(feedItemId);

    // "Download → upload" chain: if auto-upload is on, publish immediately.
    const cfg = await getConfig();
    let upload: { uploadId: number; rumbleUrl: string | null; streamUrl: string | null } | null = null;
    let uploadError: string | null = null;
    if (cfg.autoUpload && isRumbleConfigured(cfg)) {
      try {
        upload = await processItemUpload(feedItemId);
      } catch (e) {
        uploadError = (e as Error).message;
      }
    }

    return NextResponse.json({ success: true, ...result, upload, uploadError });
  } catch (e) {
    return NextResponse.json(
      { success: false, error: (e as Error).message },
      { status: 500 }
    );
  }
}
