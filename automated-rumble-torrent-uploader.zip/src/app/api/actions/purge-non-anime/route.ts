import { NextResponse } from 'next/server';
import { purgeNonAnimeItems } from '@/lib/pipeline';
import { log } from '@/lib/scheduler';

export async function POST() {
  const result = await purgeNonAnimeItems();
  await log('info', `Source cleanup: removed ${result.deleted} donghua/untrusted item(s) from the queue.`);
  return NextResponse.json({ ok: true, ...result });
}
