import { NextResponse } from 'next/server';
import { discoverPopularCatalog } from '@/lib/catalog';
import { log } from '@/lib/scheduler';

// Bulk discovery can take many minutes (one AniList page + one Nyaa search per
// title). Start it in the background and report progress via /api/scheduler logs.
let running = false;

export async function POST() {
  if (running) {
    return NextResponse.json({ ok: false, message: 'A bulk discovery job is already running.' }, { status: 409 });
  }
  running = true;
  void discoverPopularCatalog()
    .then((res) => log('info', `Bulk discovery finished: ${JSON.stringify(res)}`))
    .catch((e) => log('error', `Bulk discovery failed: ${(e as Error).message}`))
    .finally(() => {
      running = false;
    });
  return NextResponse.json({ ok: true, message: 'Bulk discovery started in the background. Watch the activity log.' });
}

export async function GET() {
  return NextResponse.json({ running });
}
