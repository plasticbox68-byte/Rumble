import { NextResponse } from 'next/server';
import { db } from '@/db';
import { feedItems } from '@/db/schema';
import { desc, count, eq } from 'drizzle-orm';
import { pollFeed } from '@/lib/pipeline';

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const limit = Math.min(Number(searchParams.get('limit') || 50), 200);
  const offset = Number(searchParams.get('offset') || 0);
  const status = searchParams.get('status');

  const base = db.select().from(feedItems);
  const filtered = status ? base.where(eq(feedItems.status, status)) : base;

  const items = await filtered
    .orderBy(desc(feedItems.pubDate), desc(feedItems.id))
    .limit(limit)
    .offset(offset);

  const totalQ = await db.select({ c: count() }).from(feedItems);
  return NextResponse.json({ items, total: Number(totalQ[0].c), limit, offset });
}

export async function POST() {
  const result = await pollFeed();
  return NextResponse.json(result);
}
