import { NextResponse } from 'next/server';
import { db } from '@/db';
import { uploads, feedItems } from '@/db/schema';
import { desc, eq } from 'drizzle-orm';
import { extractStreamUrl } from '@/lib/rumble';

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const id = searchParams.get('id');
  const refresh = searchParams.get('refresh') === '1';

  if (id) {
    const uploadId = Number(id);
    let [u] = await db.select().from(uploads).where(eq(uploads.id, uploadId)).limit(1);
    if (!u) return NextResponse.json({ error: 'Not found' }, { status: 404 });

    // If we don't have a stream URL yet but have a rumble URL, try to refresh
    if ((!u.rumbleStreamUrl || refresh) && u.rumbleUrl) {
      const streamUrl = await extractStreamUrl(u.rumbleUrl);
      if (streamUrl) {
        await db
          .update(uploads)
          .set({ rumbleStreamUrl: streamUrl, updatedAt: new Date() })
          .where(eq(uploads.id, uploadId));
        u = (await db.select().from(uploads).where(eq(uploads.id, uploadId)).limit(1))[0] || u;
      }
    }

    return NextResponse.json(u);
  }

  const rows = await db
    .select({
      id: uploads.id,
      title: uploads.title,
      status: uploads.status,
      progress: uploads.progress,
      rumbleUrl: uploads.rumbleUrl,
      rumbleStreamUrl: uploads.rumbleStreamUrl,
      rumbleThumbnail: uploads.rumbleThumbnail,
      rumbleVideoId: uploads.rumbleVideoId,
      errorMessage: uploads.errorMessage,
      createdAt: uploads.createdAt,
      updatedAt: uploads.updatedAt,
      feedItemId: uploads.feedItemId,
      feedItemTitle: feedItems.title,
    })
    .from(uploads)
    .leftJoin(feedItems, eq(feedItems.id, uploads.feedItemId))
    .orderBy(desc(uploads.id))
    .limit(100);

  return NextResponse.json({ uploads: rows });
}
