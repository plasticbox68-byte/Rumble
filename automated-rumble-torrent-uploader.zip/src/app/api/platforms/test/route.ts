import { NextResponse } from 'next/server';
import { getProvider } from '@/lib/providers';
import { getPlatformsConfig, type PlatformCreds } from '@/lib/providers/core';

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { platform?: string; creds?: PlatformCreds };
  const provider = body.platform ? getProvider(body.platform) : undefined;
  if (!provider) return NextResponse.json({ ok: false, message: 'Unknown platform' }, { status: 400 });
  const creds = body.creds || (await getPlatformsConfig())[provider.id] || {};
  try {
    const message = await provider.test(creds);
    return NextResponse.json({ ok: true, message });
  } catch (e) {
    return NextResponse.json({ ok: false, message: (e as Error).message });
  }
}
