import { NextResponse } from 'next/server';
import { db } from '@/db';
import { platformUploads } from '@/db/schema';
import { desc } from 'drizzle-orm';
import { providerCatalog, playerUrlWithSubs } from '@/lib/providers';
import { publicBaseUrl } from '@/lib/subtitle-store';
import { getPlatformsConfig, savePlatformsConfig, type PlatformsConfig } from '@/lib/providers/core';

export async function GET(req: Request) {
  const [config, rows] = await Promise.all([
    getPlatformsConfig(),
    db.select().from(platformUploads).orderBy(desc(platformUploads.id)).limit(100),
  ]);
  const base = publicBaseUrl(req);
  const recent = await Promise.all(rows.map(async (r) => ({ ...r, playerUrl: await playerUrlWithSubs(r, base) })));
  return NextResponse.json({ providers: providerCatalog(), config, recent });
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as PlatformsConfig;
  const known = new Set(providerCatalog().map((p) => p.id));
  const clean: PlatformsConfig = {};
  for (const [id, creds] of Object.entries(body || {})) {
    if (!known.has(id) || !creds || typeof creds !== 'object') continue;
    clean[id] = Object.fromEntries(Object.entries(creds).map(([k, v]) => [k, String(v ?? '')]));
  }
  const saved = await savePlatformsConfig(clean);
  return NextResponse.json({ ok: true, config: saved });
}
