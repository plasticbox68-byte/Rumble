import { NextResponse } from 'next/server';
import { retryFailedMirrors } from '@/lib/providers';

export async function POST() {
  try {
    const result = await retryFailedMirrors(20);
    return NextResponse.json({ ok: true, ...result });
  } catch (e) {
    return NextResponse.json({ ok: false, error: (e as Error).message }, { status: 500 });
  }
}
