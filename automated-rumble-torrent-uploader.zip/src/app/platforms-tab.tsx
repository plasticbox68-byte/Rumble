'use client';

import { useCallback, useEffect, useState } from 'react';

type FieldDef = { key: string; label: string; type?: 'text' | 'password' | 'textarea'; placeholder?: string; help?: string; required?: boolean };
type ProviderInfo = {
  id: string;
  name: string;
  site: string;
  mode: 'api' | 'browser';
  experimental: boolean;
  setup: string;
  difficulty: 'easy' | 'medium' | 'hard';
  steps: string[];
  subtitleSupport: 'upload' | 'deferred' | 'embed' | 'hardsub';
  fields: FieldDef[];
};
type Creds = Record<string, string>;
type MirrorRow = {
  id: number;
  feedItemId: number | null;
  platform: string;
  title: string | null;
  status: string;
  url: string | null;
  embedUrl: string | null;
  playerUrl?: string | null;
  subtitleStatus?: string;
  subtitleNote?: string | null;
  errorMessage: string | null;
  updatedAt: string;
};

const DIFFICULTY: Record<string, { label: string; cls: string; rank: number }> = {
  easy: { label: 'EASY · cookies or 1 key', cls: 'bg-emerald-100 text-emerald-800', rank: 0 },
  medium: { label: 'MEDIUM · ~5 min', cls: 'bg-amber-100 text-amber-800', rank: 1 },
  hard: { label: 'HARD · needs approval (days)', cls: 'bg-red-100 text-red-800', rank: 2 },
};

/** Render a step, turning URLs and emails into links. */
function StepText({ text }: { text: string }) {
  const parts = text.split(/(https?:\/\/[^\s,)]+|[\w.+-]+@[\w-]+\.[\w.]+)/g);
  return (
    <>
      {parts.map((part, i) =>
        /^https?:\/\//.test(part) ? (
          <a key={i} href={part} target="_blank" rel="noreferrer" className="text-blue-700 underline break-all">{part}</a>
        ) : /@/.test(part) && /^[\w.+-]+@/.test(part) ? (
          <a key={i} href={`mailto:${part}`} className="text-blue-700 underline">{part}</a>
        ) : (
          <span key={i}>{part}</span>
        )
      )}
    </>
  );
}

const SUB_SUPPORT: Record<string, string> = {
  upload: 'Subtitles: all languages uploaded as caption tracks',
  deferred: 'Subtitles: all languages, added once the platform finishes processing',
  embed: 'Subtitles: all languages, loaded by the player from this app',
  hardsub: 'No caption tracks on this site — the English hard-sub video is uploaded instead',
};

const STATUS_STYLE: Record<string, string> = {
  done: 'bg-emerald-100 text-emerald-800',
  uploading: 'bg-orange-100 text-orange-800',
  error: 'bg-red-100 text-red-800',
  pending: 'bg-slate-100 text-slate-700',
};

export default function PlatformsTab() {
  const [providers, setProviders] = useState<ProviderInfo[]>([]);
  const [config, setConfig] = useState<Record<string, Creds>>({});
  const [recent, setRecent] = useState<MirrorRow[]>([]);
  const [open, setOpen] = useState<string | null>(null);
  const [tests, setTests] = useState<Record<string, { ok: boolean; message: string } | 'running'>>({});
  const [notice, setNotice] = useState<{ ok: boolean; text: string } | null>(null);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async (withConfig: boolean) => {
    const data = await fetch('/api/platforms').then((r) => r.json());
    setProviders(data.providers || []);
    setRecent(data.recent || []);
    if (withConfig) setConfig(data.config || {});
  }, []);

  useEffect(() => {
    load(true);
    // Refresh the upload list only — never overwrite credentials being edited.
    const t = setInterval(() => load(false), 10_000);
    return () => clearInterval(t);
  }, [load]);

  const flash = (ok: boolean, text: string) => {
    setNotice({ ok, text });
    setTimeout(() => setNotice(null), 5000);
  };

  const setField = (id: string, key: string, value: string) =>
    setConfig((c) => ({ ...c, [id]: { ...(c[id] || {}), [key]: value } }));

  const save = async (next = config) => {
    setSaving(true);
    try {
      const res = await fetch('/api/platforms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(next),
      }).then((r) => r.json());
      setConfig(res.config || next);
      flash(true, 'Platform settings saved.');
    } catch (e) {
      flash(false, (e as Error).message);
    } finally {
      setSaving(false);
    }
  };

  const toggle = (id: string, enabled: boolean) => {
    const next = { ...config, [id]: { ...(config[id] || {}), enabled: String(enabled) } };
    setConfig(next);
    save(next);
  };

  const test = async (id: string) => {
    setTests((t) => ({ ...t, [id]: 'running' }));
    const res = await fetch('/api/platforms/test', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ platform: id, creds: config[id] || {} }),
    })
      .then((r) => r.json())
      .catch((e) => ({ ok: false, message: (e as Error).message }));
    setTests((t) => ({ ...t, [id]: res }));
  };

  const retry = async () => {
    const res = await fetch('/api/platforms/retry', { method: 'POST' }).then((r) => r.json());
    flash(!!res.ok, res.ok ? `Retried ${res.retried} upload(s).${res.skipped?.length ? ` ${res.skipped[0]}` : ''}` : res.error);
    load(false);
  };

  const enabledCount = providers.filter((p) => config[p.id]?.enabled === 'true').length;

  return (
    <div className="space-y-4">
      <div className="bg-white rounded shadow-sm p-4 border border-slate-200">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h2 className="text-lg font-semibold">Extra Upload Platforms</h2>
            <p className="text-xs text-slate-600 mt-1 max-w-2xl">
              After each successful Rumble upload, the same verified 1080p/720p file is uploaded to every enabled platform below, one at a time.
              A failure on one platform never affects the others. If any platform fails, the local file is kept so you can retry.
            </p>
          </div>
          <div className="flex gap-2">
            <span className="text-xs bg-slate-100 text-slate-700 px-2.5 py-1.5 rounded font-medium">{enabledCount} enabled</span>
            <button onClick={retry} className="bg-red-600 hover:bg-red-700 text-white px-3 py-1.5 rounded text-xs font-semibold">
              🔁 Retry failed platform uploads
            </button>
          </div>
        </div>
        {notice && (
          <div className={`mt-3 text-xs px-3 py-2 rounded border ${notice.ok ? 'bg-emerald-50 border-emerald-300 text-emerald-900' : 'bg-red-50 border-red-300 text-red-900'}`}>
            {notice.text}
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
        {[...providers].sort((a, b) => (DIFFICULTY[a.difficulty]?.rank ?? 9) - (DIFFICULTY[b.difficulty]?.rank ?? 9)).map((p) => {
          const creds = config[p.id] || {};
          const enabled = creds.enabled === 'true';
          const t = tests[p.id];
          const isOpen = open === p.id;
          return (
            <div key={p.id} className={`bg-white rounded shadow-sm border-2 ${enabled ? 'border-emerald-500' : 'border-slate-200'}`}>
              <div className="p-3.5 flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <a href={p.site} target="_blank" rel="noreferrer" className="font-bold text-sm hover:underline">{p.name}</a>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${p.mode === 'api' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'}`}>
                      {p.mode === 'api' ? 'API' : 'BROWSER'}
                    </span>
                    {DIFFICULTY[p.difficulty] && (
                      <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${DIFFICULTY[p.difficulty].cls}`}>{DIFFICULTY[p.difficulty].label}</span>
                    )}
                    {p.experimental && <span className="text-[10px] px-1.5 py-0.5 rounded font-bold bg-slate-200 text-slate-700">EXPERIMENTAL</span>}
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1">{p.setup}</p>
                  <p className="text-[11px] text-indigo-700 mt-0.5">💬 {SUB_SUPPORT[p.subtitleSupport]}</p>
                </div>
                <label className="flex items-center gap-1.5 text-xs font-medium cursor-pointer select-none flex-shrink-0">
                  <input type="checkbox" className="w-4 h-4" checked={enabled} onChange={(e) => toggle(p.id, e.target.checked)} />
                  {enabled ? 'On' : 'Off'}
                </label>
              </div>

              <div className="px-3.5 pb-3.5">
                <button onClick={() => setOpen(isOpen ? null : p.id)} className="text-xs text-blue-700 font-medium hover:underline">
                  {isOpen ? '▾ Hide setup' : '▸ How to set it up'}
                </button>
                {isOpen && (
                  <div className="mt-2 space-y-2">
                    <ol className="list-decimal list-outside ml-4 space-y-1 text-[11px] text-slate-700 bg-slate-50 border border-slate-200 rounded p-2.5 pl-6">
                      {p.steps.map((step, i) => (
                        <li key={i}><StepText text={step} /></li>
                      ))}
                    </ol>
                    {p.fields.map((f) => (
                      <div key={f.key}>
                        <label className="block text-[11px] font-medium text-slate-700 mb-0.5">
                          {f.label} {f.required && <span className="text-red-600">*</span>}
                        </label>
                        {f.type === 'textarea' ? (
                          <textarea
                            rows={3}
                            value={creds[f.key] || ''}
                            onChange={(e) => setField(p.id, f.key, e.target.value)}
                            placeholder={f.placeholder}
                            className="w-full px-2.5 py-1.5 border border-slate-300 rounded text-xs font-mono bg-white"
                          />
                        ) : (
                          <input
                            type={f.type === 'password' ? 'password' : 'text'}
                            value={creds[f.key] || ''}
                            onChange={(e) => setField(p.id, f.key, e.target.value)}
                            placeholder={f.placeholder}
                            autoComplete="off"
                            className="w-full px-2.5 py-1.5 border border-slate-300 rounded text-xs bg-white"
                          />
                        )}
                        {f.help && <p className="text-[10px] text-slate-500 mt-0.5">{f.help}</p>}
                      </div>
                    ))}
                    <div className="flex flex-wrap items-center gap-2 pt-1">
                      <button
                        onClick={() => save()}
                        disabled={saving}
                        className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white px-3 py-1 rounded text-xs font-semibold"
                      >
                        💾 Save
                      </button>
                      <button
                        onClick={() => test(p.id)}
                        disabled={t === 'running'}
                        className="bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white px-3 py-1 rounded text-xs font-semibold"
                      >
                        {t === 'running' ? '⏳ Testing...' : '🧪 Test connection'}
                      </button>
                      {t && t !== 'running' && (
                        <span className={`text-[11px] px-2 py-0.5 rounded border ${t.ok ? 'bg-emerald-50 border-emerald-300 text-emerald-800' : 'bg-red-50 border-red-300 text-red-800'}`}>
                          {t.ok ? '✅' : '❌'} {t.message}
                        </span>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      <div className="bg-white rounded shadow-sm p-4 border border-slate-200">
        <h3 className="font-semibold text-sm mb-2">Recent platform uploads</h3>
        {recent.length === 0 ? (
          <div className="text-xs text-slate-500">None yet. Enable a platform above; the next Rumble upload will also go there.</div>
        ) : (
          <div className="space-y-1.5 max-h-[480px] overflow-y-auto">
            {recent.map((r) => {
              const name = providers.find((p) => p.id === r.platform)?.name || r.platform;
              return (
                <div key={r.id} className="flex flex-wrap items-center gap-2 text-xs border border-slate-100 rounded px-2 py-1.5">
                  <span className={`px-1.5 py-0.5 rounded font-medium ${STATUS_STYLE[r.status] || STATUS_STYLE.pending}`}>{r.status}</span>
                  <span className="font-semibold w-24 flex-shrink-0">{name}</span>
                  <span className="truncate flex-1 min-w-0 text-slate-700" title={r.title || ''}>{r.title}</span>
                  {r.status === 'done' && r.subtitleStatus && r.subtitleStatus !== 'none' && (
                    <span
                      title={r.subtitleNote || ''}
                      className={`px-1.5 py-0.5 rounded text-[10px] font-semibold flex-shrink-0 ${
                        r.subtitleStatus === 'done' ? 'bg-indigo-100 text-indigo-800' : r.subtitleStatus === 'pending' || r.subtitleStatus === 'partial' ? 'bg-amber-100 text-amber-800' : 'bg-red-100 text-red-800'
                      }`}
                    >
                      subs: {r.subtitleStatus}
                    </span>
                  )}
                  {(r.playerUrl || r.url) && (
                    <a href={r.playerUrl || r.url || '#'} target="_blank" rel="noreferrer" className="text-blue-700 hover:underline flex-shrink-0">open ↗</a>
                  )}
                  {r.status === 'done' && r.subtitleNote && <div className="basis-full text-[11px] text-indigo-700">{r.subtitleNote}</div>}
                  {r.errorMessage && (
                    <div className={`basis-full text-[11px] ${r.status === 'error' ? 'text-red-600' : 'text-slate-500'}`}>{r.errorMessage}</div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
