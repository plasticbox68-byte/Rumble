'use client';

import { useEffect, useState, useCallback } from 'react';
import PlatformsTab from './platforms-tab';

type Config = {
  rumbleUploadMode: 'none' | 'api' | 'browser';
  rumbleAccessToken: string;
  rumbleChannelId: string;
  rumbleEmail: string;
  rumblePassword: string;
  rumbleSessionCookies: string;
  rumblePrimaryCategory: string;
  rumbleDefaultTitleTemplate: string;
  rumbleLicenseType: number;
  rssUrl: string;
  rssPollIntervalMinutes: number;
  rssFilterResolution: string;
  rssFilterFansub: string;
  rssFilterKeywords: string;
  rssMinSeeders: number;
  rssMaxSizeGb: number;
  enforceResolution: boolean;
  minVideoHeight: number;
  excludeDonghua: boolean;
  trustedGroupsOnly: boolean;
  trustedGroups: string;
  bulkMaxAnime: number;
  bulkEpisodesPerAnime: number;
  bulkAudioMode: 'sub' | 'dub' | 'both' | 'multi';
  bulkMinSeeders: number;
  bulkSoftSub: boolean;
  bulkHardSub: boolean;
  bulkHardSubLangs: string;
  autoDownload: boolean;
  autoUpload: boolean;
};

type FeedItem = {
  id: number;
  title: string;
  link: string | null;
  guid: string;
  pubDate: string | null;
  seeders: number | null;
  leechers: number | null;
  fileSize: string | null;
  resolution: string | null;
  fansubGroup: string | null;
  episodeNumber: string | null;
  category: string | null;
  status: string;
  errorMessage: string | null;
  infoHash: string | null;
};

type Download = {
  id: number;
  feedItemId: number;
  name: string;
  progress: number | null;
  status: string;
  totalSize: number | null;
  downloaded: number | null;
  videoPath: string | null;
  subtitles: { lang: string; path: string; codec?: string }[] | null;
  createdAt: string;
  updatedAt: string;
};

type Upload = {
  id: number;
  title: string;
  status: string;
  progress: number | null;
  rumbleUrl: string | null;
  rumbleStreamUrl: string | null;
  rumbleThumbnail: string | null;
  rumbleVideoId: string | null;
  rumbleEmbedUrl: string | null;
  errorMessage: string | null;
  subtitlesUploaded: { lang: string; filename: string }[] | null;
  feedItemId: number | null;
  feedItemTitle?: string | null;
  createdAt: string;
  updatedAt: string;
};

type SchedulerLog = { id: number; level: string; message: string; created_at: string };
type SchedulerStatus = {
  running: boolean;
  last_poll_at: string | null;
  last_poll_fetched: number;
  last_poll_new: number;
  last_downloaded: number;
  last_uploaded: number;
  last_error: string | null;
  last_run_ms: number;
  next_run_at: string | null;
  poll_interval_minutes: number;
  auto_download: boolean;
  auto_upload: boolean;
  upload_mode: string;
  recent_logs: SchedulerLog[];
};

const DEFAULT_CFG: Config = {
  rumbleUploadMode: 'none',
  rumbleAccessToken: '',
  rumbleChannelId: '',
  rumbleEmail: '',
  rumblePassword: '',
  rumbleSessionCookies: '',
  rumblePrimaryCategory: 'Entertainment',
  rumbleDefaultTitleTemplate: '{title}',
  rumbleLicenseType: 0,
  rssUrl: 'https://nyaa.si/?page=rss',
  rssPollIntervalMinutes: 30,
  rssFilterResolution: '1080p',
  rssFilterFansub: '',
  rssFilterKeywords: '',
  rssMinSeeders: 0,
  rssMaxSizeGb: 3,
  enforceResolution: true,
  minVideoHeight: 720,
  excludeDonghua: true,
  trustedGroupsOnly: true,
  trustedGroups: 'SubsPlease,Erai-raws,GJM,Commie,ASW,AkihitoSubs,Judas,EMBER,Coalgirls,MTBB,Anime Time,Breeze,DKB,Valenciano,Sokudo,Trix,NeoHEVC,Cleo,Reinforce,AnimeRG,HorribleSubs,ToonsHub',
  bulkMaxAnime: 25,
  bulkEpisodesPerAnime: 1,
  bulkAudioMode: 'sub',
  bulkMinSeeders: 1,
  bulkSoftSub: true,
  bulkHardSub: false,
  bulkHardSubLangs: 'en',
  autoDownload: false,
  autoUpload: false,
};

function cookieCount(raw: string): number {
  const t = raw.trim();
  if (!t) return 0;
  try {
    const parsed = JSON.parse(t);
    if (Array.isArray(parsed)) return parsed.length;
  } catch {
    /* not JSON */
  }
  return t.split(';').filter((p) => p.includes('=')).length;
}

function formatSize(n?: number | null): string {
  if (!n) return '-';
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  if (n < 1024 * 1024 * 1024) return `${(n / 1024 / 1024).toFixed(1)} MB`;
  return `${(n / 1024 / 1024 / 1024).toFixed(2)} GB`;
}

function statusColor(s: string): string {
  switch (s) {
    case 'discovered':
      return 'bg-blue-100 text-blue-800';
    case 'downloading':
      return 'bg-yellow-100 text-yellow-800';
    case 'downloaded':
      return 'bg-indigo-100 text-indigo-800';
    case 'uploading':
      return 'bg-orange-100 text-orange-800';
    case 'uploaded':
    case 'processing':
      return 'bg-purple-100 text-purple-800';
    case 'live':
      return 'bg-green-100 text-green-800';
    case 'done':
      return 'bg-green-100 text-green-800';
    case 'error':
      return 'bg-red-100 text-red-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
}

function Stat({ label, value, color }: { label: string; value: number | string; color: string }) {
  const colorMap: Record<string, string> = {
    blue: 'border-blue-200 bg-blue-50 text-blue-900',
    yellow: 'border-yellow-200 bg-yellow-50 text-yellow-900',
    emerald: 'border-emerald-200 bg-emerald-50 text-emerald-900',
    purple: 'border-purple-200 bg-purple-50 text-purple-900',
  };
  return (
    <div className={`rounded border p-3 ${colorMap[color] || 'border-slate-200 bg-slate-50 text-slate-900'}`}>
      <div className="text-[11px] uppercase font-semibold opacity-70">{label}</div>
      <div className="text-2xl font-bold">{value}</div>
    </div>
  );
}

export default function Dashboard() {
  const [cfg, setCfg] = useState<Config>(DEFAULT_CFG);
  const [items, setItems] = useState<FeedItem[]>([]);
  const [downloads, setDownloads] = useState<Download[]>([]);
  const [uploads, setUploads] = useState<Upload[]>([]);
  const [scheduler, setScheduler] = useState<SchedulerStatus | null>(null);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'feed' | 'downloads' | 'uploads' | 'streams' | 'bulk' | 'platforms' | 'settings'>('dashboard');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'ok' | 'error'; text: string } | null>(null);

  // Sign-in testing state
  const [testingLogin, setTestingLogin] = useState(false);
  const [testLoginResult, setTestLoginResult] = useState<{ ok: boolean; message: string; username?: string } | null>(null);

  // Browser sign-in sub-mode: cookies vs credentials
  const [authSubMode, setAuthSubMode] = useState<'cookies' | 'credentials'>('cookies');

  // Load operational data (feed, downloads, uploads, scheduler status).
  // CRITICAL: NEVER overwrite `cfg` in this background ticker!
  const loadOperationalData = useCallback(async () => {
    try {
      const [feedRes, dlRes, upRes, schedRes] = await Promise.all([
        fetch('/api/feed?limit=50').then((r) => r.json()),
        fetch('/api/downloads').then((r) => r.json()),
        fetch('/api/uploads').then((r) => r.json()),
        fetch('/api/scheduler').then((r) => r.json()),
      ]);
      setItems(feedRes.items || []);
      setDownloads(dlRes.downloads || []);
      setUploads(upRes.uploads || []);
      setScheduler(schedRes);
    } catch (e) {
      console.error('Operational poll error:', e);
    }
  }, []);

  // Fetch config ONCE on initial mount
  useEffect(() => {
    fetch('/api/config')
      .then((r) => r.json())
      .then((data) => {
        setCfg(data);
        if (data.rumbleSessionCookies && data.rumbleSessionCookies.trim()) {
          setAuthSubMode('cookies');
        } else if (data.rumbleEmail) {
          setAuthSubMode('credentials');
        }
      })
      .catch(console.error);

    loadOperationalData();
    const id = setInterval(loadOperationalData, 10_000);
    return () => clearInterval(id);
  }, [loadOperationalData]);

  const saveCfg = async (newCfg: Partial<Config>) => {
    setLoading(true);
    try {
      const res = await fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newCfg),
      });
      const updated = await res.json();
      setCfg(updated);
      setMessage({ type: 'ok', text: 'Settings saved! Background auto-scheduler updated.' });
    } catch (e) {
      setMessage({ type: 'error', text: `Error saving: ${(e as Error).message}` });
    } finally {
      setLoading(false);
      setTimeout(() => setMessage(null), 4000);
    }
  };

  const doTestLogin = async () => {
    setTestingLogin(true);
    setTestLoginResult(null);
    try {
      const res = await fetch('/api/actions/test-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: cfg.rumbleEmail,
          password: cfg.rumblePassword,
          cookies: cfg.rumbleSessionCookies,
        }),
      });
      const data = await res.json();
      setTestLoginResult(data);
    } catch (e) {
      setTestLoginResult({ ok: false, message: `Test failed: ${(e as Error).message}` });
    } finally {
      setTestingLogin(false);
    }
  };

  const doPoll = async () => {
    setLoading(true);
    setMessage({ type: 'ok', text: 'Running an immediate RSS poll and backlog check...' });
    try {
      await fetch('/api/scheduler', { method: 'POST' });
      await loadOperationalData();
    } catch (e) {
      setMessage({ type: 'error', text: `Poll failed: ${(e as Error).message}` });
    } finally {
      setLoading(false);
      setTimeout(() => setMessage(null), 3000);
    }
  };

  const doDownload = async (id: number) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/actions/download/${id}`, { method: 'POST' });
      const data = await res.json();
      if (!data.success) {
        setMessage({ type: 'error', text: `Download #${id} failed: ${data.error}` });
      } else {
        setMessage({ type: 'ok', text: `Download #${id} finished.` });
      }
      await loadOperationalData();
    } catch (e) {
      setMessage({ type: 'error', text: `Download error: ${(e as Error).message}` });
    } finally {
      setLoading(false);
      setTimeout(() => setMessage(null), 3000);
    }
  };

  const doUpload = async (id: number) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/actions/upload/${id}`, { method: 'POST' });
      const data = await res.json();
      if (!data.success) {
        setMessage({ type: 'error', text: `Upload #${id} failed: ${data.error}` });
      } else {
        setMessage({ type: 'ok', text: `Upload #${id} queued / completed!` });
      }
      await loadOperationalData();
    } catch (e) {
      setMessage({ type: 'error', text: `Upload error: ${(e as Error).message}` });
    } finally {
      setLoading(false);
      setTimeout(() => setMessage(null), 4000);
    }
  };

  const processBacklog = async () => {
    setLoading(true);
    setMessage({ type: 'ok', text: 'Processing backlog (downloads + uploads)...' });
    try {
      await fetch('/api/actions/process-backlog', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ download: true, upload: true }),
      });
      await loadOperationalData();
    } catch (e) {
      setMessage({ type: 'error', text: `Backlog error: ${(e as Error).message}` });
    } finally {
      setLoading(false);
      setTimeout(() => setMessage(null), 3000);
    }
  };

  const retryFailed = async (feedItemId?: number) => {
    setLoading(true);
    setMessage({ type: 'ok', text: feedItemId ? `Retrying upload for item #${feedItemId}...` : 'Retrying all failed uploads...' });
    try {
      const res = await fetch('/api/actions/retry-failed', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ limit: 50, feedItemId }),
      });
      const data = await res.json();
      setMessage(data.ok
        ? { type: 'ok', text: `Re-queued ${data.retried} failed upload(s). ${(data.errors || []).length ? data.errors[0] : ''}` }
        : { type: 'error', text: data.error || 'Retry failed' });
      await loadOperationalData();
    } catch (e) {
      setMessage({ type: 'error', text: `Retry error: ${(e as Error).message}` });
    } finally {
      setLoading(false);
      setTimeout(() => setMessage(null), 5000);
    }
  };

  const purgeNonAnime = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/actions/purge-non-anime', { method: 'POST' });
      const data = await res.json();
      setMessage({
        type: 'ok',
        text: `Removed ${data.deleted} donghua/untrusted item(s) from the queue.${data.sample?.length ? ` Example: ${data.sample[0]}` : ''}`,
      });
      await loadOperationalData();
    } catch (e) {
      setMessage({ type: 'error', text: (e as Error).message });
    } finally {
      setLoading(false);
      setTimeout(() => setMessage(null), 6000);
    }
  };

  const startBulkDiscovery = async () => {
    setLoading(true);
    try {
      await saveCfg(cfg);
      const res = await fetch('/api/actions/bulk-discover', { method: 'POST' });
      const data = await res.json();
      setMessage(data.ok ? { type: 'ok', text: data.message } : { type: 'error', text: data.message });
    } catch (e) {
      setMessage({ type: 'error', text: (e as Error).message });
    } finally {
      setLoading(false);
      setTimeout(() => setMessage(null), 5000);
    }
  };

  const getStreamUrl = async (id: number) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/streams?id=${id}&refresh=1`);
      const data = await res.json();
      setMessage({
        type: 'ok',
        text: data.stream_url ? `Stream URL extracted for upload #${id}!` : `No stream URL available yet for #${id}.`,
      });
      await loadOperationalData();
    } finally {
      setLoading(false);
      setTimeout(() => setMessage(null), 3000);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <header className="bg-slate-900 text-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 py-4 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">🎬 Rumble Auto-Uploader</h1>
            <p className="text-xs text-slate-300">Anime RSS → Torrent → Automatic Rumble Upload with Subtitles</p>
          </div>
          <div className="flex gap-2 flex-wrap">
            <button
              onClick={doPoll}
              disabled={loading}
              className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white px-3 py-1.5 rounded text-xs md:text-sm font-medium"
            >
              ▶ Run Cycle Now
            </button>
            <button
              onClick={processBacklog}
              disabled={loading}
              className="bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white px-3 py-1.5 rounded text-xs md:text-sm font-medium"
            >
              ⚙️ Process Backlog
            </button>
            <button
              onClick={() => retryFailed()}
              disabled={loading}
              className="bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white px-3 py-1.5 rounded text-xs md:text-sm font-medium"
            >
              🔁 Retry Failed
            </button>
            <button
              onClick={loadOperationalData}
              disabled={loading}
              className="bg-slate-700 hover:bg-slate-600 disabled:opacity-50 text-white px-3 py-1.5 rounded text-xs md:text-sm"
            >
              🔄 Refresh
            </button>
          </div>
        </div>
        <nav className="max-w-7xl mx-auto px-4 pb-2 flex gap-1 text-sm overflow-x-auto">
          {([
            ['dashboard', '🤖 Dashboard'],
            ['feed', '📡 RSS Feed'],
            ['downloads', '⬇️ Downloads'],
            ['uploads', '🎥 Uploads'],
            ['streams', '🔗 Stream URLs'],
            ['bulk', '📚 Bulk Catalog'],
            ['platforms', '🌍 Platforms'],
            ['settings', '⚙️ Settings'],
          ] as const).map(([key, label]) => (
            <button
              key={key}
              onClick={() => setActiveTab(key as typeof activeTab)}
              className={`px-3 py-1.5 rounded-t font-medium text-xs md:text-sm whitespace-nowrap transition-colors ${
                activeTab === key ? 'bg-slate-50 text-slate-900 font-semibold' : 'text-slate-300 hover:bg-slate-800'
              }`}
            >
              {label}
              {key === 'feed' && items.length > 0 && <span className="ml-1.5 text-xs bg-blue-500 text-white px-1.5 rounded-full">{items.length}</span>}
              {key === 'downloads' && downloads.length > 0 && <span className="ml-1.5 text-xs bg-yellow-500 text-white px-1.5 rounded-full">{downloads.length}</span>}
              {key === 'uploads' && uploads.length > 0 && <span className="ml-1.5 text-xs bg-emerald-500 text-white px-1.5 rounded-full">{uploads.length}</span>}
            </button>
          ))}
        </nav>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6">
        {message && (
          <div
            className={`mb-4 px-4 py-2.5 rounded text-sm border font-medium ${
              message.type === 'ok'
                ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                : 'bg-red-50 border-red-300 text-red-900'
            }`}
          >
            {message.text}
          </div>
        )}

        {/* 🤖 DASHBOARD TAB */}
        {activeTab === 'dashboard' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="bg-white rounded shadow-sm p-4 border border-slate-200">
                <div className="text-xs font-semibold uppercase text-slate-500 mb-1">Auto-pilot Status</div>
                <div className="flex items-center gap-2 mb-2">
                  <span
                    className={`inline-block w-3 h-3 rounded-full ${
                      scheduler?.auto_download || scheduler?.auto_upload
                        ? 'bg-emerald-500 animate-pulse'
                        : 'bg-slate-400'
                    }`}
                  />
                  <span className="font-semibold text-sm">
                    {!scheduler
                      ? 'Loading...'
                      : !scheduler.auto_download && !scheduler.auto_upload
                      ? 'Idle (Auto-download/upload disabled)'
                      : [
                          scheduler.auto_download ? 'Auto-Download' : null,
                          scheduler.auto_upload ? `Auto-Upload (${scheduler.upload_mode})` : null,
                        ]
                          .filter(Boolean)
                          .join(' + ')}
                  </span>
                </div>
                <div className="text-xs text-slate-500 space-y-0.5">
                  <div>Poll interval: <span className="font-mono">{scheduler?.poll_interval_minutes ?? 30} min</span></div>
                  <div>
                    Next run:{' '}
                    <span className="font-mono font-medium">
                      {scheduler?.next_run_at ? new Date(scheduler.next_run_at).toLocaleTimeString() : 'soon...'}
                    </span>
                  </div>
                  <div>
                    Upload method:{' '}
                    <span className="font-semibold text-slate-700 capitalize">
                      {cfg.rumbleUploadMode === 'browser' ? 'Free Browser Mode' : cfg.rumbleUploadMode === 'api' ? 'Rumble Pro API' : 'Off'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded shadow-sm p-4 border border-slate-200">
                <div className="text-xs font-semibold uppercase text-slate-500 mb-1">Last Cycle Results</div>
                <div className="text-xs space-y-1">
                  <div>RSS fetched: <strong>{scheduler?.last_poll_fetched ?? 0}</strong> • new: <strong>{scheduler?.last_poll_new ?? 0}</strong></div>
                  <div>Downloaded: <strong>{scheduler?.last_downloaded ?? 0}</strong></div>
                  <div>Uploaded: <strong>{scheduler?.last_uploaded ?? 0}</strong></div>
                  <div>Duration: <strong>{scheduler ? (scheduler.last_run_ms / 1000).toFixed(1) : 0}s</strong></div>
                  <div>
                    Last poll:{' '}
                    <span className="font-mono">
                      {scheduler?.last_poll_at ? new Date(scheduler.last_poll_at).toLocaleTimeString() : 'never'}
                    </span>
                  </div>
                </div>
                {scheduler?.last_error && (
                  <div className="mt-2 text-xs text-red-700 bg-red-50 border border-red-200 rounded p-1.5 break-words">
                    Error: {scheduler.last_error}
                  </div>
                )}
              </div>

              <div className="bg-white rounded shadow-sm p-4 border border-slate-200">
                <div className="text-xs font-semibold uppercase text-slate-500 mb-1">Quick Setup Checklist</div>
                <ul className="text-xs space-y-1.5 text-slate-600">
                  <li className="flex items-center gap-1.5">
                    {cfg.rumbleUploadMode !== 'none' ? '✅' : '⚪'}{' '}
                    <span>1. Select Upload Mode in Settings</span>
                  </li>
                  <li className="flex items-center gap-1.5">
                    {cfg.rumbleSessionCookies || (cfg.rumbleEmail && cfg.rumblePassword) || cfg.rumbleAccessToken ? '✅' : '⚪'}{' '}
                    <span>2. Enter Rumble sign-in credentials</span>
                  </li>
                  <li className="flex items-center gap-1.5">
                    {cfg.autoDownload && cfg.autoUpload ? '✅' : '⚪'}{' '}
                    <span>3. Toggle Auto-Download &amp; Auto-Upload</span>
                  </li>
                </ul>
                <button
                  onClick={() => setActiveTab('settings')}
                  className="mt-3 w-full bg-slate-900 hover:bg-slate-800 text-white text-xs font-medium py-1.5 rounded"
                >
                  Configure in Settings →
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Stat label="Discovered Anime" value={items.length} color="blue" />
              <Stat label="Downloaded" value={downloads.length} color="yellow" />
              <Stat label="Uploaded to Rumble" value={uploads.length} color="emerald" />
              <Stat
                label="HLS Streams Live"
                value={uploads.filter((u) => u.rumbleStreamUrl && u.status !== 'error').length}
                color="purple"
              />
            </div>

            <div className="bg-white rounded shadow-sm p-3 border border-slate-200">
              <div className="flex items-center justify-between mb-2">
                <div className="text-xs font-semibold text-slate-700">Server Activity Log</div>
                <div className="text-[11px] text-slate-400">Auto-refreshes every 10s • Persisted in DB</div>
              </div>
              <div className="text-xs font-mono text-slate-700 max-h-72 overflow-y-auto space-y-1 bg-slate-50 p-2.5 rounded border border-slate-200">
                {(!scheduler?.recent_logs || scheduler.recent_logs.length === 0) && (
                  <div className="text-slate-400">No events logged yet. Click "Run Cycle Now" above to trigger.</div>
                )}
                {(scheduler?.recent_logs || []).slice().reverse().map((l) => {
                  const ts = new Date(l.created_at).toLocaleTimeString();
                  const color =
                    l.level === 'error'
                      ? 'text-red-700 font-semibold'
                      : l.level === 'warn'
                      ? 'text-amber-700'
                      : 'text-slate-700';
                  return (
                    <div key={l.id} className={color}>
                      <span className="text-slate-400 select-none">[{ts}]</span> {l.message}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* 📡 FEED TAB */}
        {activeTab === 'feed' && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">Discovered Anime (Nyaa.si RSS)</h2>
              <span className="text-xs text-slate-500">{items.length} items loaded</span>
            </div>
            <div className="space-y-2">
              {items.length === 0 && (
                <div className="bg-white rounded p-6 text-center text-slate-500 border border-slate-200">
                  No items yet. Click "Run Cycle Now" in the header to poll {cfg.rssUrl}.
                </div>
              )}
              {items.map((item) => (
                <div key={item.id} className="bg-white rounded shadow-sm p-3 border border-slate-200">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusColor(item.status)}`}>{item.status}</span>
                        {item.resolution && <span className="text-xs bg-slate-200 text-slate-700 px-2 py-0.5 rounded-full">{item.resolution}</span>}
                        {item.fansubGroup && <span className="text-xs bg-slate-200 text-slate-700 px-2 py-0.5 rounded-full">{item.fansubGroup}</span>}
                        {item.episodeNumber && <span className="text-xs bg-slate-200 text-slate-700 px-2 py-0.5 rounded-full">EP {item.episodeNumber}</span>}
                        {item.fileSize && <span className="text-xs text-slate-500">{item.fileSize}</span>}
                        {typeof item.seeders === 'number' && <span className="text-xs text-emerald-700">Seeders: {item.seeders}</span>}
                        {typeof item.leechers === 'number' && <span className="text-xs text-slate-500">Leechers: {item.leechers}</span>}
                      </div>
                      <div className="font-medium text-sm truncate" title={item.title}>{item.title}</div>
                      {item.errorMessage && (
                        <div className="text-xs text-red-600 mt-1">Error: {item.errorMessage}</div>
                      )}
                      <div className="text-xs text-slate-500 mt-1">
                        {item.pubDate && new Date(item.pubDate).toLocaleString()}
                        {item.link && (
                          <a href={item.link} target="_blank" rel="noreferrer" className="ml-2 text-blue-600 hover:underline">
                            source link ↗
                          </a>
                        )}
                      </div>
                    </div>
                    <div className="flex gap-1.5 flex-shrink-0">
                      {(item.status === 'discovered' || item.status === 'error') && (
                        <button onClick={() => doDownload(item.id)} className="bg-yellow-500 hover:bg-yellow-600 text-white px-2.5 py-1 rounded text-xs font-medium">
                          Download
                        </button>
                      )}
                      {(item.status === 'downloaded' || item.status === 'error') && (
                        <button onClick={() => doUpload(item.id)} className="bg-purple-600 hover:bg-purple-700 text-white px-2.5 py-1 rounded text-xs font-medium">
                          Upload to Rumble
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ⬇️ DOWNLOADS TAB */}
        {activeTab === 'downloads' && (
          <div className="space-y-2">
            <h2 className="text-lg font-semibold mb-2">Torrent Downloads</h2>
            {downloads.length === 0 && <div className="bg-white rounded p-6 text-center text-slate-500 border border-slate-200">No downloads yet.</div>}
            {downloads.map((dl) => (
              <div key={dl.id} className="bg-white rounded shadow-sm p-3 border border-slate-200">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusColor(dl.status)}`}>{dl.status}</span>
                      <span className="text-xs text-slate-500">Download #{dl.id}</span>
                    </div>
                    <div className="font-medium text-sm truncate">{dl.name}</div>
                    {dl.videoPath && <div className="text-xs text-slate-600 mt-0.5 font-mono truncate">File: {dl.videoPath}</div>}
                    {dl.subtitles && dl.subtitles.length > 0 && (
                      <div className="text-xs text-emerald-800 mt-1 bg-emerald-50 border border-emerald-200 p-1 rounded inline-block">
                        Extracted subtitles: <strong>{dl.subtitles.map(s => s.lang).join(', ')}</strong> ({dl.subtitles.length} tracks)
                      </div>
                    )}
                    {dl.status === 'downloading' && (
                      <div className="mt-2">
                        <div className="h-2 bg-slate-200 rounded overflow-hidden">
                          <div className="h-full bg-yellow-500" style={{ width: `${dl.progress || 0}%` }} />
                        </div>
                        <div className="text-xs text-slate-500 mt-1">
                          {dl.progress || 0}% • {formatSize(dl.downloaded)} / {formatSize(dl.totalSize)}
                        </div>
                      </div>
                    )}
                  </div>
                  {dl.status === 'done' && (
                    <button
                      onClick={() => doUpload(dl.feedItemId)}
                      className="bg-purple-600 hover:bg-purple-700 text-white px-2.5 py-1 rounded text-xs font-medium"
                    >
                      Upload Now
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* 🎥 UPLOADS TAB */}
        {activeTab === 'uploads' && (
          <div className="space-y-2">
            <h2 className="text-lg font-semibold mb-2">Rumble Uploads</h2>
            {uploads.length === 0 && <div className="bg-white rounded p-6 text-center text-slate-500 border border-slate-200">No uploads yet.</div>}
            {uploads.map((u) => (
              <div key={u.id} className="bg-white rounded shadow-sm p-3 border border-slate-200">
                <div className="flex flex-wrap items-start gap-3">
                  {u.rumbleThumbnail && (
                    <img src={u.rumbleThumbnail} alt="" className="w-40 h-24 object-cover rounded bg-slate-100 flex-shrink-0" />
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-1">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusColor(u.status)}`}>{u.status}</span>
                      <span className="text-xs text-slate-500">Upload #{u.id}</span>
                      {u.rumbleVideoId && <span className="text-xs font-mono bg-slate-100 px-1.5 py-0.5 rounded">{u.rumbleVideoId}</span>}
                    </div>
                    <div className="font-medium text-sm truncate">{u.title}</div>
                    {u.subtitlesUploaded && u.subtitlesUploaded.length > 0 && (
                      <div className="text-xs text-emerald-700 mt-1">
                        Subtitles uploaded to Rumble: {u.subtitlesUploaded.map(s => s.lang).join(', ')}
                      </div>
                    )}
                    {u.status === 'uploading' && (
                      <div className="mt-2">
                        <div className="h-2 bg-slate-200 rounded overflow-hidden">
                          <div className="h-full bg-orange-500" style={{ width: `${u.progress || 0}%` }} />
                        </div>
                        <div className="text-xs text-slate-500 mt-1">{u.progress || 0}% uploaded</div>
                      </div>
                    )}
                    {u.errorMessage && <div className="text-xs text-red-600 mt-1">{u.errorMessage}</div>}
                    {u.status === 'error' && u.feedItemId && (
                      <button
                        onClick={() => retryFailed(u.feedItemId!)}
                        className="mt-1.5 bg-red-600 hover:bg-red-700 text-white px-2.5 py-1 rounded text-xs font-medium"
                      >
                        🔁 Re-upload this video
                      </button>
                    )}
                    <div className="flex flex-wrap items-center gap-2 mt-2 text-xs">
                      {u.rumbleUrl && (
                        <a href={u.rumbleUrl} target="_blank" rel="noreferrer" className="text-blue-600 font-medium hover:underline">
                          Watch on Rumble ↗
                        </a>
                      )}
                      {u.rumbleEmbedUrl && (
                        <a href={u.rumbleEmbedUrl} target="_blank" rel="noreferrer" className="text-slate-600 hover:underline">
                          Embed Player ↗
                        </a>
                      )}
                      {u.rumbleStreamUrl ? (
                        <a href={u.rumbleStreamUrl} target="_blank" rel="noreferrer" className="text-emerald-700 font-bold hover:underline">
                          HLS Stream (.m3u8) ↗
                        </a>
                      ) : (
                        <button onClick={() => getStreamUrl(u.id)} className="text-emerald-700 font-medium underline">
                          Fetch Stream URL
                        </button>
                      )}
                    </div>
                    {u.rumbleStreamUrl && (
                      <div className="mt-1.5 p-1.5 bg-slate-100 border border-slate-200 rounded font-mono text-[10px] text-slate-800 break-all select-all">
                        {u.rumbleStreamUrl}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* 🔗 STREAMS TAB */}
        {activeTab === 'streams' && (
          <div className="space-y-4">
            <h2 className="text-lg font-semibold">Rumble Stream URL API</h2>
            <div className="bg-white rounded shadow-sm p-4 border border-slate-200">
              <p className="text-sm text-slate-700 mb-3">
                When a video is uploaded to Rumble, this API extracts the direct HLS stream URL (<code>chunklist.m3u8</code>). You can use this endpoint in any video player, media center, or scraper:
              </p>
              <div className="space-y-2">
                <div className="font-mono text-xs md:text-sm bg-slate-900 text-emerald-300 p-2.5 rounded">
                  GET /api/streams?id=<span className="text-yellow-300">{'{upload_id}'}</span>
                </div>
                <div className="font-mono text-xs md:text-sm bg-slate-900 text-emerald-300 p-2.5 rounded">
                  GET /api/streams?video_id=<span className="text-yellow-300">{'{rumble_video_id}'}</span>
                </div>
                <div className="font-mono text-xs md:text-sm bg-slate-900 text-emerald-300 p-2.5 rounded">
                  GET /api/streams?url=<span className="text-yellow-300">https://rumble.com/v...-slug.html</span>
                </div>
              </div>
              <p className="text-xs text-slate-500 mt-3">
                Returns JSON with <code>stream_url</code>, <code>hls_url</code>, <code>m3u8_url</code>, <code>subtitles[]</code>, <code>thumbnail</code>, and <code>embed_url</code>.
              </p>
            </div>

            <div className="bg-white rounded shadow-sm p-4 border border-slate-200">
              <h3 className="font-semibold text-sm mb-3">Active Video Streams ({uploads.filter(u => u.rumbleStreamUrl).length})</h3>
              <div className="space-y-2 max-h-[600px] overflow-y-auto">
                {uploads.filter(u => u.rumbleStreamUrl || u.rumbleUrl).map((u) => (
                  <div key={u.id} className="border border-slate-200 rounded p-3 bg-slate-50">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <span className="text-sm font-semibold truncate">{u.title}</span>
                      <span className="text-xs text-slate-500 flex-shrink-0">Upload #{u.id}</span>
                    </div>
                    {u.rumbleStreamUrl ? (
                      <div className="mt-1 font-mono text-[11px] bg-white border border-emerald-300 p-2 rounded break-all text-emerald-900 select-all">
                        {u.rumbleStreamUrl}
                      </div>
                    ) : (
                      <button onClick={() => getStreamUrl(u.id)} className="mt-1 text-xs bg-emerald-600 text-white px-2.5 py-1 rounded">
                        Extract Stream URL
                      </button>
                    )}
                  </div>
                ))}
                {uploads.filter(u => u.rumbleStreamUrl || u.rumbleUrl).length === 0 && (
                  <div className="text-sm text-slate-500 py-4 text-center">No uploads yet. Once a video uploads, its stream URL appears here.</div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ⚙️ SETTINGS TAB */}
        {activeTab === 'platforms' && <PlatformsTab />}

        {/* 📚 BULK CATALOG TAB */}
        {activeTab === 'bulk' && (
          <div className="space-y-4">
            <div className="bg-white rounded shadow-sm p-4 border border-slate-200">
              <h2 className="text-lg font-semibold mb-1">Release Sources &amp; Anime-Only Filter</h2>
              <p className="text-xs text-slate-600 mb-3">
                AnimePahe does not encode its own videos — it uses established fansub / WEB-DL groups such as{' '}
                <strong>SubsPlease, Erai-raws, GJM, Commie, ASW, Judas, EMBER</strong>. Only these trusted providers are accepted by default.
              </p>
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-sm cursor-pointer">
                  <input
                    type="checkbox"
                    className="w-4 h-4"
                    checked={cfg.excludeDonghua}
                    onChange={(e) => setCfg({ ...cfg, excludeDonghua: e.target.checked })}
                  />
                  <span><strong>Real anime only:</strong> exclude donghua / Chinese animation, non-English-translated categories, and unknown CJK-language-only titles</span>
                </label>
                <label className="flex items-center gap-2 text-sm cursor-pointer">
                  <input
                    type="checkbox"
                    className="w-4 h-4"
                    checked={cfg.trustedGroupsOnly}
                    onChange={(e) => setCfg({ ...cfg, trustedGroupsOnly: e.target.checked })}
                  />
                  <span><strong>Trusted providers only:</strong> accept releases from the group list below (the providers AnimePahe and similar sites rely on)</span>
                </label>
              </div>
              <label className="block text-xs font-medium text-slate-700 mt-3 mb-1">Trusted release groups (comma-separated)</label>
              <textarea
                rows={3}
                value={cfg.trustedGroups}
                onChange={(e) => setCfg({ ...cfg, trustedGroups: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded text-xs font-mono bg-white"
              />
              <div className="flex flex-wrap gap-2 mt-3">
                <button
                  onClick={() => saveCfg(cfg)}
                  disabled={loading}
                  className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white px-3.5 py-1.5 rounded text-xs font-semibold"
                >
                  💾 Save Source Filters
                </button>
                <button
                  onClick={purgeNonAnime}
                  disabled={loading}
                  className="bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white px-3.5 py-1.5 rounded text-xs font-semibold"
                >
                  🧹 Remove Existing Donghua / Untrusted Items
                </button>
              </div>
              <p className="text-[11px] text-slate-500 mt-2">
                Changes apply to the next RSS poll and bulk scan. Bulk discovery additionally restricts AniList to titles with <code>countryOfOrigin: JP</code>.
              </p>
            </div>
            <div className="bg-white rounded shadow-sm p-4 border border-slate-200">
              <h2 className="text-lg font-semibold mb-1">Bulk Popular Anime Catalog</h2>
              <p className="text-xs text-slate-600 mb-4">
                Pulls the most popular anime from AniList (popularity rank), searches Nyaa for matching torrents,
                then feeds them into the normal download → subtitle extract → Rumble upload pipeline.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">How many popular anime (1–10000)</label>
                  <input
                    type="number"
                    min={1}
                    max={10000}
                    value={cfg.bulkMaxAnime}
                    onChange={(e) => setCfg({ ...cfg, bulkMaxAnime: Math.min(10000, Math.max(1, Number(e.target.value))) })}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded text-sm bg-white"
                  />
                  <p className="text-[11px] text-slate-500 mt-1">
                    Each title needs one AniList request + one Nyaa search (~4s), so 10000 titles takes many hours.
                    Start small (10–25) and increase once you confirm uploads work.
                  </p>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Torrents per anime (episodes)</label>
                  <input
                    type="number"
                    min={1}
                    max={26}
                    value={cfg.bulkEpisodesPerAnime}
                    onChange={(e) => setCfg({ ...cfg, bulkEpisodesPerAnime: Math.min(26, Math.max(1, Number(e.target.value))) })}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded text-sm bg-white"
                  />
                  <p className="text-[11px] text-slate-500 mt-1">Highest-seeded, non-batch releases are chosen first.</p>
                </div>
              </div>

              <div className="mt-4">
                <label className="block text-xs font-medium text-slate-700 mb-1">Audio options</label>
                <div className="flex flex-wrap gap-2">
                  {([
                    ['sub', 'Subbed (original audio)'],
                    ['dub', 'Dubbed (English dub)'],
                    ['both', 'Both sub + dub'],
                    ['multi', 'Multi-audio only'],
                  ] as const).map(([key, label]) => (
                    <button
                      key={key}
                      type="button"
                      onClick={() => setCfg({ ...cfg, bulkAudioMode: key })}
                      className={`px-3 py-1.5 rounded text-xs font-medium border-2 ${
                        cfg.bulkAudioMode === key
                          ? 'border-blue-600 bg-blue-50 text-blue-900'
                          : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                      }`}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Min seeders for bulk picks</label>
                  <input
                    type="number"
                    min={0}
                    value={cfg.bulkMinSeeders}
                    onChange={(e) => setCfg({ ...cfg, bulkMinSeeders: Number(e.target.value) })}
                    className="w-32 px-3 py-1.5 border border-slate-300 rounded text-sm bg-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Hard-sub language</label>
                  <div className="px-3 py-1.5 border border-slate-200 rounded text-sm bg-slate-50 text-slate-700">
                    🇬🇧 English only
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Burned-in subtitles always use the full English dialogue track. Releases with no English subtitles get no hardsub version.
                  </p>
                </div>
              </div>

              <div className="space-y-2 mt-4">
                <label className="flex items-center gap-2 text-sm cursor-pointer">
                  <input
                    type="checkbox"
                    className="w-4 h-4"
                    checked={cfg.bulkSoftSub}
                    onChange={(e) => setCfg({ ...cfg, bulkSoftSub: e.target.checked })}
                  />
                  <span><strong>Soft subs:</strong> attach every subtitle language as separate Rumble caption tracks</span>
                </label>
                <label className="flex items-center gap-2 text-sm cursor-pointer">
                  <input
                    type="checkbox"
                    className="w-4 h-4"
                    checked={cfg.bulkHardSub}
                    onChange={(e) => setCfg({ ...cfg, bulkHardSub: e.target.checked })}
                  />
                  <span><strong>Hard subs:</strong> burn the <strong>English</strong> subtitles into a separate re-encoded MP4 and upload it as an extra video titled [English Hardsub]</span>
                </label>
              </div>

              <div className="mt-5 flex flex-wrap items-center gap-3">
                <button
                  onClick={startBulkDiscovery}
                  disabled={loading}
                  className="bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white px-4 py-2 rounded text-sm font-semibold"
                >
                  🔍 Discover &amp; Queue Popular Anime
                </button>
                <button
                  onClick={() => setActiveTab('feed')}
                  className="bg-slate-700 hover:bg-slate-600 text-white px-4 py-2 rounded text-sm font-medium"
                >
                  View Queued Items →
                </button>
              </div>

              <div className="mt-4 bg-amber-50 border border-amber-200 text-amber-900 text-xs rounded p-3">
                Only use this with content you own or are licensed to distribute. Hard-sub re-encoding is CPU intensive
                and can take longer than the download itself. Local files are deleted after a successful upload to keep disk usage bounded.
              </div>
            </div>

            <div className="bg-white rounded shadow-sm p-4 border border-slate-200">
              <h3 className="font-semibold text-sm mb-2">Bulk Activity</h3>
              <p className="text-xs text-slate-500 mb-2">Discovery progress appears in the Dashboard activity log.</p>
              <div className="text-xs font-mono text-slate-700 max-h-56 overflow-y-auto space-y-1 bg-slate-50 p-2 rounded border border-slate-200">
                {(scheduler?.recent_logs || []).filter(l => l.message.includes('[bulk]')).slice().reverse().map(l => (
                  <div key={l.id}><span className="text-slate-400">[{new Date(l.created_at).toLocaleTimeString()}]</span> {l.message}</div>
                ))}
                {(scheduler?.recent_logs || []).filter(l => l.message.includes('[bulk]')).length === 0 && (
                  <div className="text-slate-400">No bulk runs yet.</div>
                )}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-semibold">Settings &amp; Automation</h2>
                <p className="text-xs text-slate-500">Choose your Rumble upload method, sign in, and configure filters.</p>
              </div>
              <button
                onClick={() => saveCfg(cfg)}
                disabled={loading}
                className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white px-4 py-2 rounded font-medium text-sm shadow-sm"
              >
                💾 Save Settings
              </button>
            </div>

            {/* UPLOAD METHOD CARDS - CANNOT "CLICK OFF"! */}
            <div className="bg-white rounded shadow-sm p-4 border border-slate-200 space-y-4">
              <div>
                <h3 className="font-semibold text-sm text-slate-800 mb-1">1. Choose Rumble Upload Method</h3>
                <p className="text-xs text-slate-500 mb-3">Click on your preferred upload method below:</p>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {/* Option 1: FREE BROWSER AUTOMATION */}
                  <div
                    onClick={() => saveCfg({ ...cfg, rumbleUploadMode: 'browser' })}
                    className={`cursor-pointer rounded-lg border-2 p-3.5 transition-all select-none ${
                      cfg.rumbleUploadMode === 'browser'
                        ? 'border-emerald-600 bg-emerald-50/60 shadow-sm'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
                        <span>🌐</span>
                        <span>Free Browser Sign-In</span>
                      </div>
                      <span
                        className={`text-xs px-2 py-0.5 rounded-full font-bold ${
                          cfg.rumbleUploadMode === 'browser'
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-100 text-slate-500'
                        }`}
                      >
                        {cfg.rumbleUploadMode === 'browser' ? 'SELECTED' : 'FREE'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600">
                      Sign in with your <strong>regular free Rumble account</strong>. No Pro plan or API key needed. Supports video + all subtitles.
                    </p>
                  </div>

                  {/* Option 2: RUMBLE PRO API */}
                  <div
                    onClick={() => saveCfg({ ...cfg, rumbleUploadMode: 'api' })}
                    className={`cursor-pointer rounded-lg border-2 p-3.5 transition-all select-none ${
                      cfg.rumbleUploadMode === 'api'
                        ? 'border-blue-600 bg-blue-50/60 shadow-sm'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
                        <span>🔑</span>
                        <span>Rumble Pro API</span>
                      </div>
                      <span
                        className={`text-xs px-2 py-0.5 rounded-full font-bold ${
                          cfg.rumbleUploadMode === 'api'
                            ? 'bg-blue-600 text-white'
                            : 'bg-slate-100 text-slate-500'
                        }`}
                      >
                        {cfg.rumbleUploadMode === 'api' ? 'SELECTED' : 'PRO ONLY'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600">
                      Official multipart API (<code>simple-upload.php</code>). Requires a 40-char token from bd@rumble.com.
                    </p>
                  </div>

                  {/* Option 3: NONE */}
                  <div
                    onClick={() => saveCfg({ ...cfg, rumbleUploadMode: 'none' })}
                    className={`cursor-pointer rounded-lg border-2 p-3.5 transition-all select-none ${
                      cfg.rumbleUploadMode === 'none'
                        ? 'border-slate-600 bg-slate-100 shadow-sm'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
                        <span>⏹️</span>
                        <span>Do Not Upload</span>
                      </div>
                      <span
                        className={`text-xs px-2 py-0.5 rounded-full font-bold ${
                          cfg.rumbleUploadMode === 'none'
                            ? 'bg-slate-700 text-white'
                            : 'bg-slate-100 text-slate-500'
                        }`}
                      >
                        {cfg.rumbleUploadMode === 'none' ? 'SELECTED' : 'OFF'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600">
                      Only scrape RSS and download torrents to disk. No video will be uploaded to Rumble.
                    </p>
                  </div>
                </div>
              </div>

              {/* DETAILS FOR BROWSER MODE */}
              {cfg.rumbleUploadMode === 'browser' && (
                <div className="border-t border-slate-200 pt-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold text-sm text-slate-800">2. Free Rumble Sign-In Details</h3>
                    <div className="flex gap-1 text-xs">
                      <button
                        type="button"
                        onClick={() => setAuthSubMode('cookies')}
                        className={`px-3 py-1 rounded font-medium ${
                          authSubMode === 'cookies'
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                        }`}
                      >
                        🍪 Session Cookies (Recommended)
                      </button>
                      <button
                        type="button"
                        onClick={() => setAuthSubMode('credentials')}
                        className={`px-3 py-1 rounded font-medium ${
                          authSubMode === 'credentials'
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                        }`}
                      >
                        ✉️ Email &amp; Password
                      </button>
                    </div>
                  </div>

                  {authSubMode === 'cookies' && (
                    <div className="bg-emerald-50/60 border border-emerald-200 rounded p-3 text-xs space-y-2">
                      <div className="font-semibold text-emerald-900">
                        Why Session Cookies are recommended:
                      </div>
                      <p className="text-slate-700">
                        Rumble's login page uses Cloudflare Turnstile protection ("Just a moment..."). By pasting your cookies from a browser where you are already signed in to Rumble, the uploader <strong>completely bypasses Cloudflare</strong> and navigates directly to the upload page.
                      </p>
                      <div className="bg-white p-2.5 rounded border border-emerald-200 space-y-1 text-slate-700">
                        <div className="font-medium text-emerald-800">How to get your cookies in 20 seconds:</div>
                        <ol className="list-decimal list-inside space-y-0.5">
                          <li>Log in to <a href="https://rumble.com" target="_blank" rel="noreferrer" className="text-blue-600 underline">rumble.com</a> in your regular browser.</li>
                          <li>Install the free <strong>Cookie-Editor</strong> extension (Chrome/Edge/Firefox).</li>
                          <li>Click the cookie icon on rumble.com &gt; click <strong>Export &gt; Export as JSON</strong>.</li>
                          <li>Paste the exported text into the box below.</li>
                        </ol>
                      </div>

                      <label className="block text-xs font-semibold text-slate-700 mt-2">
                        Pasted Rumble Cookies (JSON or key=value header format):
                      </label>
                      <textarea
                        rows={4}
                        value={cfg.rumbleSessionCookies}
                        onChange={(e) => setCfg({ ...cfg, rumbleSessionCookies: e.target.value })}
                        onBlur={() => saveCfg(cfg)}
                        className="w-full px-3 py-2 border border-slate-300 rounded font-mono text-xs bg-white"
                        placeholder='[{"name":"a_s","value":"...","domain":".rumble.com"}, ...]'
                      />
                      <div className="flex items-center justify-between gap-2 text-xs">
                        <span className={cfg.rumbleSessionCookies.trim() ? 'text-emerald-700 font-medium' : 'text-slate-500'}>
                          {cfg.rumbleSessionCookies.trim()
                            ? `✅ Cookies saved on the server (${cookieCount(cfg.rumbleSessionCookies)} cookies). They are reused automatically — you won't need to paste them again.`
                            : 'No cookies saved yet.'}
                        </span>
                        <button
                          type="button"
                          onClick={() => saveCfg(cfg)}
                          className="bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-1 rounded font-medium"
                        >
                          Save cookies
                        </button>
                      </div>
                    </div>
                  )}

                  {authSubMode === 'credentials' && (
                    <div className="space-y-3 bg-slate-50 border border-slate-200 rounded p-3">
                      <p className="text-xs text-slate-600">
                        Enter your Rumble account credentials. The server will launch headless Chromium to log in:
                      </p>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-xs font-medium text-slate-700 mb-1">Rumble Email</label>
                          <input
                            type="email"
                            value={cfg.rumbleEmail}
                            onChange={(e) => setCfg({ ...cfg, rumbleEmail: e.target.value })}
                            className="w-full px-3 py-1.5 border border-slate-300 rounded text-sm bg-white"
                            placeholder="user@example.com"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-slate-700 mb-1">Rumble Password</label>
                          <input
                            type="password"
                            value={cfg.rumblePassword}
                            onChange={(e) => setCfg({ ...cfg, rumblePassword: e.target.value })}
                            className="w-full px-3 py-1.5 border border-slate-300 rounded text-sm bg-white"
                            placeholder="••••••••"
                          />
                        </div>
                      </div>
                      <p className="text-[11px] text-amber-700">
                        ⚠️ If Cloudflare or 2FA blocks headless login, switch to the "Session Cookies" tab above.
                      </p>
                    </div>
                  )}

                  {/* TEST CONNECTION BUTTON */}
                  <div className="flex flex-wrap items-center gap-3 pt-1">
                    <button
                      type="button"
                      onClick={doTestLogin}
                      disabled={testingLogin}
                      className="bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white px-3.5 py-1.5 rounded text-xs font-semibold shadow-sm flex items-center gap-1.5"
                    >
                      {testingLogin ? '⏳ Verifying connection...' : '🧪 Test Rumble Sign-In'}
                    </button>
                    {testLoginResult && (
                      <span
                        className={`text-xs px-2.5 py-1 rounded font-medium border ${
                          testLoginResult.ok
                            ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                            : 'bg-red-50 border-red-300 text-red-800'
                        }`}
                      >
                        {testLoginResult.ok ? '✅ ' : '❌ '}
                        {testLoginResult.message}
                      </span>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Primary Rumble Category</label>
                    <input
                      type="text"
                      value={cfg.rumblePrimaryCategory}
                      onChange={(e) => setCfg({ ...cfg, rumblePrimaryCategory: e.target.value })}
                      className="w-full px-3 py-1.5 border border-slate-300 rounded text-sm bg-white"
                      placeholder="Entertainment"
                    />
                    <p className="text-[11px] text-slate-500 mt-1">
                      Must match a Rumble category name exactly (e.g. <code>Entertainment</code>, <code>Film &amp; Animation</code>, <code>Gaming</code>, <code>Anime</code>).
                    </p>
                  </div>
                </div>
              )}

              {/* DETAILS FOR API MODE */}
              {cfg.rumbleUploadMode === 'api' && (
                <div className="border-t border-slate-200 pt-4 space-y-3">
                  <h3 className="font-semibold text-sm text-slate-800">2. Rumble Pro API Credentials</h3>
                  <div className="bg-blue-50 border border-blue-200 rounded p-3 text-xs text-slate-700 space-y-1">
                    <p className="font-semibold text-blue-900">How to request an API token from Rumble:</p>
                    <ol className="list-decimal list-inside space-y-0.5">
                      <li>You must have a Rumble Pro subscription.</li>
                      <li>Email <a href="mailto:bd@rumble.com" className="text-blue-700 underline font-medium">bd@rumble.com</a> requesting access to the Simple Upload API.</li>
                      <li>They will email back a 40-character <code>access_token</code>. Paste it below.</li>
                    </ol>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">Access Token (40 chars)</label>
                      <input
                        type="text"
                        value={cfg.rumbleAccessToken}
                        onChange={(e) => setCfg({ ...cfg, rumbleAccessToken: e.target.value })}
                        className="w-full px-3 py-1.5 border border-slate-300 rounded font-mono text-sm bg-white"
                        placeholder="0123456789abcdef0123456789abcdef01234567"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">Channel ID</label>
                      <input
                        type="text"
                        value={cfg.rumbleChannelId}
                        onChange={(e) => setCfg({ ...cfg, rumbleChannelId: e.target.value })}
                        className="w-full px-3 py-1.5 border border-slate-300 rounded font-mono text-sm bg-white"
                        placeholder="123456"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">License Type</label>
                    <select
                      value={cfg.rumbleLicenseType}
                      onChange={(e) => setCfg({ ...cfg, rumbleLicenseType: Number(e.target.value) })}
                      className="w-full px-3 py-1.5 border border-slate-300 rounded text-sm bg-white"
                    >
                      <option value={0}>0 - Personal Use (not for sale / default)</option>
                      <option value={6}>6 - Rumble Only</option>
                    </select>
                  </div>
                </div>
              )}

              {/* TITLE TEMPLATE */}
              <div className="border-t border-slate-200 pt-4">
                <label className="block text-xs font-medium text-slate-700 mb-1">Video Title Template</label>
                <input
                  type="text"
                  value={cfg.rumbleDefaultTitleTemplate}
                  onChange={(e) => setCfg({ ...cfg, rumbleDefaultTitleTemplate: e.target.value })}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded text-sm bg-white"
                  placeholder="{title}"
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  Placeholders: <code>{'{title}'}</code>, <code>{'{group}'}</code>, <code>{'{episode}'}</code>, <code>{'{resolution}'}</code>
                </p>
              </div>
            </div>

            {/* RSS FEED & FILTER SETTINGS */}
            <div className="bg-white rounded shadow-sm p-4 border border-slate-200 space-y-4">
              <h3 className="font-semibold text-sm text-slate-800">3. Anime RSS Feed Source &amp; Filters</h3>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">RSS URL</label>
                <input
                  type="text"
                  value={cfg.rssUrl}
                  onChange={(e) => setCfg({ ...cfg, rssUrl: e.target.value })}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded font-mono text-xs md:text-sm bg-white"
                  placeholder="https://nyaa.si/?page=rss"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Upload quality</label>
                  <div className="w-full px-3 py-1.5 border border-slate-200 rounded text-sm bg-slate-50 text-slate-700">
                    1080p only · 720p fallback
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Fansub group</label>
                  <input
                    type="text"
                    value={cfg.rssFilterFansub}
                    onChange={(e) => setCfg({ ...cfg, rssFilterFansub: e.target.value })}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded text-sm bg-white"
                    placeholder="e.g. SubsPlease (empty = all)"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Min seeders</label>
                  <input
                    type="number"
                    value={cfg.rssMinSeeders}
                    onChange={(e) => setCfg({ ...cfg, rssMinSeeders: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded text-sm bg-white"
                    placeholder="0"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Keyword filter (comma-separated anime titles)</label>
                <input
                  type="text"
                  value={cfg.rssFilterKeywords}
                  onChange={(e) => setCfg({ ...cfg, rssFilterKeywords: e.target.value })}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded text-sm bg-white"
                  placeholder="e.g. One Piece,Solo Leveling,Frieren (empty = all)"
                />
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded p-3 text-xs text-slate-700 space-y-2">
                <div className="font-semibold text-blue-900">Video quality check</div>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    className="w-4 h-4"
                    checked={cfg.enforceResolution}
                    onChange={(e) => setCfg({ ...cfg, enforceResolution: e.target.checked })}
                  />
                  <span>Verify every file's real resolution before uploading (recommended)</span>
                </label>
                <ul className="list-disc list-inside text-[11px] text-slate-600 space-y-0.5">
                  <li>Rumble only creates qualities up to what you upload, so <strong>1080p</strong> is uploaded whenever a 1080p release exists.</li>
                  <li><strong>720p</strong> is used only when no 1080p release of that episode appears within 60 minutes.</li>
                  <li>480p, 360p, 4K and anything else are never uploaded, and only one release per episode is uploaded.</li>
                  <li>The real resolution is measured with ffprobe (aspect-aware, so 1920×804 counts as 1080p), not taken from the title.</li>
                </ul>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Max torrent size (GB)</label>
                <input
                  type="number"
                  min={0}
                  step={0.5}
                  value={cfg.rssMaxSizeGb}
                  onChange={(e) => setCfg({ ...cfg, rssMaxSizeGb: Number(e.target.value) })}
                  className="w-32 px-3 py-1.5 border border-slate-300 rounded text-sm bg-white"
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  Skips season batch packs and Blu-ray ISOs that would fill the disk. A single 1080p episode is usually 0.3–1.5 GB. Local files are deleted automatically after a successful upload.
                </p>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Poll interval (minutes)</label>
                <input
                  type="number"
                  min={1}
                  value={cfg.rssPollIntervalMinutes}
                  onChange={(e) => setCfg({ ...cfg, rssPollIntervalMinutes: Number(e.target.value) })}
                  className="w-32 px-3 py-1.5 border border-slate-300 rounded text-sm bg-white"
                />
              </div>
            </div>

            {/* AUTOMATION TOGGLES */}
            <div className="bg-white rounded shadow-sm p-4 border border-slate-200 space-y-3">
              <h3 className="font-semibold text-sm text-slate-800">4. Automatic Scheduling</h3>

              <div className="space-y-2">
                <label className="flex items-center gap-2 text-sm cursor-pointer select-none">
                  <input
                    type="checkbox"
                    className="w-4 h-4 text-blue-600 rounded"
                    checked={cfg.autoDownload}
                    onChange={(e) => setCfg({ ...cfg, autoDownload: e.target.checked })}
                  />
                  <span className="font-medium text-slate-800">Auto-download newly discovered anime torrents</span>
                </label>
                <label className="flex items-center gap-2 text-sm cursor-pointer select-none">
                  <input
                    type="checkbox"
                    className="w-4 h-4 text-emerald-600 rounded"
                    checked={cfg.autoUpload}
                    onChange={(e) => setCfg({ ...cfg, autoUpload: e.target.checked })}
                  />
                  <span className="font-medium text-slate-800">Auto-upload completed videos to Rumble with all subtitles</span>
                </label>
              </div>

              <div className="pt-2">
                <button
                  onClick={() => saveCfg(cfg)}
                  disabled={loading}
                  className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white px-5 py-2.5 rounded font-semibold text-sm shadow-sm"
                >
                  💾 Save Settings &amp; Arm Scheduler
                </button>
              </div>
            </div>
          </div>
        )}
      </main>

      <footer className="max-w-7xl mx-auto px-4 py-6 text-xs text-slate-400 border-t border-slate-200 mt-8 flex flex-wrap items-center justify-between gap-2">
        <div>🎬 Rumble Auto-Uploader • BitTorrent + WebTorrent + ffmpeg + Rumble HLS Extraction</div>
        <div>Stream API: <code>/api/streams?id=...</code></div>
      </footer>
    </div>
  );
}
