declare module 'ffmpeg-static' {
  const path: string | { default?: string } | null;
  export default path;
}

declare module 'ffprobe-static' {
  const mod: { path: string };
  export default mod;
}
