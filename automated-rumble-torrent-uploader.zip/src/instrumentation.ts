// Runs on server startup (both dev and prod).
// Kicks off the background RSS/auto-download/auto-upload scheduler.

// Playwright reads PLAYWRIGHT_BROWSERS_PATH at import time. Set it BEFORE any
// module imports the browser library, so uploads never use ~/.cache.
process.env.PLAYWRIGHT_BROWSERS_PATH = `${process.cwd()}/.playwright-browsers`;

import { ensureDirs } from './lib/storage';
import { startScheduler } from './lib/scheduler';

export async function register() {
  if (process.env.NEXT_RUNTIME !== 'nodejs') return;
  try {
    await ensureDirs();
  } catch {
    /* ignore */
  }
  // Start scheduler (async); don't block server boot.
  startScheduler().catch((e) => console.error('[instrumentation] scheduler start failed:', e));
}
