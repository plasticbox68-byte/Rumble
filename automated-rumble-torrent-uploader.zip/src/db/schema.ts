import {
  pgTable,
  serial,
  text,
  varchar,
  timestamp,
  integer,
  boolean,
  jsonb,
} from 'drizzle-orm/pg-core';

// Settings table stores rumble credentials, RSS config, etc.
export const settings = pgTable('settings', {
  id: serial('id').primaryKey(),
  key: varchar('key', { length: 255 }).notNull().unique(),
  value: text('value'),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Log of background-scheduler events; drives the in-app Activity Log panel.
export const schedulerLogs = pgTable('scheduler_logs', {
  id: serial('id').primaryKey(),
  level: varchar('level', { length: 16 }).notNull().default('info'), // info | warn | error
  message: text('message').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// A single row tracks scheduler health / last run timings.
export const schedulerState = pgTable('scheduler_state', {
  id: serial('id').primaryKey(),
  lastPollAt: timestamp('last_poll_at'),
  lastPollFetched: integer('last_poll_fetched').default(0),
  lastPollNew: integer('last_poll_new').default(0),
  lastDownloaded: integer('last_downloaded').default(0),
  lastUploaded: integer('last_uploaded').default(0),
  lastError: text('last_error'),
  lastRunMs: integer('last_run_ms').default(0),
  nextRunAt: timestamp('next_run_at'),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});


// Anime feed items discovered from RSS
export const feedItems = pgTable('feed_items', {
  id: serial('id').primaryKey(),
  feedUrl: varchar('feed_url', { length: 1024 }).notNull(),
  title: text('title').notNull(),
  link: text('link'),
  guid: varchar('guid', { length: 1024 }).notNull().unique(),
  pubDate: timestamp('pub_date'),
  description: text('description'),
  category: text('category'),
  torrentUrl: text('torrent_url'),
  infoHash: varchar('info_hash', { length: 64 }),
  magnetUri: text('magnet_uri'),
  fileSize: varchar('file_size', { length: 64 }),
  seeders: integer('seeders'),
  leechers: integer('leechers'),
  fansubGroup: varchar('fansub_group', { length: 255 }),
  episodeNumber: varchar('episode_number', { length: 64 }),
  resolution: varchar('resolution', { length: 32 }),
  actualResolution: varchar('actual_resolution', { length: 32 }),
  // Normalized "series|season|episode" key used to compare releases of the same episode.
  episodeKey: varchar('episode_key', { length: 512 }),
  status: varchar('status', { length: 32 }).notNull().default('discovered'),
  // discovered -> downloading -> processing -> uploading -> uploaded -> error
  errorMessage: text('error_message'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Downloaded torrents / files on disk
export const downloads = pgTable('downloads', {
  id: serial('id').primaryKey(),
  feedItemId: integer('feed_item_id').references(() => feedItems.id, { onDelete: 'cascade' }),
  infoHash: varchar('info_hash', { length: 64 }),
  name: text('name').notNull(),
  downloadPath: text('download_path'),
  totalSize: integer('total_size'),
  downloaded: integer('downloaded').default(0),
  progress: integer('progress').default(0),
  status: varchar('status', { length: 32 }).notNull().default('pending'),
  // pending -> downloading -> done -> error
  files: jsonb('files').$type<{ path: string; size: number; type: 'video' | 'subtitle' | 'other' }[]>(),
  subtitles: jsonb('subtitles').$type<{ lang: string; path: string; codec: string; title?: string }[]>(),
  videoPath: text('video_path'),
  actualWidth: integer('actual_width'),
  actualHeight: integer('actual_height'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Videos uploaded to Rumble
export const uploads = pgTable('uploads', {
  id: serial('id').primaryKey(),
  feedItemId: integer('feed_item_id').references(() => feedItems.id, { onDelete: 'set null' }),
  downloadId: integer('download_id').references(() => downloads.id, { onDelete: 'set null' }),
  title: text('title').notNull(),
  description: text('description'),
  channelId: varchar('channel_id', { length: 64 }),
  rumbleVideoId: varchar('rumble_video_id', { length: 128 }),
  rumbleUrl: text('rumble_url'),
  rumbleEmbedUrl: text('rumble_embed_url'),
  rumbleStreamUrl: text('rumble_stream_url'),
  rumbleThumbnail: text('rumble_thumbnail'),
  status: varchar('status', { length: 32 }).notNull().default('pending'),
  // pending -> uploading -> processing -> live -> error
  variant: varchar('variant', { length: 32 }).notNull().default('soft'),
  // soft = original video with attached subtitle tracks; hard = burned-in subtitles
  hardLang: varchar('hard_lang', { length: 16 }),
  progress: integer('progress').default(0),
  rumbleResponse: jsonb('rumble_response').$type<Record<string, unknown>>(),
  errorMessage: text('error_message'),
  subtitlesUploaded: jsonb('subtitles_uploaded').$type<{ lang: string; filename: string }[]>(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export type FeedItem = typeof feedItems.$inferSelect;
export type NewFeedItem = typeof feedItems.$inferInsert;
export type Download = typeof downloads.$inferSelect;
export type NewDownload = typeof downloads.$inferInsert;
export type Upload = typeof uploads.$inferSelect;
export type NewUpload = typeof uploads.$inferInsert;

// Copies of an uploaded episode on other video platforms (Dailymotion, OK.ru, Odysee, ...).
export const platformUploads = pgTable('platform_uploads', {
  id: serial('id').primaryKey(),
  feedItemId: integer('feed_item_id').references(() => feedItems.id, { onDelete: 'set null' }),
  uploadId: integer('upload_id').references(() => uploads.id, { onDelete: 'set null' }),
  platform: varchar('platform', { length: 32 }).notNull(),
  title: text('title'),
  status: varchar('status', { length: 32 }).notNull().default('pending'),
  // pending -> uploading -> done | error
  url: text('url'),
  embedUrl: text('embed_url'),
  remoteId: varchar('remote_id', { length: 255 }),
  // none | pending | done | partial | error | unsupported
  subtitleStatus: varchar('subtitle_status', { length: 16 }).notNull().default('none'),
  subtitleNote: text('subtitle_note'),
  errorMessage: text('error_message'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});
export type PlatformUpload = typeof platformUploads.$inferSelect;

// Subtitle text kept in the DB so it survives local file cleanup. Served publicly at
// /api/subs/{id}.vtt (Byse player) and re-sent to platforms that need it later (VidShared).
export const subtitleTracks = pgTable('subtitle_tracks', {
  id: serial('id').primaryKey(),
  feedItemId: integer('feed_item_id').references(() => feedItems.id, { onDelete: 'cascade' }),
  lang: varchar('lang', { length: 16 }).notNull(),
  label: varchar('label', { length: 64 }).notNull(),
  srt: text('srt').notNull(),
  vtt: text('vtt').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});
export type SubtitleTrack = typeof subtitleTracks.$inferSelect;
