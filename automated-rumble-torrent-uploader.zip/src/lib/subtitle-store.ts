import fs from 'fs/promises';
import os from 'os';
import path from 'path';
import { db } from '@/db';
import { subtitleTracks, type SubtitleTrack } from '@/db/schema';
import { eq } from 'drizzle-orm';

const LANG_LABELS: Record<string, string> = {
  en: 'English', ja: 'Japanese', es: 'Spanish', pt: 'Portuguese', fr: 'French', de: 'German', it: 'Italian',
  ru: 'Russian', ar: 'Arabic', zh: 'Chinese', ko: 'Korean', id: 'Indonesian', ms: 'Malay', th: 'Thai',
  vi: 'Vietnamese', tr: 'Turkish', pl: 'Polish', nl: 'Dutch', hi: 'Hindi', he: 'Hebrew', uk: 'Ukrainian',
  cs: 'Czech', hu: 'Hungarian', ro: 'Romanian', el: 'Greek', sv: 'Swedish', fi: 'Finnish', da: 'Danish', no: 'Norwegian',
};
export const langLabel = (lang: string) => LANG_LABELS[lang] || lang.toUpperCase();

/** SRT → WebVTT (timestamps use "." and a WEBVTT header). */
export function srtToVtt(srt: string): string {
  const body = srt
    .replace(/^\uFEFF/, '')
    .replace(/\r\n?/g, '\n')
    .replace(/(\d{2}:\d{2}:\d{2}),(\d{3})/g, '$1.$2');
  return `WEBVTT\n\n${body.trim()}\n`;
}

/** Store every subtitle language for an episode (replaces previous copies). */
export async function storeSubtitleTracks(feedItemId: number, subtitles: Record<string, string>): Promise<SubtitleTrack[]> {
  const rows: SubtitleTrack[] = [];
  const entries = Object.entries(subtitles);
  if (entries.length === 0) return rows;
  await db.delete(subtitleTracks).where(eq(subtitleTracks.feedItemId, feedItemId));
  for (const [lang, file] of entries) {
    try {
      const srt = await fs.readFile(file, 'utf8');
      if (!srt.trim()) continue;
      const [row] = await db
        .insert(subtitleTracks)
        .values({ feedItemId, lang, label: langLabel(lang), srt, vtt: srtToVtt(srt) })
        .returning();
      rows.push(row);
    } catch (e) {
      console.warn(`[subs] could not store ${lang} for #${feedItemId}: ${(e as Error).message}`);
    }
  }
  // English first so players pick it as the default track.
  return rows.sort((a, b) => (a.lang === 'en' ? -1 : b.lang === 'en' ? 1 : a.lang.localeCompare(b.lang)));
}

export async function getSubtitleTracks(feedItemId: number): Promise<SubtitleTrack[]> {
  const rows = await db.select().from(subtitleTracks).where(eq(subtitleTracks.feedItemId, feedItemId));
  return rows.sort((a, b) => (a.lang === 'en' ? -1 : b.lang === 'en' ? 1 : a.lang.localeCompare(b.lang)));
}

/** Write a stored track to a temp file (for platforms that need a file upload). */
export async function trackToTempFile(track: SubtitleTrack, format: 'srt' | 'vtt' = 'srt'): Promise<string> {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'subs-'));
  const file = path.join(dir, `${track.label}.${track.lang}.${format}`);
  await fs.writeFile(file, format === 'srt' ? track.srt : track.vtt, 'utf8');
  return file;
}

/** Public URL of the app (used for subtitle links on players such as Byse). */
export function publicBaseUrl(req?: Request): string | null {
  if (process.env.PUBLIC_BASE_URL) return process.env.PUBLIC_BASE_URL.replace(/\/$/, '');
  if (!req) return null;
  const h = req.headers;
  const host = h.get('x-forwarded-host') || h.get('host');
  if (!host || /^(localhost|127\.|0\.0\.0\.0)/.test(host)) return null;
  const proto = h.get('x-forwarded-proto') || 'https';
  return `${proto}://${host}`;
}

/** Byse/Filemoon player: subtitles are attached with c1_file/c1_label URL parameters. */
export function byseEmbedWithSubs(embedUrl: string, tracks: SubtitleTrack[], base: string | null): string {
  if (!base || tracks.length === 0) return embedUrl;
  const u = new URL(embedUrl);
  tracks.slice(0, 20).forEach((t, i) => {
    u.searchParams.set(`c${i + 1}_file`, `${base}/api/subs/${t.id}.vtt`);
    u.searchParams.set(`c${i + 1}_label`, t.label);
  });
  return u.toString();
}
