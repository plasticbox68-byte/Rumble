import { spawn } from 'child_process';
import ffmpegStatic from 'ffmpeg-static';
import ffprobeStatic from 'ffprobe-static';
import path from 'path';
import fs from 'fs/promises';

// ffmpeg-static exports the path to the binary. Under some bundling
// conditions it may be an object with a default - handle both.
function getFfmpegPath(): string {
  const raw = (ffmpegStatic as unknown) as string | { default: string } | null;
  if (!raw) return 'ffmpeg';
  if (typeof raw === 'string') return raw;
  if (typeof raw === 'object' && raw.default) return raw.default;
  return 'ffmpeg';
}

function getFfprobePath(): string {
  const raw = (ffprobeStatic as unknown) as { path: string } | null;
  if (!raw || !raw.path) return 'ffprobe';
  return raw.path;
}

export const FFMPEG_PATH = getFfmpegPath();
export const FFPROBE_PATH = getFfprobePath();

export type FFProbeStream = {
  index: number;
  codec_name: string;
  codec_type: string;
  width?: number;
  height?: number;
  duration?: number | string;
  language?: string;
  tags?: Record<string, string>;
};

export type FFProbeResult = {
  streams: FFProbeStream[];
  format: Record<string, unknown>;
};

export async function ffprobe(filePath: string): Promise<FFProbeResult> {
  return new Promise((resolve, reject) => {
    const args = [
      '-v',
      'error',
      '-print_format',
      'json',
      '-show_format',
      '-show_streams',
      filePath,
    ];
    const proc = spawn(FFPROBE_PATH, args);
    let stdout = '';
    let stderr = '';
    proc.stdout.on('data', (d) => (stdout += d.toString()));
    proc.stderr.on('data', (d) => (stderr += d.toString()));
    proc.on('close', (code) => {
      if (code !== 0) return reject(new Error(`ffprobe failed (${code}): ${stderr}`));
      try {
        resolve(JSON.parse(stdout));
      } catch (e) {
        reject(new Error(`Failed to parse ffprobe output: ${(e as Error).message}\n${stdout}`));
      }
    });
    proc.on('error', reject);
  });
}

/** Read the actual video stream properties (width/height/codec/duration). */
export async function probeVideoInfo(filePath: string): Promise<{
  width: number;
  height: number;
  codec: string;
  duration: number;
  resolution: string;
}> {
  const probe = await ffprobe(filePath);
  const v = probe.streams.find((s) => s.codec_type === 'video');
  if (!v) throw new Error(`No video stream in ${filePath}`);
  const width = Number(v.tags?.width || v.width || 0);
  const height = Number(v.tags?.height || v.height || 0);
  const duration = Number(probe.format?.duration || v.duration || 0);
  // 16:9-equivalent height, so cinema-scope encodes (1920x804) still count as 1080p.
  const effective = Math.max(height, Math.round((width * 9) / 16));
  const resolution =
    effective >= 1800 ? '2160p' : effective >= 1300 ? '1440p' : effective >= 1000 ? '1080p' : effective >= 700 ? '720p' : effective >= 400 ? '480p' : '360p';
  return { width, height, codec: v.codec_name, duration, resolution };
}

export type ExtractedSubtitle = {
  lang: string;
  title?: string;
  codec: string;
  path: string; // path to extracted SRT file
};

/**
 * Extract all subtitle streams from a video file.
 * Converts ASS/SSA to SRT, leaves SRT as-is.
 */
export async function extractSubtitles(
  videoPath: string,
  outDir: string
): Promise<ExtractedSubtitle[]> {
  await fs.mkdir(outDir, { recursive: true });
  const probe = await ffprobe(videoPath);
  const subs = probe.streams.filter((s) => s.codec_type === 'subtitle');

  const extracted: ExtractedSubtitle[] = [];

  for (const sub of subs) {
    const lang = (sub.tags?.language || 'und').toLowerCase();
    const title = sub.tags?.title;
    const codec = sub.codec_name.toLowerCase();
    const baseName = `sub_${sub.index}_${lang}`;

    if (codec === 'srt' || codec === 'subrip') {
      const outPath = path.join(outDir, `${baseName}.srt`);
      await runFfmpegExtract(videoPath, sub.index, outPath, false);
      extracted.push({ lang, title, codec, path: outPath });
    } else if (codec === 'ass' || codec === 'ssa') {
      // Extract ass, then convert to srt
      const assPath = path.join(outDir, `${baseName}.ass`);
      const srtPath = path.join(outDir, `${baseName}.srt`);
      await runFfmpegExtract(videoPath, sub.index, assPath, false);
      await runFfmpegConvert(assPath, srtPath);
      try {
        await fs.unlink(assPath);
      } catch {
        /* ignore */
      }
      extracted.push({ lang, title, codec, path: srtPath });
    } else if (codec === 'webvtt') {
      const outPath = path.join(outDir, `${baseName}.srt`);
      await runFfmpegConvert(path.join(outDir, `${baseName}.vtt`), outPath);
      extracted.push({ lang, title, codec, path: outPath });
    } else if (codec === 'hdmv_pgs_subtitle' || codec === 'pgs' || codec === 'dvd_subtitle' || codec === 'sub') {
      // Bitmap subs - ffmpeg can extract but they're images; try to extract as idx/sub and note that
      // conversion to SRT requires OCR which we won't attempt. Skip with warning.
      console.warn(
        `[ffmpeg] Bitmap subtitle codec "${codec}" at stream ${sub.index} (${lang}) - skipping OCR for SRT`
      );
      continue;
    } else {
      // Unknown - try direct extraction
      try {
        const outPath = path.join(outDir, `${baseName}.srt`);
        await runFfmpegExtract(videoPath, sub.index, outPath, true);
        extracted.push({ lang, title, codec, path: outPath });
      } catch (e) {
        console.warn(
          `[ffmpeg] Could not extract subtitle stream ${sub.index} (${codec}/${lang}): ${(e as Error).message}`
        );
      }
    }
  }

  return extracted;
}

function runFfmpegExtract(
  videoPath: string,
  streamIndex: number,
  outPath: string,
  convertToSrt: boolean
): Promise<void> {
  return new Promise((resolve, reject) => {
    const args = [
      '-y',
      '-i',
      videoPath,
      '-map',
      `0:${streamIndex}`,
    ];
    if (convertToSrt) {
      args.push('-c:s', 'srt');
    } else {
      args.push('-c', 'copy');
    }
    args.push(outPath);

    const proc = spawn(FFMPEG_PATH, args);
    let stderr = '';
    proc.stderr.on('data', (d) => (stderr += d.toString()));
    proc.on('close', (code) => {
      if (code !== 0) return reject(new Error(`ffmpeg extract failed (${code}): ${stderr}`));
      resolve();
    });
    proc.on('error', reject);
  });
}

function runFfmpegConvert(inputPath: string, outputPath: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const args = ['-y', '-i', inputPath, '-c:s', 'srt', outputPath];
    const proc = spawn(FFMPEG_PATH, args);
    let stderr = '';
    proc.stderr.on('data', (d) => (stderr += d.toString()));
    proc.on('close', (code) => {
      if (code !== 0) return reject(new Error(`ffmpeg convert failed (${code}): ${stderr}`));
      resolve();
    });
    proc.on('error', reject);
  });
}

/**
 * Convert ASS to SRT if needed. Rumble accepts .srt files.
 */
export async function ensureSrt(inputPath: string): Promise<string> {
  const ext = path.extname(inputPath).toLowerCase();
  if (ext === '.srt') return inputPath;
  const outPath = inputPath.replace(/\.[^.]+$/, '.srt');
  await runFfmpegConvert(inputPath, outPath);
  return outPath;
}
