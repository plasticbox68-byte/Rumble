import { db } from '@/db';
import { feedItems, schedulerLogs } from '@/db/schema';
import { eq } from 'drizzle-orm';
import { parseNyaaRss, storeFeedItems, parseSizeToBytes, passesSourceFilters, type NyaaRssItem } from './rss';
import { getConfig } from './config';
import { isAcceptedResolution, titleResolution } from './quality';
import { episodeKey } from './rss';

type AnimeEntry = {
  id: number;
  title: string;
  english: string;
  popularity: number;
};

/**
 * Fetch the most popular anime on AniList (public GraphQL API, no key required).
 * 50 per page, with a small delay to respect the 30 req/min rate limit.
 */
export async function fetchPopularAnime(
  limit: number,
  onProgress?: (msg: string) => void
): Promise<AnimeEntry[]> {
  const results: AnimeEntry[] = [];
  const perPage = 50;
  const pages = Math.ceil(Math.min(limit, 10_000) / perPage);
  for (let page = 1; page <= pages; page++) {
    try {
      const res = await fetch('https://graphql.anilist.co', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({
          query: `query ($page: Int, $perPage: Int) {
            Page(page: $page, perPage: $perPage) {
              media(sort: POPULARITY_DESC, type: ANIME, isAdult: false, countryOfOrigin: JP, format_in: [TV, MOVIE, ONA, OVA]) {
                id
                title { romaji english }
                popularity
              }
            }
          }`,
          variables: { page, perPage: Math.min(perPage, limit - results.length) },
        }),
        signal: AbortSignal.timeout(45_000),
      });
      if (!res.ok) throw new Error(`AniList HTTP ${res.status}`);
      const json = (await res.json()) as {
        data?: { Page?: { media?: { id: number; title: { romaji: string; english: string | null }; popularity: number }[] } };
        errors?: { message: string }[];
      };
      if (json.errors?.length) throw new Error(json.errors[0].message);
      const media = json.data?.Page?.media || [];
      if (media.length === 0) break;
      for (const m of media) {
        results.push({
          id: m.id,
          title: m.title.romaji || m.title.english || '',
          english: m.title.english || m.title.romaji || '',
          popularity: m.popularity || 0,
        });
      }
      onProgress?.(`AniList page ${page}/${pages}: ${results.length} titles fetched`);
      if (results.length >= limit) break;
      await new Promise((r) => setTimeout(r, 2200)); // rate-limit friendly
    } catch (e) {
      onProgress?.(`AniList page ${page} failed: ${(e as Error).message}`);
      break;
    }
  }
  return results.slice(0, limit);
}

function audioMatches(title: string, mode: string): boolean {
  const t = title.toLowerCase();
  const hasDub = /dub|multi.?audio|dual.?audio|eng.?dub/i.test(t);
  if (mode === 'dub') return hasDub;
  if (mode === 'multi') return /multi.?audio|dual.?audio|dub.*sub|sub.*dub/i.test(t);
  if (mode === 'both') return true; // sub + dub variants both accepted
  return !hasDub; // 'sub' = subtitled/original audio only
}

/** Search Nyaa's RSS for one anime title and return suitable single-episode torrents. */
export async function searchNyaaForAnime(
  title: string,
  onProgress?: (msg: string) => void
): Promise<NyaaRssItem[]> {
  const cfg = await getConfig();
  const q = encodeURIComponent(title.replace(/[^\p{L}\p{N} \-]/gu, ' ').trim());
  const url = `https://nyaa.si/?page=rss&q=${q}&c=1_2&f=0`;
  try {
    const res = await fetch(url, {
      headers: { 'User-Agent': 'RumbleAutoUploader/1.0 (bulk catalog)' },
      signal: AbortSignal.timeout(30_000),
    });
    if (!res.ok) throw new Error(`Nyaa HTTP ${res.status}`);
    const items = parseNyaaRss(await res.text());
    const maxBytes = cfg.rssMaxSizeGb > 0 ? cfg.rssMaxSizeGb * 1024 ** 3 : Infinity;
    return items
      .filter((it) => passesSourceFilters(it, cfg))
      .filter((it) => audioMatches(it.title, cfg.bulkAudioMode))
      .filter((it) => (it.seeders || 0) >= cfg.bulkMinSeeders)
      .filter((it) => {
        const bytes = parseSizeToBytes(it.size);
        return bytes === 0 || bytes <= maxBytes;
      })
      .filter((it) => {
        const t = it.title.toLowerCase();
        return !/\b(batch|complete|season\s*\d?\s*-\s*\d|bluray|bdrip|bdiso|remux|boxset)\b/.test(t);
      })
      // Resolution policy: 1080p preferred, 720p fallback, nothing else.
      .filter((it) => {
        const res = it.resolution || titleResolution(it.title);
        return !res || isAcceptedResolution(res);
      })
      .sort((a, b) => {
        const rank = (x: NyaaRssItem) => ({ '1080p': 2, '720p': 1 } as Record<string, number>)[x.resolution || titleResolution(x.title) || ''] ?? 0;
        return rank(b) - rank(a) || (b.seeders || 0) - (a.seeders || 0);
      })
      // Keep only the best release per episode (sorted best-first above).
      .filter((it, idx, arr) => {
        const key = episodeKey(it.title, it.episodeNumber);
        if (!key) return true;
        return arr.findIndex((o) => episodeKey(o.title, o.episodeNumber) === key) === idx;
      });
  } catch (e) {
    onProgress?.(`Nyaa search failed for "${title}": ${(e as Error).message}`);
    return [];
  }
}

async function log(msg: string) {
  console.log(`[bulk] ${msg}`);
  await db.insert(schedulerLogs).values({ level: 'info', message: `[bulk] ${msg}` });
}

/**
 * Discover the top-N popular anime on Nyaa and store matching torrents as feed items.
 * Runs in the background; processes one title at a time to be polite to both APIs.
 */
export async function discoverPopularCatalog(): Promise<{ anime: number; itemsFound: number; itemsNew: number }> {
  const cfg = await getConfig();
  const limit = Math.max(1, Math.min(10_000, cfg.bulkMaxAnime || 25));
  const perAnime = Math.max(1, Math.min(26, cfg.bulkEpisodesPerAnime || 1));
  await log(`Starting bulk discovery: top ${limit} popular anime, up to ${perAnime} torrents each (audio: ${cfg.bulkAudioMode}).`);

  const titles = await fetchPopularAnime(limit, (m) => log(m));
  await log(`Fetched ${titles.length} popular anime titles from AniList.`);

  let itemsFound = 0;
  let itemsNew = 0;

  for (let i = 0; i < titles.length; i++) {
    const anime = titles[i];
    const candidates = await searchNyaaForAnime(anime.english || anime.title, (m) => log(m));
    const chosen = candidates.slice(0, perAnime);
    itemsFound += chosen.length;

    if (chosen.length > 0) {
      const inserted = await storeFeedItems(chosen, `anilist-popular:${anime.id}`);
      itemsNew += inserted;
      await log(`#${i + 1}/${titles.length} ${anime.english || anime.title}: ${chosen.length} torrents found, ${inserted} new.`);
    } else {
      await log(`#${i + 1}/${titles.length} ${anime.english || anime.title}: no suitable torrent found.`);
    }
    // Be polite to Nyaa between searches.
    await new Promise((r) => setTimeout(r, 1200));
  }

  await log(`Bulk discovery complete: ${titles.length} anime scanned, ${itemsFound} torrents found, ${itemsNew} new items queued.`);
  return { anime: titles.length, itemsFound, itemsNew };
}
