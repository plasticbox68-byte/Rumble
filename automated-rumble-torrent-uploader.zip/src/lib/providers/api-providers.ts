import crypto from 'crypto';
import fs from 'fs/promises';
import path from 'path';
import {
  type Provider,
  type PlatformCreds,
  postMultipart,
  readJson,
  requireFields,
  slugify,
  tusUpload,
  getPlatformsConfig,
  savePlatformsConfig,
} from './core';

// ======================= Dailymotion =======================
// Logs in with your browser session cookies (no API key needed). The site's own
// v2 token is used for /v2 upload endpoints and /v1/rest subtitle endpoints, exactly
// like Dailymotion Studio. Expired tokens are refreshed by loading the site with the
// refresh cookie; Dailymotion rotates the refresh token, so new cookies are saved at once.
type ExportCookie = {
  name: string;
  value: string;
  domain: string;
  path?: string;
  expirationDate?: number;
  httpOnly?: boolean;
  secure?: boolean;
  sameSite?: string | null;
};
const DM_HEADERS = { Origin: 'https://www.dailymotion.com', Referer: 'https://www.dailymotion.com/' };

function dmCookies(c: PlatformCreds): ExportCookie[] {
  const raw = (c.cookies || '').trim();
  if (!raw) throw new Error('Dailymotion: paste your dailymotion.com cookies (Cookie-Editor → Export → JSON)');
  try {
    const arr = JSON.parse(raw);
    if (Array.isArray(arr)) return arr as ExportCookie[];
  } catch {
    /* fall through */
  }
  throw new Error('Dailymotion: cookies must be the JSON export from Cookie-Editor');
}

function jwtExp(token: string): number {
  try {
    return Number(JSON.parse(Buffer.from(token.split('.')[1], 'base64url').toString('utf8')).exp) || 0;
  } catch {
    return 0;
  }
}

async function dmRefresh(c: PlatformCreds, cookies: ExportCookie[]): Promise<ExportCookie[]> {
  const { launchBrowser } = await import('../rumble-browser');
  const browser = await launchBrowser(true);
  try {
    const ctx = await browser.newContext({
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36',
    });
    await ctx.addCookies(
      cookies
        .filter((ck) => ck.name !== 'access_token_v2')
        .map((ck) => ({
          name: ck.name,
          value: ck.value,
          domain: ck.domain,
          path: ck.path || '/',
          expires: ck.expirationDate ? Math.floor(ck.expirationDate) : -1,
          httpOnly: !!ck.httpOnly,
          secure: ck.secure !== false || ck.sameSite === 'no_restriction',
          sameSite: (ck.sameSite === 'strict' ? 'Strict' : ck.sameSite === 'no_restriction' ? 'None' : 'Lax') as 'Strict' | 'None' | 'Lax',
        }))
    );
    const page = await ctx.newPage();
    await page.goto('https://www.dailymotion.com/partner', { waitUntil: 'domcontentloaded', timeout: 60_000 }).catch(() => {});
    let fresh: ExportCookie[] = [];
    for (let i = 0; i < 15; i++) {
      await page.waitForTimeout(1000);
      const all = await ctx.cookies();
      if (all.some((ck) => ck.name === 'access_token_v2')) {
        fresh = all
          .filter((ck) => ck.domain.includes('dailymotion.com'))
          .map((ck) => ({
            name: ck.name,
            value: ck.value,
            domain: ck.domain,
            path: ck.path,
            expirationDate: ck.expires > 0 ? ck.expires : undefined,
            httpOnly: ck.httpOnly,
            secure: ck.secure,
            sameSite: ck.sameSite === 'None' ? 'no_restriction' : ck.sameSite === 'Strict' ? 'strict' : 'lax',
          }));
        break;
      }
    }
    if (!fresh.length) throw new Error('Dailymotion: session expired — sign in again and export fresh cookies');
    // Save immediately: the old refresh token is no longer valid after rotation.
    const cfg = await getPlatformsConfig();
    cfg.dailymotion = { ...(cfg.dailymotion || {}), ...c, cookies: JSON.stringify(fresh) };
    await savePlatformsConfig(cfg);
    return fresh;
  } finally {
    await browser.close().catch(() => {});
  }
}

async function dmAuth(c: PlatformCreds): Promise<{ token: string; creds: PlatformCreds }> {
  let cookies = dmCookies(c);
  let token = cookies.find((ck) => ck.name === 'access_token_v2')?.value || '';
  if (!token || jwtExp(token) * 1000 < Date.now() + 5 * 60_000) {
    cookies = await dmRefresh(c, cookies);
    token = cookies.find((ck) => ck.name === 'access_token_v2')?.value || '';
  }
  return { token, creds: { ...c, cookies: JSON.stringify(cookies) } };
}

async function dmUploadFile(token: string, filePath: string, contentType: string): Promise<string> {
  const session = await readJson(
    await fetch('https://api.dailymotion.com/v2/files/upload_sessions', {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, ...DM_HEADERS },
    }),
    'Dailymotion upload session'
  );
  if (!session.upload_url) throw new Error(`Dailymotion: no upload URL (${JSON.stringify(session).slice(0, 200)})`);
  const sent = await postMultipart(String(session.upload_url), {}, { field: 'file', path: filePath, contentType });
  let j: { url?: string } = {};
  try {
    j = JSON.parse(sent.body);
  } catch {
    /* handled below */
  }
  if (!j.url) throw new Error(`Dailymotion file upload failed (HTTP ${sent.status}): ${sent.body.slice(0, 200)}`);
  return j.url;
}

export const dailymotion: Provider = {
  id: 'dailymotion',
  name: 'Dailymotion',
  site: 'https://www.dailymotion.com',
  mode: 'api',
  subtitleSupport: 'upload',
  setup: 'Just export your dailymotion.com cookies while signed in — no API key needed. Tokens refresh automatically.',
  difficulty: 'easy',
  steps: [
    'Sign in at https://www.dailymotion.com.',
    'With Cookie-Editor open on dailymotion.com, click Export → JSON and paste it below.',
    'Make sure the export contains "access_token_v2" and "refresh_token_v2". The app refreshes the login by itself and saves the new cookies, so you only paste once.',
  ],
  fields: [
    { key: 'cookies', label: 'dailymotion.com cookies (JSON export)', type: 'textarea', required: true },
    {
      key: 'category',
      label: 'Category',
      placeholder: 'tv',
      help: 'One of: tv, fun, kids, creation, lifestyle, music, news, people, school, sport, tech, travel, videogames',
    },
  ],
  async test(c) {
    const { token } = await dmAuth(c);
    const me = await readJson(await fetch('https://api.dailymotion.com/v2/me', { headers: { Authorization: `Bearer ${token}`, ...DM_HEADERS } }), 'Dailymotion');
    if (!me.user_id) throw new Error(`Dailymotion: ${JSON.stringify(me).slice(0, 200)}`);
    return `Signed in as ${me.username} (profile ${me.user_id})`;
  },
  async upload(input, c) {
    const { token, creds } = await dmAuth(c);
    const auth = { Authorization: `Bearer ${token}`, ...DM_HEADERS };
    const me = await readJson(await fetch('https://api.dailymotion.com/v2/me', { headers: auth }), 'Dailymotion');
    const profile = String(me.user_id || '');
    if (!profile) throw new Error('Dailymotion: could not read your profile id');

    input.onProgress?.('Uploading file to Dailymotion...');
    const fileUrl = await dmUploadFile(token, input.videoPath, 'video/mp4');
    const created = await readJson(
      await fetch(`https://api.dailymotion.com/v2/profiles/${profile}/videos`, {
        method: 'POST',
        headers: { ...auth, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: input.title.slice(0, 255),
          description: input.description.slice(0, 3000),
          tags: input.tags.slice(0, 10),
          category: c.category || 'tv',
          visibility: 'public',
          is_for_kids: false,
          source: { file_url: fileUrl },
        }),
      }),
      'Dailymotion create video'
    );
    const id = String(created.video_id || created.id || '');
    if (!id) throw new Error(`Dailymotion create failed: ${JSON.stringify(created.error || created).slice(0, 300)}`);

    // Subtitles: upload each SRT to Dailymotion's upload server, then attach it to the video.
    const tracks = input.tracks || [];
    let ok = 0;
    const failed: string[] = [];
    for (const t of tracks.slice(0, 20)) {
      input.onProgress?.(`Adding ${t.label} subtitles on Dailymotion...`);
      try {
        const { trackToTempFile } = await import('../subtitle-store');
        const tmp = await trackToTempFile(t, 'srt');
        const subUrl = await dmUploadFile(token, tmp, 'application/x-subrip');
        const res = await fetch(`https://api.dailymotion.com/v1/rest/video/${id}/subtitles`, {
          method: 'POST',
          headers: { ...auth, 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams({ url: subUrl, language: t.lang, format: 'SRT' }),
        });
        const j = await readJson(res, 'Dailymotion subtitles');
        if (j.error) throw new Error(JSON.stringify(j.error).slice(0, 160));
        ok++;
      } catch (e) {
        failed.push(`${t.lang}: ${(e as Error).message}`);
      }
    }
    return {
      url: `https://www.dailymotion.com/video/${id}`,
      embedUrl: `https://www.dailymotion.com/embed/video/${id}`,
      remoteId: id,
      subtitleStatus: tracks.length === 0 ? 'none' : ok === tracks.length ? 'done' : ok > 0 ? 'partial' : 'error',
      subtitleNote: tracks.length ? `${ok}/${tracks.length} subtitle tracks added${failed.length ? ` — ${failed.slice(0, 2).join('; ')}` : ''}` : undefined,
      updatedCreds: creds,
    };
  },
};

// ======================= OK.ru (Odnoklassniki) =======================
// Docs: https://apiok.ru/en/dev/examples/video_upload
async function okCall(c: PlatformCreds, method: string, params: Record<string, string> = {}) {
  requireFields(c, ['applicationKey', 'applicationSecret', 'accessToken'], 'OK.ru');
  const all: Record<string, string> = { application_key: c.applicationKey, format: 'json', method, ...params };
  const secret = crypto.createHash('md5').update(c.accessToken + c.applicationSecret).digest('hex');
  const base = Object.keys(all)
    .sort()
    .map((k) => `${k}=${all[k]}`)
    .join('');
  const sig = crypto.createHash('md5').update(base + secret).digest('hex').toLowerCase();
  const res = await fetch('https://api.ok.ru/fb.do', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ ...all, access_token: c.accessToken, sig }),
  });
  const text = await res.text();
  let json: unknown = text;
  try {
    json = JSON.parse(text);
  } catch {
    /* some methods return an empty body */
  }
  if (json && typeof json === 'object' && 'error_code' in (json as Record<string, unknown>)) {
    const j = json as Record<string, unknown>;
    throw new Error(`OK.ru ${method} error ${j.error_code}: ${j.error_msg}`);
  }
  return json;
}

export const okru: Provider = {
  id: 'okru',
  name: 'OK.ru',
  site: 'https://ok.ru',
  mode: 'api',
  subtitleSupport: 'hardsub',
  setup: 'Needs a developer app plus manual approval from OK.ru support — expect to wait a few days.',
  difficulty: 'hard',
  steps: [
    'Sign in at https://ok.ru and make sure your profile has a confirmed email address (app keys are emailed to you).',
    'Open https://ok.ru/devaccess and click "Получить права разработчика" (Get developer rights).',
    'Create an app at https://apiok.ru/dev/app/create (or Games → My uploaded → Add app). Choose type "External" (Внешнее) and enable the OAuth platform. The Application ID, public key and secret key arrive by email.',
    'Email api-support@ok.ru with your Application ID and ask for these permissions: VALUABLE_ACCESS, VIDEO_CONTENT, LONG_ACCESS_TOKEN (say it is for uploading your videos). Writing in Russian helps. Approval usually takes a few days.',
    'Only AFTER approval: open your app settings ("Изменить настройки приложения"), scroll to the bottom and click "Получить Access Token" (Get access token). Approval resets the token, so don\'t do this earlier.',
    'Paste the public key, secret key and access token below.',
  ],
  fields: [
    { key: 'applicationKey', label: 'Application key (public)', required: true },
    { key: 'applicationSecret', label: 'Application secret key', type: 'password', required: true },
    { key: 'accessToken', label: 'Access token', type: 'password', required: true },
    { key: 'groupId', label: 'Group ID (optional)', help: 'Upload into a group instead of your profile' },
  ],
  async test(c) {
    const me = (await okCall(c, 'users.getCurrentUser')) as Record<string, unknown>;
    return `Connected as ${me.name || me.uid}`;
  },
  async upload(input, c) {
    const { size } = await fs.stat(input.videoPath);
    const params: Record<string, string> = { file_name: path.basename(input.videoPath), file_size: String(size) };
    if (c.groupId) params.gid = c.groupId;
    const slot = (await okCall(c, 'video.getUploadUrl', params)) as { upload_url?: string; video_id?: number | string };
    if (!slot.upload_url || !slot.video_id) throw new Error(`OK.ru: no upload URL (${JSON.stringify(slot).slice(0, 200)})`);
    input.onProgress?.('Uploading file to OK.ru...');
    const sent = await postMultipart(slot.upload_url, {}, { field: 'data', path: input.videoPath });
    if (sent.status >= 400) throw new Error(`OK.ru file upload failed (HTTP ${sent.status}): ${sent.body.slice(0, 200)}`);
    const vid = String(slot.video_id);
    // The video stays hidden until video.update is called.
    await okCall(c, 'video.update', {
      vid,
      title: input.title.slice(0, 200),
      description: input.description.slice(0, 2000),
      tags: input.tags.slice(0, 10).join(','),
    });
    return { url: `https://ok.ru/video/${vid}`, embedUrl: `https://ok.ru/videoembed/${vid}`, remoteId: vid };
  },
};

// ======================= Odysee (LBRY) =======================
// Uses Odysee's resumable publish endpoint (tus) + JSON-RPC "publish".
const ODYSEE_PUBLISH = 'https://api.na-backend.odysee.com/api/v2/publish/';
const ODYSEE_PROXY = 'https://api.na-backend.odysee.com/api/v1/proxy';

/** Accept a Cookie-Editor JSON export, a "a=b; c=d" cookie header, or the bare token. */
function odyseeToken(c: PlatformCreds): string {
  const raw = (c.cookies || c.authToken || '').trim();
  if (!raw) throw new Error('Odysee: paste your odysee.com cookies (or the auth_token value) in Platforms settings');
  if (raw.startsWith('[') || raw.startsWith('{')) {
    try {
      const parsed = JSON.parse(raw);
      const arr: { name?: string; value?: string }[] = Array.isArray(parsed) ? parsed : parsed.cookies || [];
      const hit = arr.find((ck) => ck.name === 'auth_token');
      if (hit?.value) return hit.value;
    } catch {
      /* fall through */
    }
    throw new Error('Odysee: no "auth_token" cookie in the export — make sure you were signed in to odysee.com when exporting');
  }
  const m = raw.match(/(?:^|;\s*)auth_token=([^;\s]+)/);
  if (m) return m[1];
  if (/^[A-Za-z0-9_-]{20,}$/.test(raw)) return raw;
  throw new Error('Odysee: could not find auth_token in what was pasted');
}

async function odyseeChannels(token: string): Promise<{ claim_id: string; name: string }[]> {
  const res = await fetch(`${ODYSEE_PROXY}?m=channel_list`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Lbry-Auth-Token': token },
    body: JSON.stringify({ jsonrpc: '2.0', method: 'channel_list', params: { page: 1, page_size: 50 }, id: Date.now() }),
  });
  const j = await readJson(res, 'Odysee');
  if (j.error) {
    const msg = (j.error as { message?: string }).message || JSON.stringify(j.error);
    throw new Error(/authenticate/i.test(msg) ? 'Odysee: sign-in expired — export fresh cookies' : `Odysee: ${msg}`);
  }
  const items = ((j.result as { items?: { claim_id: string; name: string }[] })?.items || []).filter((i) => i.claim_id);
  return items;
}

async function odyseeChannelId(c: PlatformCreds, token: string): Promise<string> {
  const wanted = (c.channelId || '').trim().replace(/^@/, '');
  const channels = await odyseeChannels(token);
  if (channels.length === 0) throw new Error('Odysee: your account has no channel yet — create one at odysee.com first');
  if (!wanted) return channels[0].claim_id;
  const hit = channels.find((ch) => ch.claim_id === wanted || ch.claim_id.startsWith(wanted) || ch.name.replace(/^@/, '') === wanted);
  if (!hit) throw new Error(`Odysee: channel "${wanted}" not found. Your channels: ${channels.map((ch) => ch.name).join(', ')}`);
  return hit.claim_id;
}

export const odysee: Provider = {
  id: 'odysee',
  name: 'Odysee',
  site: 'https://odysee.com',
  mode: 'api',
  subtitleSupport: 'hardsub',
  setup: 'Just export your odysee.com cookies (like you did for Rumble). Your channel is detected automatically.',
  difficulty: 'easy',
  steps: [
    'Sign in at https://odysee.com. If you don\'t have a channel yet, create one (click your avatar → New channel).',
    'With the Cookie-Editor extension open on odysee.com, click Export → JSON and paste it below. The app finds the auth_token cookie itself.',
    'Leave "Channel" empty to use your first channel, or type the channel name (e.g. @MyAnime) to pick a specific one.',
    'Publishing locks a tiny deposit of 0.001 LBC per video. Check your balance at https://odysee.com/$/wallet and add a little LBC if it is 0.',
  ],
  fields: [
    {
      key: 'cookies',
      label: 'odysee.com cookies (JSON export) or auth_token',
      type: 'textarea',
      required: true,
      help: 'Cookie-Editor → Export → JSON. A bare auth_token value also works.',
    },
    { key: 'channelId', label: 'Channel (optional)', placeholder: '@MyChannel', help: 'Empty = your first channel' },
    { key: 'bid', label: 'Deposit per video (LBC)', placeholder: '0.001' },
  ],
  async test(c) {
    const token = odyseeToken(c);
    const channels = await odyseeChannels(token);
    if (channels.length === 0) return 'Signed in, but no channel yet — create one on odysee.com';
    const chosen = await odyseeChannelId(c, token);
    const name = channels.find((ch) => ch.claim_id === chosen)?.name;
    return `Signed in. Uploading to ${name} (channels: ${channels.map((ch) => ch.name).join(', ')})`;
  },
  async upload(input, c) {
    const token = odyseeToken(c);
    const channelId = await odyseeChannelId(c, token);
    const headers = { 'X-Lbry-Auth-Token': token };
    input.onProgress?.('Uploading file to Odysee...');
    const location = await tusUpload({ endpoint: ODYSEE_PUBLISH, filePath: input.videoPath, headers });
    const name = `${slugify(input.title, 50)}-${crypto.randomBytes(3).toString('hex')}`;
    const res = await fetch(`${location.replace(/\/$/, '')}/notify`, {
      method: 'POST',
      headers: { ...headers, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        jsonrpc: '2.0',
        method: 'publish',
        id: Date.now(),
        params: {
          name,
          title: input.title.slice(0, 200),
          description: input.description,
          bid: c.bid || '0.001',
          channel_id: channelId,
          tags: input.tags.slice(0, 10),
          languages: ['en'],
          optimize_file: false,
        },
      }),
      signal: AbortSignal.timeout(10 * 60_000),
    });
    const j = await readJson(res, 'Odysee publish');
    if (j.error) {
      const msg = JSON.stringify(j.error);
      if (/insufficient|not enough|balance/i.test(msg)) throw new Error('Odysee: not enough LBC for the 0.001 deposit — add LBC at odysee.com/$/wallet');
      throw new Error(`Odysee publish failed: ${msg.slice(0, 300)}`);
    }
    const result = j.result as { outputs?: { name?: string; claim_id?: string }[] } | undefined;
    const out = result?.outputs?.find((o) => o.claim_id) || result?.outputs?.[0];
    if (!out?.claim_id) throw new Error(`Odysee publish returned no claim: ${JSON.stringify(j).slice(0, 300)}`);
    const claimName = out.name || name;
    return {
      url: `https://odysee.com/${claimName}:${out.claim_id}`,
      embedUrl: `https://odysee.com/$/embed/${claimName}/${out.claim_id}`,
      remoteId: out.claim_id,
    };
  },
};

// ======================= Byse (formerly Filemoon) =======================
const BYSE_API = 'https://api.byse.sx';

export const byse: Provider = {
  id: 'byse',
  name: 'Byse',
  site: 'https://byse.sx',
  mode: 'api',
  subtitleSupport: 'embed',
  setup: 'Copy the API key from your Byse account settings.',
  difficulty: 'easy',
  steps: ['Sign in at https://byse.sx.', 'Open Settings → API (or the API docs page) and copy your API key.', 'Paste it below and click Test connection.'],
  fields: [{ key: 'apiKey', label: 'API key', type: 'password', required: true }],
  async test(c) {
    requireFields(c, ['apiKey'], 'Byse');
    const j = await readJson(await fetch(`${BYSE_API}/account/info?key=${encodeURIComponent(c.apiKey)}`), 'Byse');
    if (Number(j.status) !== 200) throw new Error(`Byse: ${j.msg || 'invalid key'}`);
    const r = (j.result || {}) as Record<string, unknown>;
    return `Connected as ${r.login || r.email || 'Byse account'}`;
  },
  async upload(input, c) {
    requireFields(c, ['apiKey'], 'Byse');
    const srv = await readJson(await fetch(`${BYSE_API}/upload/server?key=${encodeURIComponent(c.apiKey)}`), 'Byse upload server');
    if (Number(srv.status) !== 200 || typeof srv.result !== 'string') throw new Error(`Byse: ${srv.msg || 'no upload server'}`);
    input.onProgress?.('Uploading file to Byse...');
    const sent = await postMultipart(srv.result, { key: c.apiKey }, { field: 'file', path: input.videoPath });
    let j: { files?: { filecode?: string; status?: string }[]; msg?: string; result?: unknown } = {};
    try {
      j = JSON.parse(sent.body);
    } catch {
      throw new Error(`Byse upload failed (HTTP ${sent.status}): ${sent.body.slice(0, 200)}`);
    }
    const code = j.files?.[0]?.filecode;
    if (!code) throw new Error(`Byse upload failed: ${j.msg || sent.body.slice(0, 200)}`);
    const n = input.tracks?.length || 0;
    return {
      url: `https://byse.sx/d/${code}`,
      embedUrl: `https://byse.sx/e/${code}`,
      remoteId: code,
      subtitleStatus: n ? 'done' : 'none',
      subtitleNote: n ? `${n} subtitle tracks attached through the player link (hosted by this app)` : undefined,
    };
  },
};

// ======================= VidShared =======================
// Docs: https://api.vidshared.com (OpenAPI). Create → upload ticket → tus.
const VIDSHARED_API = 'https://api.vidshared.com/v1';

export const vidshared: Provider = {
  id: 'vidshared',
  name: 'VidShared',
  site: 'https://vidshared.com',
  mode: 'api',
  subtitleSupport: 'deferred',
  setup: 'Copy the API key from your VidShared account page.',
  difficulty: 'easy',
  steps: [
    'Sign in at https://vidshared.com.',
    'Open Account → API key and copy it.',
    'Optional: if your share links use a different player domain, put it in "Player link template" with {code} where the video ID goes.',
  ],
  fields: [
    { key: 'apiKey', label: 'API key', type: 'password', required: true },
    { key: 'playerUrl', label: 'Player link template', placeholder: 'https://vidembed.online/e/{code}', help: 'Use {code} for the Play ID' },
  ],
  async test(c) {
    requireFields(c, ['apiKey'], 'VidShared');
    const res = await fetch(`${VIDSHARED_API}/files?limit=1`, { headers: { 'X-Api-Key': c.apiKey } });
    if (res.status === 401 || res.status === 403) throw new Error('VidShared rejected the API key');
    await readJson(res, 'VidShared');
    return 'API key accepted';
  },
  async upload(input, c) {
    requireFields(c, ['apiKey'], 'VidShared');
    const auth = { 'X-Api-Key': c.apiKey, 'Content-Type': 'application/json' };
    const created = await readJson(
      await fetch(`${VIDSHARED_API}/files`, {
        method: 'POST',
        headers: auth,
        body: JSON.stringify({ title: input.title.slice(0, 200) }),
      }),
      'VidShared create'
    );
    const code = created.code as string | undefined;
    if (!code) throw new Error(`VidShared create failed: ${JSON.stringify(created).slice(0, 200)}`);
    const ticket = await readJson(
      await fetch(`${VIDSHARED_API}/files/${code}/upload-ticket`, { method: 'POST', headers: auth }),
      'VidShared upload ticket'
    );
    const node = ticket.node as { url?: string } | undefined;
    if (!node?.url || !ticket.token) throw new Error(`VidShared ticket failed: ${JSON.stringify(ticket).slice(0, 200)}`);
    input.onProgress?.('Uploading file to VidShared...');
    await tusUpload({
      endpoint: node.url,
      filePath: input.videoPath,
      metadata: {
        token: String(ticket.token),
        brand_ref: String(ticket.brand_ref ?? ''),
        filename: path.basename(input.videoPath),
      },
    });
    const link = (c.playerUrl || 'https://vidembed.online/e/{code}').replace('{code}', code);
    const tracks = input.tracks || [];
    // VidShared only accepts subtitles once the video is ready; usually that is a few
    // minutes after upload, so the scheduler retries until they are attached.
    let sub: { status: string; note: string } = { status: 'none', note: '' };
    if (tracks.length) sub = await vidshared.attachSubtitles!(code, tracks, c);
    return { url: link, embedUrl: link, remoteId: code, subtitleStatus: sub.status, subtitleNote: sub.note || undefined };
  },
  async attachSubtitles(code, tracks, c) {
    requireFields(c, ['apiKey'], 'VidShared');
    const f = await readJson(await fetch(`${VIDSHARED_API}/files/${code}`, { headers: { 'X-Api-Key': c.apiKey } }), 'VidShared');
    const state = String(f.core_state || '');
    if (state === 'failed') return { status: 'error', note: 'VidShared failed to process the video' };
    if (!state.startsWith('ready')) return { status: 'pending', note: `Waiting for VidShared to finish processing (${state || 'unknown'})` };
    const { trackToTempFile } = await import('../subtitle-store');
    let ok = 0;
    const failed: string[] = [];
    for (const [i, t] of tracks.slice(0, 20).entries()) {
      const tmp = await trackToTempFile(t, 'srt');
      const res = await postMultipart(
        `${VIDSHARED_API}/subtitles/${code}`,
        { language: t.lang, label: t.label, default: String(i === 0) },
        { field: 'file', path: tmp, contentType: 'application/x-subrip' },
        { 'X-Api-Key': c.apiKey }
      );
      if (res.status < 300 || /duplicate|already/i.test(res.body)) ok++;
      else failed.push(`${t.lang}: HTTP ${res.status} ${res.body.slice(0, 120)}`);
    }
    return {
      status: ok === Math.min(tracks.length, 20) ? 'done' : ok > 0 ? 'partial' : 'error',
      note: `${ok}/${Math.min(tracks.length, 20)} subtitle tracks added${failed.length ? ` — ${failed.slice(0, 2).join('; ')}` : ''}`,
    };
  },
};

export const apiProviders: Provider[] = [dailymotion, okru, odysee, byse, vidshared];
