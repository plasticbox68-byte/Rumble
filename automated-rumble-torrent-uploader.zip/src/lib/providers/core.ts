import FormData from 'form-data';
import { createReadStream } from 'fs';
import fs from 'fs/promises';
import path from 'path';
import { db } from '@/db';
import { settings } from '@/db/schema';
import { eq } from 'drizzle-orm';
import type { SubtitleTrack } from '@/db/schema';

export type MirrorInput = {
  videoPath: string;
  title: string;
  description: string;
  tags: string[];
  /** 2-letter language code -> subtitle file path */
  subtitles: Record<string, string>;
  /** The same subtitles stored in the DB (English first). */
  tracks?: SubtitleTrack[];
  onProgress?: (msg: string) => void;
};

export type MirrorResult = {
  url: string;
  embedUrl?: string | null;
  remoteId?: string | null;
  /** done | partial | pending | error | unsupported | none */
  subtitleStatus?: string;
  subtitleNote?: string;
  /** Credentials changed during the upload (e.g. rotated session tokens) — saved automatically. */
  updatedCreds?: PlatformCreds;
};

/**
 * How a platform receives subtitles:
 *  upload   — caption files are sent during the upload
 *  deferred — sent later, once the platform finishes processing the video
 *  embed    — player loads subtitle links hosted by this app
 *  hardsub  — no caption support: the English hard-sub video is uploaded instead
 */
export type SubtitleSupport = 'upload' | 'deferred' | 'embed' | 'hardsub';

export type FieldDef = {
  key: string;
  label: string;
  type?: 'text' | 'password' | 'textarea';
  placeholder?: string;
  help?: string;
  required?: boolean;
};

export type PlatformCreds = Record<string, string> & { enabled?: string };

export type Provider = {
  id: string;
  name: string;
  site: string;
  mode: 'api' | 'browser';
  experimental?: boolean;
  setup: string;
  /** How hard it is to get the credentials. */
  difficulty: 'easy' | 'medium' | 'hard';
  /** Numbered how-to steps shown in the UI (may contain URLs). */
  steps: string[];
  fields: FieldDef[];
  subtitleSupport: SubtitleSupport;
  upload: (input: MirrorInput, creds: PlatformCreds) => Promise<MirrorResult>;
  test: (creds: PlatformCreds) => Promise<string>;
  /** For 'deferred' platforms: try to attach subtitles to an existing upload. */
  attachSubtitles?: (
    remoteId: string,
    tracks: SubtitleTrack[],
    creds: PlatformCreds
  ) => Promise<{ status: 'done' | 'partial' | 'pending' | 'error'; note: string }>;
};

// ---------- per-platform settings (stored as JSON in the settings table) ----------

const SETTINGS_KEY = 'platforms';

export type PlatformsConfig = Record<string, PlatformCreds>;

export async function getPlatformsConfig(): Promise<PlatformsConfig> {
  const [row] = await db.select().from(settings).where(eq(settings.key, SETTINGS_KEY)).limit(1);
  if (!row?.value) return {};
  try {
    return JSON.parse(row.value) as PlatformsConfig;
  } catch {
    return {};
  }
}

export async function savePlatformsConfig(cfg: PlatformsConfig): Promise<PlatformsConfig> {
  const value = JSON.stringify(cfg);
  const [row] = await db.select().from(settings).where(eq(settings.key, SETTINGS_KEY)).limit(1);
  if (row) {
    await db.update(settings).set({ value, updatedAt: new Date() }).where(eq(settings.key, SETTINGS_KEY));
  } else {
    await db.insert(settings).values({ key: SETTINGS_KEY, value });
  }
  return cfg;
}

export function requireFields(creds: PlatformCreds, keys: string[], platform: string) {
  const missing = keys.filter((k) => !creds[k] || !String(creds[k]).trim());
  if (missing.length) throw new Error(`${platform}: missing ${missing.join(', ')} in Platforms settings`);
}

// ---------- HTTP helpers ----------

export async function readJson(res: Response, label: string): Promise<Record<string, unknown>> {
  const text = await res.text();
  let json: Record<string, unknown>;
  try {
    json = JSON.parse(text);
  } catch {
    throw new Error(`${label}: unexpected response (HTTP ${res.status}): ${text.slice(0, 300)}`);
  }
  return json;
}

/** Stream a file as multipart/form-data (no full read into memory). */
export function postMultipart(
  url: string,
  fields: Record<string, string>,
  file: { field: string; path: string; filename?: string; contentType?: string },
  headers: Record<string, string> = {}
): Promise<{ status: number; body: string }> {
  const form = new FormData();
  for (const [k, v] of Object.entries(fields)) form.append(k, v);
  form.append(file.field, createReadStream(file.path), {
    filename: file.filename || path.basename(file.path),
    contentType: file.contentType || 'video/mp4',
  });
  const u = new URL(url);
  return new Promise((resolve, reject) => {
    form.submit(
      {
        protocol: u.protocol as 'https:' | 'http:',
        host: u.hostname,
        port: u.port ? Number(u.port) : undefined,
        path: u.pathname + u.search,
        method: 'POST',
        headers,
      },
      (err, res) => {
        if (err) return reject(err);
        let body = '';
        res.on('data', (c: Buffer) => (body += c.toString('utf8')));
        res.on('end', () => resolve({ status: res.statusCode || 0, body }));
        res.on('error', reject);
      }
    );
  });
}

// ---------- tus 1.0.0 resumable upload client ----------

const TUS_CHUNK = 32 * 1024 * 1024;

function b64(s: string) {
  return Buffer.from(s, 'utf8').toString('base64');
}

export async function tusUpload(opts: {
  endpoint: string;
  filePath: string;
  headers?: Record<string, string>;
  metadata?: Record<string, string>;
  onProgress?: (pct: number) => void;
}): Promise<string> {
  const { size } = await fs.stat(opts.filePath);
  const metadata = Object.entries(opts.metadata || {})
    .map(([k, v]) => `${k} ${b64(v)}`)
    .join(',');
  const create = await fetch(opts.endpoint, {
    method: 'POST',
    headers: {
      'Tus-Resumable': '1.0.0',
      'Upload-Length': String(size),
      ...(metadata ? { 'Upload-Metadata': metadata } : {}),
      ...(opts.headers || {}),
    },
    signal: AbortSignal.timeout(60_000),
  });
  if (create.status !== 201) {
    throw new Error(`tus create failed (HTTP ${create.status}): ${(await create.text()).slice(0, 300)}`);
  }
  const loc = create.headers.get('location');
  if (!loc) throw new Error('tus create returned no Location header');
  const location = new URL(loc, opts.endpoint).toString();

  const fh = await fs.open(opts.filePath, 'r');
  try {
    let offset = 0;
    let failures = 0;
    while (offset < size) {
      const len = Math.min(TUS_CHUNK, size - offset);
      const buf = Buffer.alloc(len);
      await fh.read(buf, 0, len, offset);
      try {
        const res = await fetch(location, {
          method: 'PATCH',
          headers: {
            'Tus-Resumable': '1.0.0',
            'Upload-Offset': String(offset),
            'Content-Type': 'application/offset+octet-stream',
            ...(opts.headers || {}),
          },
          body: buf,
          signal: AbortSignal.timeout(10 * 60_000),
        });
        if (res.status !== 204 && res.status !== 200) {
          throw new Error(`tus PATCH failed (HTTP ${res.status}): ${(await res.text()).slice(0, 200)}`);
        }
        const next = Number(res.headers.get('upload-offset'));
        offset = Number.isFinite(next) && next > offset ? next : offset + len;
        failures = 0;
        opts.onProgress?.(Math.floor((offset / size) * 100));
      } catch (e) {
        // Give up after 5 consecutive failures; otherwise resume from the server's offset.
        if (++failures >= 5) throw e;
        const head = await fetch(location, {
          method: 'HEAD',
          headers: { 'Tus-Resumable': '1.0.0', ...(opts.headers || {}) },
        }).catch(() => null);
        const serverOffset = Number(head?.headers.get('upload-offset'));
        if (Number.isFinite(serverOffset) && serverOffset >= 0) offset = serverOffset;
        await new Promise((r) => setTimeout(r, 3000 * failures));
      }
    }
  } finally {
    await fh.close();
  }
  return location;
}

export function slugify(s: string, max = 60): string {
  return (
    s
      .toLowerCase()
      .normalize('NFKD')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '')
      .slice(0, max) || 'video'
  );
}
