import path from 'path';
import fs from 'fs/promises';
import os from 'os';
import type { SubtitleTrack } from '@/db/schema';
import { trackToTempFile } from '../subtitle-store';
import type { Page } from 'playwright';
import { launchBrowser, parseRawCookies } from '../rumble-browser';
import { DATA_DIR, ensureDirs } from '../storage';
import { type Provider, type PlatformCreds, type MirrorInput, requireFields } from './core';

const USER_AGENT =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36';

type BrowserSiteSpec = {
  id: string;
  name: string;
  domain: string; // cookie domain, e.g. ".d.tube"
  uploadUrl: string;
  loginPattern: RegExp; // URL means "not signed in"
  /** Regex that matches the finished video's public URL anywhere on the page. */
  resultPattern: RegExp;
  toUrls: (match: string) => { url: string; embedUrl?: string; remoteId?: string };
};

function siteCookies(spec: BrowserSiteSpec, raw: string) {
  // parseRawCookies() normalizes unknown domains to .rumble.com; re-home them to this site.
  return parseRawCookies(raw).map((ck) => ({
    ...ck,
    domain: !ck.domain || ck.domain.includes('rumble.com') ? spec.domain : ck.domain,
  }));
}

async function firstVisible(page: Page, selectors: string[]) {
  for (const sel of selectors) {
    const loc = page.locator(sel).first();
    if ((await loc.count()) > 0 && (await loc.isVisible().catch(() => false))) return loc;
  }
  return null;
}

async function browserUpload(spec: BrowserSiteSpec, input: MirrorInput, c: PlatformCreds) {
  requireFields(c, ['sessionCookies'], spec.name);
  const cookies = siteCookies(spec, c.sessionCookies);
  if (cookies.length === 0) throw new Error(`${spec.name}: could not parse the session cookies`);

  const browser = await launchBrowser(true);
  const context = await browser.newContext({ userAgent: USER_AGENT, viewport: { width: 1440, height: 900 } });
  await context.addCookies(cookies);
  const page = await context.newPage();
  page.setDefaultTimeout(60_000);
  try {
    await page.goto(spec.uploadUrl, { waitUntil: 'domcontentloaded', timeout: 60_000 });
    await page.waitForTimeout(3000);
    if (spec.loginPattern.test(page.url())) {
      throw new Error(`${spec.name}: session cookies are expired — export fresh cookies and save them in Platforms`);
    }
    const loginShown = (await page.locator('button, a').filter({ hasText: /^(log ?in|sign ?in)$/i }).count()) > 0;
    if (loginShown && (await page.locator('input[type="file"]').count()) === 0) {
      throw new Error(`${spec.name}: not signed in — sign in on the site, then export cookies again`);
    }

    const fileInput = page.locator('input[type="file"][accept*="video"], input[type="file"]').first();
    await fileInput.waitFor({ state: 'attached', timeout: 60_000 });
    input.onProgress?.(`Selecting file on ${spec.name}...`);
    await fileInput.setInputFiles(input.videoPath);

    // Fill title/description if the form exposes them.
    const titleBox = await firstVisible(page, [
      'input[name*="title" i]',
      'input[placeholder*="title" i]',
      'input[id*="title" i]',
    ]);
    if (titleBox) await titleBox.fill(input.title.slice(0, 100)).catch(() => {});
    const descBox = await firstVisible(page, ['textarea[name*="desc" i]', 'textarea[placeholder*="desc" i]', 'textarea']);
    if (descBox) await descBox.fill(input.description.slice(0, 2000)).catch(() => {});

    // Wait for the finished link, clicking a publish/save button once it is enabled.
    const deadline = Date.now() + 45 * 60_000;
    let clicked = false;
    while (Date.now() < deadline) {
      const html = await page.content();
      const inputs = await page
        .locator('input, textarea')
        .evaluateAll((els) => els.map((e) => (e as HTMLInputElement).value || '').join('\n'))
        .catch(() => '');
      const m = (html + '\n' + inputs + '\n' + page.url()).match(spec.resultPattern);
      if (m) return spec.toUrls(m[0]);
      if (!clicked) {
        const btn = await firstVisible(page, [
          'button:has-text("Publish"):not([disabled])',
          'button:has-text("Post"):not([disabled])',
          'button:has-text("Save"):not([disabled])',
          'button:has-text("Submit"):not([disabled])',
        ]);
        if (btn) {
          await btn.click().catch(() => {});
          clicked = true;
        }
      }
      await page.waitForTimeout(5000);
    }
    throw new Error(`${spec.name}: upload did not produce a video link within 45 minutes`);
  } catch (e) {
    try {
      await ensureDirs();
      await page.screenshot({ path: path.join(DATA_DIR, `${spec.id}_failure.png`), fullPage: true });
    } catch {
      /* ignore */
    }
    throw e;
  } finally {
    await browser.close().catch(() => {});
  }
}

async function browserTest(spec: BrowserSiteSpec, c: PlatformCreds) {
  requireFields(c, ['sessionCookies'], spec.name);
  const browser = await launchBrowser(true);
  try {
    const context = await browser.newContext({ userAgent: USER_AGENT });
    await context.addCookies(siteCookies(spec, c.sessionCookies));
    const page = await context.newPage();
    await page.goto(spec.uploadUrl, { waitUntil: 'domcontentloaded', timeout: 60_000 });
    await page.waitForTimeout(3000);
    if (spec.loginPattern.test(page.url())) throw new Error(`${spec.name}: not signed in — cookies are missing or expired`);
    const hasInput = (await page.locator('input[type="file"]').count()) > 0;
    const loginShown = (await page.locator('button, a').filter({ hasText: /^(log ?in|sign ?in)$/i }).count()) > 0;
    if (!hasInput && loginShown) {
      throw new Error(`${spec.name}: not signed in — these cookies contain no login session. Sign in on the site first, then export cookies again.`);
    }
    return hasInput ? 'Signed in — upload form found' : 'Signed in, but no upload form was found on the page';
  } finally {
    await browser.close().catch(() => {});
  }
}

function makeBrowserProvider(spec: BrowserSiteSpec, setup: string): Provider {
  const site = `https://${spec.domain.replace(/^\./, '')}`;
  return {
    id: spec.id,
    name: spec.name,
    site: `https://${spec.domain.replace(/^\./, '')}`,
    mode: 'browser',
    experimental: true,
    subtitleSupport: 'hardsub',
    setup,
    difficulty: 'easy',
    steps: [
      `Sign up or sign in at ${site}.`,
      `On ${site}, open the Cookie-Editor extension and click Export → JSON (the same way you did for Rumble).`,
      'Paste it below, click Save, then Test connection. If uploads start failing later, your session expired — export the cookies again.',
    ],
    fields: [
      {
        key: 'sessionCookies',
        label: 'Session cookies (JSON export)',
        type: 'textarea',
        required: true,
        help: 'Log in, then export cookies for this site with the Cookie-Editor extension (Export → JSON) and paste here.',
      },
    ],
    upload: (input, c) => browserUpload(spec, input, c),
    test: (c) => browserTest(spec, c),
  };
}

export const dtube = makeBrowserProvider(
  {
    id: 'dtube',
    name: 'DTube',
    domain: '.d.tube',
    uploadUrl: 'https://d.tube/upload',
    loginPattern: /\/(login|signin|signup)/i,
    resultPattern: /https?:\/\/d\.tube\/(?:v|video|watch|p)\/[A-Za-z0-9_\-/]+/,
    toUrls: (m) => ({ url: m, remoteId: m.split('/').pop() }),
  },
  'DTube has no public upload API, so this uses browser automation with your logged-in session. Experimental: the upload form may change.'
);

// ---------------- VdoHide (dashboard uploader + Subtitles tab) ----------------
const VH_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36';
const VH_SPEC: BrowserSiteSpec = {
  id: 'vdohide',
  name: 'VdoHide',
  domain: '.vdohide.com',
  uploadUrl: 'https://vdohide.com/dashboard',
  loginPattern: /\/(login|register)/i,
  resultPattern: /https?:\/\/fembed\.co\/embed\/[A-Za-z0-9_-]+/,
  toUrls: (m) => ({ url: m, embedUrl: m, remoteId: m.split('/').pop() }),
};

async function vhOpen(c: PlatformCreds) {
  requireFields(c, ['sessionCookies'], 'VdoHide');
  const browser = await launchBrowser(true);
  const context = await browser.newContext({ userAgent: VH_UA, viewport: { width: 1440, height: 900 } });
  await context.addCookies(siteCookies(VH_SPEC, c.sessionCookies));
  const page = await context.newPage();
  page.setDefaultTimeout(60_000);
  await page.goto('https://vdohide.com/dashboard', { waitUntil: 'networkidle', timeout: 90_000 }).catch(() => {});
  await page.waitForTimeout(2000);
  const m = page.url().match(/vdohide\.com\/(ws_[^/?#]+)/);
  if (!m) {
    await browser.close().catch(() => {});
    throw new Error('VdoHide: not signed in — export fresh cookies from vdohide.com');
  }
  return { browser, page, workspace: m[1] };
}

/** Find a file's id via its Share dialog (embed URL https://fembed.co/embed/<id>). */
async function vhFileIdByName(page: Page, fileName: string): Promise<string | null> {
  await page.goto('https://vdohide.com/dashboard', { waitUntil: 'networkidle', timeout: 90_000 }).catch(() => {});
  await page.waitForTimeout(2000);
  const actions = page.locator(`button[aria-label="File actions: ${fileName}"]`).first();
  if (!(await actions.count())) return null;
  await actions.click();
  await page.locator('[role=menuitem]', { hasText: 'Share' }).first().click();
  await page.waitForTimeout(1500);
  const text = await page.locator('[role=dialog]').first().innerText().catch(() => '');
  await page.keyboard.press('Escape').catch(() => {});
  return text.match(/fembed\.co\/embed\/([A-Za-z0-9_-]+)/)?.[1] || null;
}

async function vhAttachSubtitles(page: Page, workspace: string, fileId: string, tracks: SubtitleTrack[]) {
  if (!tracks.length) return { status: 'none', note: '' };
  await page.goto(`https://vdohide.com/${workspace}/file/${fileId}`, { waitUntil: 'networkidle', timeout: 90_000 }).catch(() => {});
  await page.waitForTimeout(2000);
  await page.locator('[role=tab]', { hasText: /Subtitles/ }).first().click();
  await page.waitForTimeout(1500);
  let ok = 0;
  const failed: string[] = [];
  for (const t of tracks.slice(0, 20)) {
    try {
      const file = await trackToTempFile(t, 'srt');
      await page.locator('input[type=file][accept*="srt"]').first().setInputFiles(file);
      await page.waitForTimeout(1500);
      const name = path.basename(file);
      // Set the language in the Review dialog (required before upload).
      const review = page.locator('button', { hasText: /^Review$/ }).last();
      if (await review.count()) {
        await review.click();
        await page.waitForTimeout(1200);
        const dialog = page.locator('[role=dialog]').last();
        const lang = dialog.locator('[role=combobox], select').first();
        if (await lang.count()) {
          const tag = await lang.evaluate((el) => el.tagName);
          if (tag === 'SELECT') {
            await lang.selectOption({ label: t.label }).catch(() => lang.selectOption({ value: t.lang }));
          } else {
            await lang.click();
            await page.keyboard.type(t.label, { delay: 30 });
            await page.waitForTimeout(600);
            const opt = page.locator('[role=option]', { hasText: new RegExp(`^${t.label}`, 'i') }).first();
            if (await opt.count()) await opt.click();
            else await page.keyboard.press('Enter');
          }
        }
        const done = dialog.locator('button', { hasText: /^(Done|Save|Apply)$/ }).first();
        if (await done.count()) await done.click();
        else await page.keyboard.press('Escape');
        await page.waitForTimeout(800);
      }
      const upload = page.locator(`button[aria-label="Upload ${name}"], button:has-text("Upload ${name}")`).first();
      const anyUpload = page.locator('button', { hasText: /^Upload$/ }).last();
      await ((await upload.count()) ? upload : anyUpload).click();
      // Wait for the success toast or an error.
      const outcome = await Promise.race([
        page.getByText(/Subtitle uploaded|uploaded$/i).first().waitFor({ timeout: 30_000 }).then(() => 'ok'),
        page.getByText(/Choose a language|already been uploaded|could not|failed/i).first().waitFor({ timeout: 30_000 }).then(() => 'err'),
      ]).catch(() => 'timeout');
      if (outcome === 'ok') ok++;
      else failed.push(`${t.lang}: ${outcome === 'err' ? (await page.getByText(/Choose a language|already been uploaded|could not|failed/i).first().innerText().catch(() => 'rejected')) : 'no confirmation'}`);
      await page.waitForTimeout(800);
    } catch (e) {
      failed.push(`${t.lang}: ${(e as Error).message.slice(0, 120)}`);
    }
  }
  const n = Math.min(tracks.length, 20);
  return {
    status: ok === n ? 'done' : ok > 0 ? 'partial' : 'error',
    note: `${ok}/${n} subtitle tracks added${failed.length ? ` — ${failed.slice(0, 2).join('; ')}` : ''}`,
  };
}

export const vdohide: Provider = {
  id: 'vdohide',
  name: 'VdoHide',
  site: 'https://vdohide.com',
  mode: 'browser',
  experimental: true,
  // VdoHide's subtitle endpoint rejects automated uploads (POST /api/v1/upload/files → 404),
  // so it receives the English hard-sub video like other sites without caption support.
  subtitleSupport: 'hardsub',
  setup: 'Export your vdohide.com cookies while signed in. Uploads go through your dashboard.',
  difficulty: 'easy',
  steps: [
    'Sign in at https://vdohide.com.',
    'With Cookie-Editor open on vdohide.com, click Export → JSON and paste it below (it must include "__Secure-auth.session_token").',
    'Click Save, then Test connection. Sign-ins last about 30 days; re-export when uploads start failing.',
  ],
  fields: [
    { key: 'sessionCookies', label: 'vdohide.com cookies (JSON export)', type: 'textarea', required: true },
  ],
  async test(c) {
    const { browser, workspace, page } = await vhOpen(c);
    try {
      const inputs = await page.locator('input[type=file][accept*="video"]').count();
      return `Signed in (workspace ${workspace})${inputs ? ' — upload form ready' : ''}`;
    } finally {
      await browser.close().catch(() => {});
    }
  },
  async upload(input, c) {
    const { browser, page, workspace } = await vhOpen(c);
    // Give the upload a recognizable file name (symlink — no copy of the video).
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'vh-'));
    const fileName = `${input.title.replace(/[\\/:*?"<>|]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 150)}.mp4`;
    const link = path.join(dir, fileName);
    await fs.symlink(input.videoPath, link);
    try {
      input.onProgress?.('Uploading file to VdoHide...');
      const saved = page.waitForResponse(
        (r) => r.url().includes('/api/v1/upload/files/save') && r.request().method() === 'POST',
        { timeout: 90 * 60_000 }
      );
      await page.locator('input[type=file][accept*="video"]:not([webkitdirectory])').first().setInputFiles(link);
      const res = await saved;
      const body = await res.text().catch(() => '');
      if (!res.ok() || /"success"\s*:\s*false/.test(body)) throw new Error(`VdoHide save failed: ${body.slice(0, 200)}`);
      // The id is usually in the save response; otherwise read it from the Share dialog.
      let fileId = body.match(/"(?:slug|fileId|file_id|code|shortId|id)"\s*:\s*"([A-Za-z0-9_-]{8,20})"/)?.[1] || null;
      if (!fileId || !/^[A-Za-z0-9_-]{8,20}$/.test(fileId)) fileId = null;
      for (let i = 0; !fileId && i < 6; i++) {
        await page.waitForTimeout(5000);
        fileId = await vhFileIdByName(page, fileName);
      }
      if (!fileId) throw new Error('VdoHide: upload saved but the video id could not be found');
      // Caption tracks are attempted only if any are passed (hard-sub mode passes none).
      const sub = input.tracks?.length ? await vhAttachSubtitles(page, workspace, fileId, input.tracks) : null;
      const url = `https://fembed.co/embed/${fileId}`;
      return { url, embedUrl: url, remoteId: fileId, subtitleStatus: sub?.status, subtitleNote: sub?.note || undefined };
    } catch (e) {
      try {
        await ensureDirs();
        await page.screenshot({ path: path.join(DATA_DIR, 'vdohide_failure.png'), fullPage: true });
      } catch {
        /* ignore */
      }
      throw e;
    } finally {
      await browser.close().catch(() => {});
      await fs.rm(dir, { recursive: true, force: true }).catch(() => {});
    }
  },
};

export const browserProviders: Provider[] = [dtube, vdohide];
