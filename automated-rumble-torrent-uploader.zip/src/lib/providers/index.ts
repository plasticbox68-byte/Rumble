import fs from 'fs/promises';
import { db } from '@/db';
import { platformUploads, downloads, feedItems } from '@/db/schema';
import { and, desc, eq } from 'drizzle-orm';
import { apiProviders } from './api-providers';
import { browserProviders } from './browser-providers';
import { type MirrorInput, type Provider, getPlatformsConfig, savePlatformsConfig } from './core';
import { storeSubtitleTracks, getSubtitleTracks, trackToTempFile } from '../subtitle-store';
import { burnSubtitles } from '../hardsub';
import path from 'path';
import { removeDownloadDir } from '../storage';

export const PROVIDERS: Provider[] = [...apiProviders, ...browserProviders];

export function getProvider(id: string): Provider | undefined {
  return PROVIDERS.find((p) => p.id === id);
}

/** Public metadata for the settings UI (no functions). */
export function providerCatalog() {
  return PROVIDERS.map(({ id, name, site, mode, experimental, setup, fields, difficulty, steps, subtitleSupport }) => ({
    id,
    name,
    site,
    mode,
    experimental: !!experimental,
    setup,
    difficulty,
    steps,
    subtitleSupport,
    fields,
  }));
}

export async function enabledProviders(): Promise<Provider[]> {
  const cfg = await getPlatformsConfig();
  return PROVIDERS.filter((p) => cfg[p.id]?.enabled === 'true');
}

/**
 * Upload one finished episode to every enabled platform, sequentially.
 * Each platform's result is stored; a failure never stops the others.
 */
export async function mirrorToPlatforms(
  ctx: { feedItemId: number; uploadId: number | null } & Omit<MirrorInput, 'onProgress'>,
  only?: string[]
): Promise<{ done: number; failed: number }> {
  const cfg = await getPlatformsConfig();
  const targets = (await enabledProviders()).filter((p) => !only || only.includes(p.id));
  let done = 0;
  let failed = 0;
  if (targets.length === 0) return { done, failed };

  // Keep every subtitle language in the DB (needed by Byse links and VidShared retries).
  const tracks = Object.keys(ctx.subtitles).length
    ? await storeSubtitleTracks(ctx.feedItemId, ctx.subtitles)
    : await getSubtitleTracks(ctx.feedItemId);

  // Platforms without caption support get the English hard-sub video (burned once, reused).
  let hardsubPath: string | null | undefined;
  const englishHardsub = async (): Promise<string | null> => {
    if (hardsubPath !== undefined) return hardsubPath;
    const en = tracks.find((t) => t.lang === 'en');
    if (!en) return (hardsubPath = null);
    try {
      const srt = ctx.subtitles.en || (await trackToTempFile(en, 'srt'));
      const outDir = path.join(path.dirname(ctx.videoPath), '._hardsubs');
      const existing = path.join(outDir, 'hardsub_en.mp4');
      const fsMod = await import('fs/promises');
      if (await fsMod.stat(existing).then((st) => st.size > 0).catch(() => false)) return (hardsubPath = existing);
      console.log(`[mirror] #${ctx.feedItemId} burning English hard-sub for platforms without caption support...`);
      return (hardsubPath = (await burnSubtitles(ctx.videoPath, srt, 'en', outDir)).outPath);
    } catch (e) {
      console.error(`[mirror] English hard-sub failed for #${ctx.feedItemId}: ${(e as Error).message}`);
      return (hardsubPath = null);
    }
  };

  for (const p of targets) {
    // Skip platforms that already have this episode.
    const existing = await db
      .select()
      .from(platformUploads)
      .where(and(eq(platformUploads.feedItemId, ctx.feedItemId), eq(platformUploads.platform, p.id), eq(platformUploads.status, 'done')))
      .limit(1);
    if (existing.length) continue;

    let videoPath = ctx.videoPath;
    let title = ctx.title;
    let forcedSubStatus: { status: string; note: string } | null = null;
    if (p.subtitleSupport === 'hardsub' && tracks.length) {
      const hs = await englishHardsub();
      if (hs) {
        videoPath = hs;
        title = `${ctx.title} [English Subbed]`.slice(0, 200);
        forcedSubStatus = { status: 'done', note: `${p.name} has no caption tracks — uploaded with English subtitles burned in` };
      } else {
        forcedSubStatus = { status: 'unsupported', note: `${p.name} has no caption tracks and this release has no English subtitles to burn in` };
      }
    }

    const [row] = await db
      .insert(platformUploads)
      .values({ feedItemId: ctx.feedItemId, uploadId: ctx.uploadId, platform: p.id, title, status: 'uploading' })
      .returning();
    console.log(`[mirror] #${ctx.feedItemId} → ${p.name}...`);
    try {
      const res = await p.upload(
        {
          ...ctx,
          videoPath,
          title,
          tracks: p.subtitleSupport === 'hardsub' ? [] : tracks,
          onProgress: (msg) => {
            db.update(platformUploads)
              .set({ errorMessage: `stage: ${msg}`, updatedAt: new Date() })
              .where(eq(platformUploads.id, row.id))
              .catch(() => {});
          },
        },
        cfg[p.id] || {}
      );
      if (res.updatedCreds) {
        const latest = await getPlatformsConfig();
        latest[p.id] = { ...(latest[p.id] || {}), ...res.updatedCreds };
        await savePlatformsConfig(latest);
      }
      const sub = forcedSubStatus || { status: res.subtitleStatus || (tracks.length ? 'error' : 'none'), note: res.subtitleNote || '' };
      await db
        .update(platformUploads)
        .set({
          status: 'done',
          url: res.url,
          embedUrl: res.embedUrl ?? null,
          remoteId: res.remoteId ?? null,
          subtitleStatus: sub.status,
          subtitleNote: sub.note || null,
          errorMessage: null,
          updatedAt: new Date(),
        })
        .where(eq(platformUploads.id, row.id));
      console.log(`[mirror] #${ctx.feedItemId} ${p.name} OK: ${res.url} (subtitles: ${sub.status})`);
      done++;
    } catch (e) {
      const msg = (e as Error).message || String(e);
      await db
        .update(platformUploads)
        .set({ status: 'error', errorMessage: msg.slice(0, 2000), updatedAt: new Date() })
        .where(eq(platformUploads.id, row.id));
      console.error(`[mirror] #${ctx.feedItemId} ${p.name} failed: ${msg}`);
      failed++;
    }
  }
  return { done, failed };
}

/** Retry failed platform uploads whose local video file still exists. */
export async function retryFailedMirrors(limit = 20): Promise<{ retried: number; skipped: string[] }> {
  const failedRows = await db
    .select()
    .from(platformUploads)
    .where(eq(platformUploads.status, 'error'))
    .orderBy(desc(platformUploads.id))
    .limit(limit);
  const skipped: string[] = [];
  let retried = 0;
  const seen = new Set<string>();
  for (const r of failedRows) {
    if (!r.feedItemId) continue;
    const key = `${r.feedItemId}:${r.platform}`;
    if (seen.has(key)) continue;
    seen.add(key);
    const [dl] = await db.select().from(downloads).where(eq(downloads.feedItemId, r.feedItemId)).orderBy(desc(downloads.id)).limit(1);
    const [item] = await db.select().from(feedItems).where(eq(feedItems.id, r.feedItemId)).limit(1);
    if (!dl?.videoPath || !item) {
      skipped.push(`${r.platform} #${r.feedItemId}: local video was already deleted`);
      continue;
    }
    try {
      await fs.access(dl.videoPath);
    } catch {
      skipped.push(`${r.platform} #${r.feedItemId}: local video was already deleted`);
      continue;
    }
    await db.delete(platformUploads).where(eq(platformUploads.id, r.id));
    await mirrorToPlatforms(
      {
        feedItemId: r.feedItemId,
        uploadId: r.uploadId,
        videoPath: dl.videoPath,
        title: r.title || item.title,
        description: item.title,
        tags: ['anime'],
        subtitles: {},
      },
      [r.platform]
    );
    retried++;
    // Once every platform succeeded for this episode, the local copy is no longer needed.
    const stillFailing = await db
      .select({ id: platformUploads.id })
      .from(platformUploads)
      .where(and(eq(platformUploads.feedItemId, r.feedItemId), eq(platformUploads.status, 'error')))
      .limit(1);
    if (stillFailing.length === 0 && (await removeDownloadDir(dl.infoHash || item.infoHash))) {
      await db.update(downloads).set({ status: 'cleaned', videoPath: null, updatedAt: new Date() }).where(eq(downloads.id, dl.id));
    }
  }
  return { retried, skipped };
}

/**
 * Platforms that accept subtitles only after processing (VidShared) are marked
 * "pending"; this runs every scheduler cycle and attaches them once ready.
 */
export async function attachPendingSubtitles(): Promise<{ attached: number; stillPending: number }> {
  const cfg = await getPlatformsConfig();
  const rows = await db
    .select()
    .from(platformUploads)
    .where(and(eq(platformUploads.status, 'done'), eq(platformUploads.subtitleStatus, 'pending')))
    .limit(25);
  let attached = 0;
  let stillPending = 0;
  for (const r of rows) {
    const p = getProvider(r.platform);
    if (!p?.attachSubtitles || !r.remoteId || !r.feedItemId) continue;
    // Give up after 24 hours.
    if (Date.now() - r.createdAt.getTime() > 24 * 3600_000) {
      await db.update(platformUploads).set({ subtitleStatus: 'error', subtitleNote: 'Gave up waiting for the platform to finish processing', updatedAt: new Date() }).where(eq(platformUploads.id, r.id));
      continue;
    }
    try {
      const tracks = await getSubtitleTracks(r.feedItemId);
      const res = await p.attachSubtitles(r.remoteId, tracks, cfg[p.id] || {});
      await db.update(platformUploads).set({ subtitleStatus: res.status, subtitleNote: res.note, updatedAt: new Date() }).where(eq(platformUploads.id, r.id));
      if (res.status === 'pending') stillPending++;
      else attached++;
    } catch (e) {
      await db.update(platformUploads).set({ subtitleNote: `Retrying: ${(e as Error).message.slice(0, 200)}`, updatedAt: new Date() }).where(eq(platformUploads.id, r.id));
      stillPending++;
    }
  }
  return { attached, stillPending };
}

/** Player link with subtitles (Byse loads them from this app via c1_file/c1_label). */
export async function playerUrlWithSubs(
  row: { platform: string; feedItemId: number | null; embedUrl: string | null; url: string | null },
  base: string | null
): Promise<string | null> {
  const link = row.embedUrl || row.url;
  if (!link || row.platform !== 'byse' || !row.feedItemId) return link;
  const { byseEmbedWithSubs } = await import('../subtitle-store');
  return byseEmbedWithSubs(link, await getSubtitleTracks(row.feedItemId), base);
}
