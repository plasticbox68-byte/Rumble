import path from 'path';
import fs from 'fs/promises';

// Downloads live OUTSIDE the project tree so the multi-GB torrent folder never
// gets scanned by the Next.js build. Hard-coded absolute path: the sandbox
// resets .env periodically, so this must not depend on an env var being set.
const DATA_DIR = process.env.DATA_DIR || '/home/user/rumble-data';
const DOWNLOADS_DIR = path.join(DATA_DIR, 'downloads');
const TMP_DIR = path.join(DATA_DIR, 'tmp');

export async function ensureDirs() {
  await fs.mkdir(DOWNLOADS_DIR, { recursive: true });
  await fs.mkdir(TMP_DIR, { recursive: true });
}

export function getDownloadDir(infoHash: string) {
  return path.join(DOWNLOADS_DIR, infoHash);
}

export function getTmpPath(filename: string) {
  return path.join(TMP_DIR, filename);
}

/** Free bytes on the filesystem that holds the downloads folder. */
export async function getFreeDiskBytes(): Promise<number> {
  try {
    await fs.mkdir(DOWNLOADS_DIR, { recursive: true });
    const st = await fs.statfs(DOWNLOADS_DIR);
    return Number(st.bavail) * Number(st.bsize);
  } catch {
    return Number.MAX_SAFE_INTEGER;
  }
}

/** Delete a finished torrent's folder after a successful upload to reclaim disk. */
export async function removeDownloadDir(infoHash: string | null | undefined): Promise<boolean> {
  if (!infoHash || !/^[a-f0-9]{20,64}$/i.test(infoHash)) return false;
  const dir = path.join(DOWNLOADS_DIR, infoHash);
  try {
    await fs.rm(dir, { recursive: true, force: true });
    return true;
  } catch {
    return false;
  }
}

export { DATA_DIR, DOWNLOADS_DIR, TMP_DIR };
