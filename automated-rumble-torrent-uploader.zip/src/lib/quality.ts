import { db } from '@/db';
import { feedItems } from '@/db/schema';
import { and, eq, inArray, ne } from 'drizzle-orm';
import { episodeKey } from './rss';

/**
 * Upload policy: Rumble only generates renditions UP TO the uploaded quality,
 * so we upload 1080p, and fall back to 720p only when no 1080p release exists.
 */
export const ACCEPTED_RESOLUTIONS = ['1080p', '720p'] as const;
const RANK: Record<string, number> = { '1080p': 2, '720p': 1 };

/** Wait this long before settling for a 720p release, so a 1080p one can appear. */
export const FALLBACK_GRACE_MS = 60 * 60 * 1000;

/**
 * Classify by the 16:9-equivalent height, so letterboxed/cinema-scope encodes
 * (1920x804, 1280x536) count as 1080p/720p instead of being under-rated.
 */
export function resolutionClass(width: number, height: number): string {
  const effective = Math.max(height, Math.round((width * 9) / 16));
  if (effective >= 1800) return '2160p';
  if (effective >= 1300) return '1440p';
  if (effective >= 1000) return '1080p';
  if (effective >= 700) return '720p';
  if (effective >= 400) return '480p';
  return '360p';
}

/** Resolution advertised in a release title (e.g. "1080p", "1920x1080"). */
export function titleResolution(title: string): string | null {
  const p = title.match(/\b(2160|1440|1080|720|576|480|360)p\b/i);
  if (p) return `${p[1]}p`;
  const wh = title.match(/\b(\d{3,4})x(\d{3,4})\b/);
  if (wh) return resolutionClass(Number(wh[1]), Number(wh[2]));
  if (/\b4k\b|\buhd\b/i.test(title)) return '2160p';
  return null;
}

export function isAcceptedResolution(res: string | null | undefined): boolean {
  return !!res && (ACCEPTED_RESOLUTIONS as readonly string[]).includes(res);
}

type Item = typeof feedItems.$inferSelect;

function keyOf(item: Item): string | null {
  return item.episodeKey || episodeKey(item.title, item.episodeNumber);
}

async function siblingsOf(item: Item): Promise<Item[]> {
  const key = keyOf(item);
  if (!key) return [];
  return db
    .select()
    .from(feedItems)
    .where(and(eq(feedItems.episodeKey, key), ne(feedItems.id, item.id)));
}

const IN_FLIGHT = ['downloading', 'downloaded', 'uploading', 'uploaded'];

export type DownloadDecision =
  | { action: 'download' }
  | { action: 'defer'; reason: string }
  | { action: 'skip'; reason: string };

/**
 * Decide whether a queued release should be downloaded under the
 * "1080p, else 720p, one upload per episode" policy.
 */
export async function decideDownload(item: Item): Promise<DownloadDecision> {
  const res = item.resolution || titleResolution(item.title);

  if (res && !isAcceptedResolution(res)) {
    return { action: 'skip', reason: `release is ${res}; only 1080p (or 720p fallback) is uploaded` };
  }

  const siblings = await siblingsOf(item);
  const alreadyHandled = siblings.find((s) => IN_FLIGHT.includes(s.status));
  if (alreadyHandled) {
    return {
      action: 'skip',
      reason: `another release of this episode is already ${alreadyHandled.status} (#${alreadyHandled.id})`,
    };
  }

  const candidates = siblings.filter(
    (s) => !['skipped'].includes(s.status) && isAcceptedResolution(s.resolution || titleResolution(s.title))
  );
  const myRank = res ? RANK[res] ?? 0 : 0;
  const better = candidates.find((s) => {
    const r = RANK[s.resolution || titleResolution(s.title) || ''] ?? 0;
    return r > myRank || (r === myRank && (s.seeders || 0) > (item.seeders || 0));
  });
  if (better) {
    const betterRes = better.resolution || titleResolution(better.title);
    return {
      action: 'skip',
      reason:
        betterRes === res
          ? `a better-seeded ${res} release of this episode exists (#${better.id})`
          : `a ${betterRes} release of this episode exists (#${better.id})`,
    };
  }

  // 720p is a fallback: give a 1080p release time to appear first.
  if (res === '720p') {
    const age = Date.now() - (item.pubDate?.getTime() || item.createdAt.getTime());
    if (age < FALLBACK_GRACE_MS) {
      const mins = Math.ceil((FALLBACK_GRACE_MS - age) / 60_000);
      return { action: 'defer', reason: `720p fallback — waiting ${mins} more min for a 1080p release` };
    }
  }

  return { action: 'download' };
}

/** True if a 1080p release of the same episode is queued or in progress. */
export async function hasActive1080Sibling(item: Item): Promise<Item | null> {
  const siblings = await siblingsOf(item);
  return (
    siblings.find(
      (s) =>
        !['skipped', 'error'].includes(s.status) &&
        (s.actualResolution || s.resolution || titleResolution(s.title)) === '1080p'
    ) || null
  );
}

/** Fill episode_key for rows created before the column existed. */
export async function backfillEpisodeKeys(): Promise<number> {
  const rows = await db
    .select({ id: feedItems.id, title: feedItems.title, ep: feedItems.episodeNumber, key: feedItems.episodeKey })
    .from(feedItems);
  let n = 0;
  for (const r of rows) {
    if (r.key) continue;
    const key = episodeKey(r.title, r.ep);
    if (!key) continue;
    await db.update(feedItems).set({ episodeKey: key }).where(eq(feedItems.id, r.id));
    n++;
  }
  return n;
}

/** Mark queued releases that violate the resolution policy as skipped. */
export async function skipDisallowedQueued(): Promise<number> {
  const rows = await db
    .select()
    .from(feedItems)
    .where(inArray(feedItems.status, ['discovered', 'error']));
  let n = 0;
  for (const r of rows) {
    const res = r.resolution || titleResolution(r.title);
    if (res && !isAcceptedResolution(res)) {
      await db
        .update(feedItems)
        .set({ status: 'skipped', errorMessage: `Skipped: ${res} — only 1080p (720p fallback) is uploaded`, updatedAt: new Date() })
        .where(eq(feedItems.id, r.id));
      n++;
    }
  }
  return n;
}
