import { XMLParser } from 'fast-xml-parser';
import { db } from '@/db';
import { feedItems } from '@/db/schema';
import { eq } from 'drizzle-orm';

export type NyaaRssItem = {
  title: string;
  link: string;
  guid: string;
  pubDate: string;
  seeders: number;
  leechers: number;
  downloads: number;
  infoHash: string;
  category: string;
  size: string;
  description: string;
  torrentUrl: string;
  magnetUri: string;
  fansubGroup?: string;
  episodeNumber?: string;
  resolution?: string;
};

const NYAA_NS = 'https://nyaa.si/xmlns/nyaa';

export async function fetchNyaaRss(
  rssUrl: string
): Promise<NyaaRssItem[]> {
  const res = await fetch(rssUrl, {
    headers: { 'User-Agent': 'RumbleAutoUploader/1.0' },
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch RSS: ${res.status} ${res.statusText}`);
  }
  const xml = await res.text();
  return parseNyaaRss(xml);
}

export function parseNyaaRss(xml: string): NyaaRssItem[] {
  const parser = new XMLParser({
    ignoreAttributes: false,
    attributeNamePrefix: '@_',
    trimValues: true,
  });
  const parsed = parser.parse(xml);
  const items = parsed?.rss?.channel?.item;
  if (!items) return [];
  const arr = Array.isArray(items) ? items : [items];
  return arr.map(rawToNyaaItem).filter(Boolean) as NyaaRssItem[];
}

// Helper to get text from a tag that may be a string or an object with #text (from attributes)
function getText(v: unknown): string {
  if (v == null) return '';
  if (typeof v === 'string') return v.trim();
  if (typeof v === 'object') {
    const obj = v as Record<string, unknown>;
    if (typeof obj['#text'] === 'string') return obj['#text'].trim();
    if (typeof obj['_'] === 'string') return obj['_'].trim();
  }
  return String(v).trim();
}

// Build a magnet link from an info hash and title
function buildMagnet(infoHash: string, title: string): string {
  if (!infoHash) return '';
  const dn = encodeURIComponent(title);
  const trackers = [
    'http://nyaa.tracker.wf:7777/announce',
    'udp://open.stealth.si:80/announce',
    'udp://tracker.opentrackr.org:1337/announce',
    'udp://exodus.desync.com:6969/announce',
    'udp://tracker.torrent.eu.org:451/announce',
  ];
  const tr = trackers.map((t) => `tr=${encodeURIComponent(t)}`).join('&');
  return `magnet:?xt=urn:btih:${infoHash}&dn=${dn}&${tr}`;
}

function rawToNyaaItem(raw: Record<string, unknown>): NyaaRssItem | null {
  try {
    const title = getText(raw['title']);
    // In Nyaa RSS, <link> is the .torrent download URL, <guid> is the view page URL.
    const torrentLink = getText(raw['link']);
    const guidRaw = raw['guid'];
    let pageUrl = '';
    let guid = '';
    if (typeof guidRaw === 'string') {
      pageUrl = guidRaw.trim();
      guid = pageUrl;
    } else if (guidRaw && typeof guidRaw === 'object') {
      pageUrl = getText(guidRaw);
      guid = pageUrl;
    }
    if (!guid) guid = torrentLink;

    const pubDate = getText(raw['pubDate']);
    const description = getText(raw['description']);

    // Prefer nyaa:category namespace element; fall back to <category>
    const category = getText(raw['nyaa:category']) || getText(raw['category']);

    const seeders = Number(getText(raw['nyaa:seeders']) || 0);
    const leechers = Number(getText(raw['nyaa:leechers']) || 0);
    const downloadsCount = Number(getText(raw['nyaa:downloads']) || 0);
    const infoHash = getText(raw['nyaa:infoHash']).toLowerCase();
    const size = getText(raw['nyaa:size']);

    // Torrent URL: prefer <link> (which on nyaa rss is the .torrent URL). If not, build from guid page.
    let torrentUrl = torrentLink;
    if (!torrentUrl) {
      const m = pageUrl.match(/\/view\/(\d+)/);
      if (m) torrentUrl = `https://nyaa.si/download/${m[1]}.torrent`;
    }

    const magnetUri = buildMagnet(infoHash, title);

    // Parse metadata from title
    const meta = parseAnimeTitle(title);

    return {
      title,
      link: pageUrl || torrentUrl,
      guid: guid || pageUrl || torrentUrl,
      pubDate,
      seeders: isNaN(seeders) ? 0 : seeders,
      leechers: isNaN(leechers) ? 0 : leechers,
      downloads: isNaN(downloadsCount) ? 0 : downloadsCount,
      infoHash,
      category,
      size,
      description,
      torrentUrl,
      magnetUri,
      ...meta,
    };
  } catch {
    return null;
  }
}

// Parse anime title like:
// [SubsPlease] Anime Name - 13 (1080p) [ABCD1234].mkv
// [Erai-raws] Anime Name S02 - 12 [1080p][HEVC][multiple subtitles]
// Returns fansubGroup, episodeNumber, resolution
export function parseAnimeTitle(title: string): {
  fansubGroup?: string;
  episodeNumber?: string;
  resolution?: string;
} {
  const out: { fansubGroup?: string; episodeNumber?: string; resolution?: string } = {};

  // Fansub group in leading brackets
  const groupMatch = title.match(/^\[([^\]]+)\]/);
  if (groupMatch) out.fansubGroup = groupMatch[1];

  // Resolution
  const resMatch = title.match(/\b(2160p|1080p|720p|480p|360p)\b/i);
  if (resMatch) out.resolution = resMatch[1].toLowerCase();

  // Episode number - look for " - NN" or "Episode NN" or S02E13
  const epMatch =
    title.match(/\bS\d+E(\d+(?:\.\d+)?)\b/i) ||
    title.match(/-\s*(\d+(?:\.\d+)?)\b/) ||
    title.match(/Episode\s+(\d+(?:\.\d+)?)/i);
  if (epMatch) out.episodeNumber = epMatch[1];

  return out;
}

/** Parse Nyaa size strings like "1.4 GiB", "529.0 MiB", "42.5 GiB" into bytes. */
export function parseSizeToBytes(size: string | null | undefined): number {
  if (!size) return 0;
  const m = size.trim().match(/([\d.]+)\s*(B|KiB|MiB|GiB|TiB|KB|MB|GB|TB)/i);
  if (!m) return 0;
  const n = parseFloat(m[1]);
  const unit = m[2].toLowerCase();
  const mult: Record<string, number> = {
    b: 1, kib: 1024, mib: 1024 ** 2, gib: 1024 ** 3, tib: 1024 ** 4,
    kb: 1000, mb: 1000 ** 2, gb: 1000 ** 3, tb: 1000 ** 4,
  };
  return Math.round(n * (mult[unit] || 1));
}

/**
 * Donghua (Chinese animation) detection. Nyaa's home RSS is full of Chinese
 * series from groups like Doomdos/FSP. These heuristics are deliberately
 * narrow so real Japanese anime with Chinese titles is not discarded.
 */
const DONGHUA_WORDS = [
  'donghua', 'guochao', 'chinese anime', 'cn anime', 'china anime',
  'battle through the heavens', 'mortals journey', 'a record of mortals',
  'renegade immortal', 'shrouding the heavens', 'perfect world', 'soul land',
  'douluo', 'renegade', 'against the gods', 'desolate era', 'story about buying',
  'chinese-dub', 'chinese dub', 'mandarin', 'cantonese', 'guoyu', 'zh-cn',
  'dongman', 'donghua-bt', '国内动漫', '国漫', '动漫国', '华语', '普通话',
];
const DONGHUA_GROUPS = [
  'doomdos', 'fsp', 'lolihouse', 'dhr', 'ttt', 'baha', 'vcb-studio', 'vcbstudio',
  'zhong', 'chinese', 'mikan', 'dmhy', 'cctv', 'bilibili', 'iqiyi', 'youku', 'tencent',
  'haoliners', 'ifan', 'aixier', 'skysubs', 'hjar', 'hysubs', 'sua', 'chinesesubs',
];

export function looksLikeDonghua(item: {
  title?: string | null;
  category?: string | null;
  fansubGroup?: string | null;
  description?: string | null;
}): boolean {
  const t = `${item.title || ''} ${item.description || ''}`.toLowerCase();
  if (DONGHUA_WORDS.some((w) => t.includes(w))) return true;
  const g = (item.fansubGroup || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  if (DONGHUA_GROUPS.some((w) => g.includes(w.replace(/[^a-z0-9]/g, '')))) return true;
  // Nyaa's "Anime - Non-English-translated" category is overwhelmingly donghua.
  if (/non-english/i.test(item.category || '')) return true;
  // Many donghua titles are CJK with no Latin letters at all.
  if (item.title && !/[a-z]{3}/i.test(item.title.replace(/\[[^\]]*\]/g, ''))) return true;
  return false;
}

export function isTrustedRelease(
  group: string | null | undefined,
  trustedList: string
): boolean {
  if (!trustedList.trim()) return true;
  const g = (group || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  if (!g) return false;
  return trustedList
    .split(',')
    .map((s) => s.trim().toLowerCase().replace(/[^a-z0-9]/g, ''))
    .filter(Boolean)
    .some((name) => g.includes(name) || name.includes(g));
}

/** Apply the user's anime-only / trusted-provider rules to a parsed RSS item. */
export function passesSourceFilters(
  item: NyaaRssItem,
  cfg: { excludeDonghua: boolean; trustedGroupsOnly: boolean; trustedGroups: string }
): boolean {
  if (item.category && !/^anime\b/i.test(item.category)) return false;
  if (cfg.excludeDonghua && looksLikeDonghua(item)) return false;
  if (cfg.trustedGroupsOnly && !isTrustedRelease(item.fansubGroup, cfg.trustedGroups)) return false;
  return true;
}

/**
 * Normalized identity for "the same episode" across release groups, e.g.
 * "[SubsPlease] Sousou no Frieren - 05 (1080p)" and
 * "[Erai-raws] Sousou no Frieren - 05 [720p][Multiple Subtitle]" → "sousounofrieren|s1|e5".
 */
export function episodeKey(title: string, episodeNumber?: string | null): string | null {
  const ep = episodeNumber ? Number(episodeNumber) : NaN;
  if (!Number.isFinite(ep)) return null;
  const seasonMatch = title.match(/\bS(\d{1,2})E\d+/i) || title.match(/\b(?:Season|S)\s?(\d{1,2})\b/i);
  const season = seasonMatch ? Number(seasonMatch[1]) : 1;
  let t = title
    .replace(/\[[^\]]*\]|\([^)]*\)|【[^】]*】/g, ' ')
    .replace(/\.(mkv|mp4)$/i, ' ');
  // Series name is everything before the episode marker.
  t = t.split(/\s-\s\d|\bS\d{1,2}E\d+|\bE(?:p|pisode)?\.?\s?\d+\b/i)[0];
  t = t.replace(/\b(?:Season|S)\s?\d{1,2}\b/gi, ' ').replace(/\b\d{3,4}p\b/gi, ' ');
  const series = t.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '');
  if (!series) return null;
  return `${series}|s${season}|e${ep}`;
}

export async function storeFeedItems(items: NyaaRssItem[], feedUrl: string) {
  let inserted = 0;
  for (const item of items) {
    const existing = await db
      .select({ id: feedItems.id })
      .from(feedItems)
      .where(eq(feedItems.guid, item.guid))
      .limit(1);
    if (existing.length > 0) continue;

    await db.insert(feedItems).values({
      feedUrl,
      title: item.title,
      link: item.link,
      guid: item.guid,
      pubDate: item.pubDate ? new Date(item.pubDate) : null,
      description: item.description,
      category: item.category,
      torrentUrl: item.torrentUrl,
      infoHash: item.infoHash || null,
      magnetUri: item.magnetUri || null,
      fileSize: item.size,
      seeders: item.seeders,
      leechers: item.leechers,
      fansubGroup: item.fansubGroup || null,
      episodeNumber: item.episodeNumber || null,
      resolution: item.resolution || null,
      episodeKey: episodeKey(item.title, item.episodeNumber),
      status: 'discovered',
    });
    inserted++;
  }
  return inserted;
}
