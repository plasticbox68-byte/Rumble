import { db } from '@/db';
import { schedulerLogs, schedulerState } from '@/db/schema';
import { eq, desc, lt, sql } from 'drizzle-orm';
import { getConfig } from './config';
import { pollFeed, processBacklog } from './pipeline';

export type SchedulerStatus = {
  running: boolean;
  last_poll_at: string | null;
  last_poll_fetched: number;
  last_poll_new: number;
  last_downloaded: number;
  last_uploaded: number;
  last_error: string | null;
  last_run_ms: number;
  next_run_at: string | null;
  poll_interval_minutes: number;
  auto_download: boolean;
  auto_upload: boolean;
  upload_mode: string;
  recent_logs: { id: number; level: string; message: string; created_at: string }[];
};

export async function log(
  level: 'info' | 'warn' | 'error',
  message: string
): Promise<void> {
  const ts = new Date().toISOString();
  const line = `[${ts}] [${level}] ${message}`;
  // Mirror to stdout so server logs also get it
  if (level === 'error') console.error(line);
  else if (level === 'warn') console.warn(line);
  else console.log(line);

  try {
    await db.insert(schedulerLogs).values({ level, message });
    // Keep only the most recent 500 rows (delete anything older than the 500th newest).
    await db.execute(sql`
      DELETE FROM scheduler_logs
      WHERE id IN (
        SELECT id FROM scheduler_logs
        ORDER BY id DESC
        OFFSET 500
      )
    `);
  } catch (e) {
    console.error('[scheduler] failed to persist log:', (e as Error).message);
  }
}

async function getOrCreateState() {
  let [row] = await db.select().from(schedulerState).limit(1);
  if (!row) {
    [row] = await db
      .insert(schedulerState)
      .values({
        lastRunMs: 0,
        lastPollFetched: 0,
        lastPollNew: 0,
        lastDownloaded: 0,
        lastUploaded: 0,
      })
      .returning();
  }
  return row;
}

export async function runCycle(): Promise<{
  fetched: number;
  newItems: number;
  downloaded: number;
  uploaded: number;
  errors: string[];
  durationMs: number;
}> {
  const start = Date.now();
  const errors: string[] = [];
  let fetched = 0;
  let newItems = 0;
  let downloaded = 0;
  let uploaded = 0;

  try {
    await log('info', 'Starting RSS poll cycle...');
    const feed = await pollFeed();
    fetched = feed.fetched;
    newItems = feed.newItems;
    await log('info', `RSS poll: ${feed.fetched} fetched, ${feed.newItems} new items stored.`);

    // Attach subtitles on platforms that only accept them after processing (VidShared).
    try {
      const { attachPendingSubtitles } = await import('./providers');
      const subs = await attachPendingSubtitles();
      if (subs.attached) await log('info', `Attached subtitles to ${subs.attached} platform upload(s); ${subs.stillPending} still processing.`);
    } catch (e) {
      await log('warn', `Pending subtitle check failed: ${(e as Error).message}`);
    }

    const cfg = await getConfig();
    if (cfg.autoDownload || cfg.autoUpload) {
      await log(
        'info',
        `Processing backlog (autoDownload=${cfg.autoDownload}, autoUpload=${cfg.autoUpload}, mode=${cfg.rumbleUploadMode})...`
      );
      const res = await processBacklog();
      downloaded = res.downloaded;
      uploaded = res.uploaded;
      errors.push(...res.errors);
      if (res.downloaded > 0 || res.uploaded > 0) {
        await log('info', `Backlog done: ${res.downloaded} downloaded, ${res.uploaded} uploaded.`);
      } else {
        await log('info', 'Backlog done: nothing new to download/upload.');
      }
      for (const e of res.errors) {
        await log('error', e);
      }
    } else {
      await log('info', 'Auto-download / auto-upload disabled; skipping backlog processing.');
    }
  } catch (e) {
    const msg = (e as Error).message || String(e);
    errors.push(msg);
    await log('error', `Cycle failed: ${msg}`);
  }

  const durationMs = Date.now() - start;

  try {
    const cfg = await getConfig();
    const next = new Date(Date.now() + cfg.rssPollIntervalMinutes * 60_000);
    await db
      .update(schedulerState)
      .set({
        lastPollAt: new Date(),
        lastPollFetched: fetched,
        lastPollNew: newItems,
        lastDownloaded: downloaded,
        lastUploaded: uploaded,
        lastError: errors.length > 0 ? errors.slice(-1)[0] : null,
        lastRunMs: durationMs,
        nextRunAt: next,
        updatedAt: new Date(),
      })
      .where(eq(schedulerState.id, 1));
  } catch (e) {
    console.error('[scheduler] failed to update state:', (e as Error).message);
  }

  return { fetched, newItems, downloaded, uploaded, errors, durationMs };
}

export async function getStatus(): Promise<SchedulerStatus> {
  const cfg = await getConfig();
  await getOrCreateState();
  const [state] = await db.select().from(schedulerState).limit(1);
  const logs = await db
    .select()
    .from(schedulerLogs)
    .orderBy(desc(schedulerLogs.id))
    .limit(50);
  return {
    running: true,
    last_poll_at: state.lastPollAt ? state.lastPollAt.toISOString() : null,
    last_poll_fetched: state.lastPollFetched ?? 0,
    last_poll_new: state.lastPollNew ?? 0,
    last_downloaded: state.lastDownloaded ?? 0,
    last_uploaded: state.lastUploaded ?? 0,
    last_error: state.lastError,
    last_run_ms: state.lastRunMs ?? 0,
    next_run_at: state.nextRunAt ? state.nextRunAt.toISOString() : null,
    poll_interval_minutes: cfg.rssPollIntervalMinutes,
    auto_download: cfg.autoDownload,
    auto_upload: cfg.autoUpload,
    upload_mode: cfg.rumbleUploadMode,
    recent_logs: logs
      .map((l) => ({
        id: l.id,
        level: l.level,
        message: l.message,
        created_at: l.createdAt.toISOString(),
      }))
      .reverse(),
  };
}

// Singleton scheduler timer handle
let timer: NodeJS.Timeout | null = null;
let stopped = false;

async function tick() {
  if (stopped) return;
  try {
    await runCycle();
  } catch (e) {
    console.error('[scheduler] tick error:', e);
  }
  // Schedule next tick based on current config interval
  try {
    const cfg = await getConfig();
    const minutes = Math.max(1, cfg.rssPollIntervalMinutes || 30);
    timer = setTimeout(tick, minutes * 60_000);
  } catch {
    timer = setTimeout(tick, 30 * 60_000);
  }
}

/** A server restart kills any in-flight browser upload; mark those rows so they get retried. */
async function recoverInterruptedJobs() {
  const { uploads, feedItems } = await import('@/db/schema');
  const { sql } = await import('drizzle-orm');
  const stuckUploads = await db
    .update(uploads)
    .set({
      status: 'error',
      errorMessage: 'Interrupted by server restart — will be retried',
      updatedAt: new Date(),
    })
    .where(sql`${uploads.status} = 'uploading'`)
    .returning({ id: uploads.id });
  // Items stuck in "uploading" go back to "downloaded" so auto-upload picks them up again.
  const stuckItems = await db
    .update(feedItems)
    .set({ status: 'downloaded', errorMessage: null, updatedAt: new Date() })
    .where(sql`${feedItems.status} = 'uploading'`)
    .returning({ id: feedItems.id });
  // Items stuck in "downloading" are reset to "discovered" so the download restarts.
  const stuckDownloads = await db
    .update(feedItems)
    .set({ status: 'discovered', updatedAt: new Date() })
    .where(sql`${feedItems.status} = 'downloading'`)
    .returning({ id: feedItems.id });
  if (stuckUploads.length || stuckItems.length || stuckDownloads.length) {
    await log(
      'warn',
      `Recovered interrupted jobs after restart: ${stuckUploads.length} upload(s), ${stuckItems.length} item(s) re-queued for upload, ${stuckDownloads.length} download(s) re-queued.`
    );
  }
}

export async function startScheduler() {
  if (timer) return;
  stopped = false;
  try {
    await getOrCreateState();
    await recoverInterruptedJobs();
    const { backfillEpisodeKeys, skipDisallowedQueued } = await import('./quality');
    const keyed = await backfillEpisodeKeys();
    const skipped = await skipDisallowedQueued();
    if (keyed || skipped) {
      await log('info', `Quality policy (1080p, 720p fallback): indexed ${keyed} episode(s), skipped ${skipped} queued release(s) with other resolutions.`);
    }
    await log('info', 'Background scheduler initialized. First cycle runs shortly...');
  } catch (e) {
    console.error('[scheduler] init failed:', (e as Error).message);
  }
  // First run 15 seconds after boot so the DB is ready
  setTimeout(() => {
    tick();
  }, 15_000);
}

export function stopScheduler() {
  stopped = true;
  if (timer) {
    clearTimeout(timer);
    timer = null;
  }
}

/**
 * Called when the user saves new config (e.g. enabling auto-upload).
 * Re-arms the timer and triggers an immediate cycle if needed.
 */
export async function notifyConfigChanged(): Promise<void> {
  await log('info', 'Configuration saved; re-scheduling next poll and running an immediate cycle.');
  if (timer) {
    clearTimeout(timer);
    timer = null;
  }
  // Run immediately, then schedule next
  setTimeout(() => tick(), 1_000);
}
