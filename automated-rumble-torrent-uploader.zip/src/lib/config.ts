import { db } from '@/db';
import { settings } from '@/db/schema';
import { eq } from 'drizzle-orm';

export type UploadMode = 'none' | 'api' | 'browser';

export type AppConfig = {
  rumbleUploadMode: UploadMode;
  rumbleAccessToken: string;
  rumbleChannelId: string;
  rumbleEmail: string;
  rumblePassword: string;
  rumbleSessionCookies: string;
  rumblePrimaryCategory: string;
  rumbleDefaultTitleTemplate: string;
  rumbleLicenseType: number;
  rssUrl: string;
  rssPollIntervalMinutes: number;
  rssFilterResolution: string;
  rssFilterFansub: string;
  rssFilterKeywords: string;
  rssMinSeeders: number;
  rssMaxSizeGb: number;
  enforceResolution: boolean;
  minVideoHeight: number;
  // Source quality controls
  excludeDonghua: boolean;
  trustedGroupsOnly: boolean;
  trustedGroups: string;
  // Bulk popular-anime discovery
  bulkMaxAnime: number;
  bulkEpisodesPerAnime: number;
  bulkAudioMode: 'sub' | 'dub' | 'both' | 'multi';
  bulkMinSeeders: number;
  bulkSoftSub: boolean;
  bulkHardSub: boolean;
  bulkHardSubLangs: string;
  autoDownload: boolean;
  autoUpload: boolean;
};

const DEFAULTS: AppConfig = {
  rumbleUploadMode: 'none',
  rumbleAccessToken: '',
  rumbleChannelId: '',
  rumbleEmail: '',
  rumblePassword: '',
  rumbleSessionCookies: '',
  rumblePrimaryCategory: 'Entertainment',
  rumbleDefaultTitleTemplate: '{title}',
  rumbleLicenseType: 0,
  rssUrl: 'https://nyaa.si/?page=rss',
  rssPollIntervalMinutes: 30,
  rssFilterResolution: '1080p',
  rssFilterFansub: '',
  rssFilterKeywords: '',
  rssMinSeeders: 0,
  rssMaxSizeGb: 3,
  enforceResolution: true,
  minVideoHeight: 720,
  excludeDonghua: true,
  trustedGroupsOnly: true,
  trustedGroups: 'SubsPlease,Erai-raws,GJM,Commie,ASW,AkihitoSubs,Judas,EMBER,Coalgirls,MTBB,Anime Time,Breeze,DKB,Valenciano,Sokudo,Trix,NeoHEVC,Cleo,Reinforce,AnimeRG,HorribleSubs,ToonsHub',
  bulkMaxAnime: 25,
  bulkEpisodesPerAnime: 1,
  bulkAudioMode: 'sub',
  bulkMinSeeders: 1,
  bulkSoftSub: true,
  bulkHardSub: false,
  bulkHardSubLangs: 'en',
  autoDownload: false,
  autoUpload: false,
};

const ALL_KEYS = Object.keys(DEFAULTS) as (keyof AppConfig)[];

export async function getConfig(): Promise<AppConfig> {
  const rows = await db.select().from(settings);
  const cfg = { ...DEFAULTS } as Record<string, string | number | boolean>;
  for (const row of rows) {
    const k = row.key as keyof AppConfig;
    if (ALL_KEYS.includes(k)) {
      const def = DEFAULTS[k];
      if (typeof def === 'number') {
        cfg[k] = row.value === null || row.value === '' ? def : Number(row.value);
      } else if (typeof def === 'boolean') {
        cfg[k] = row.value === 'true' || row.value === '1';
      } else {
        cfg[k] = row.value ?? def;
      }
    }
  }
  return cfg as unknown as AppConfig;
}

export async function setConfig(partial: Partial<AppConfig>): Promise<AppConfig> {
  for (const [k, v] of Object.entries(partial)) {
    if (!ALL_KEYS.includes(k as keyof AppConfig)) continue;
    const strVal = String(v);
    const existing = await db.select().from(settings).where(eq(settings.key, k)).limit(1);
    if (existing.length > 0) {
      await db
        .update(settings)
        .set({ value: strVal, updatedAt: new Date() })
        .where(eq(settings.key, k));
    } else {
      await db.insert(settings).values({ key: k, value: strVal });
    }
  }
  return getConfig();
}

export function isRumbleConfigured(cfg: AppConfig): boolean {
  if (cfg.rumbleUploadMode === 'api') {
    return !!cfg.rumbleAccessToken && cfg.rumbleAccessToken.length === 40;
  }
  if (cfg.rumbleUploadMode === 'browser') {
    const hasEmailPwd = !!cfg.rumbleEmail && !!cfg.rumblePassword;
    const hasCookies = !!cfg.rumbleSessionCookies && cfg.rumbleSessionCookies.trim().length > 10;
    return hasEmailPwd || hasCookies;
  }
  return false;
}

export function isBrowserMode(cfg: AppConfig): boolean {
  return cfg.rumbleUploadMode === 'browser';
}
