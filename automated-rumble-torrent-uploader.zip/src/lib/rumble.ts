import FormData from 'form-data';
import fs from 'fs/promises';
import { createReadStream } from 'fs';
import path from 'path';

// Rumble's simple upload API for Pro users
// POST https://rumble.com/api/simple-upload.php
// Fields:
//   access_token (required)
//   title (required, max 100 chars)
//   description
//   license_type (0 = personal, 6 = rumble only)
//   channel_id (required if account has channels)
//   video (required file)
//   thumb (optional)
//   cc_XX (optional captions per language, e.g. cc_en, cc_es, cc_fr, cc_de, cc_pt, cc_it, cc_ja, cc_ko, cc_zh)
//   tags (optional comma-separated)
//   category (optional category id)

export type RumbleUploadOptions = {
  accessToken: string;
  title: string;
  description?: string;
  licenseType?: number;
  channelId?: string;
  videoPath: string;
  thumbnailPath?: string;
  tags?: string[];
  category?: string;
  /** subtitles keyed by ISO 639-1 language code (en, es, ja, etc.) -> srt file path */
  subtitles?: Record<string, string>;
};

export type RumbleUploadResponse = {
  success?: boolean;
  video_id?: string;
  url?: string;
  embed_url?: string;
  embed_html?: string;
  thumbnail_url?: string;
  iFrameUrl?: string;
  error?: string;
  msg?: string;
  status?: string;
} & Record<string, unknown>;

export async function uploadToRumble(
  opts: RumbleUploadOptions,
  onProgress?: (pct: number) => void
): Promise<RumbleUploadResponse> {
  const form = new FormData();

  form.append('access_token', opts.accessToken);
  form.append('title', opts.title.slice(0, 100));
  if (opts.description) form.append('description', opts.description);
  form.append('license_type', String(opts.licenseType ?? 0));
  if (opts.channelId) form.append('channel_id', opts.channelId);
  if (opts.tags && opts.tags.length > 0) form.append('tags', opts.tags.join(','));
  if (opts.category) form.append('category', opts.category);

  // Attach video
  const videoStream = createReadStream(opts.videoPath);
  form.append('video', videoStream, {
    filename: path.basename(opts.videoPath),
    contentType: 'video/mp4',
  });

  // Attach thumbnail if provided
  if (opts.thumbnailPath) {
    form.append('thumb', createReadStream(opts.thumbnailPath), {
      filename: path.basename(opts.thumbnailPath),
    });
  }

  // Attach subtitles: Rumble uses cc_XX field names
  if (opts.subtitles) {
    for (const [lang, subPath] of Object.entries(opts.subtitles)) {
      const langCode = lang.toLowerCase().slice(0, 2);
      // Ensure .srt
      const ext = path.extname(subPath).toLowerCase();
      const filename = path.basename(subPath);
      const subStream = createReadStream(subPath);
      form.append(`cc_${langCode}`, subStream, {
        filename: ext === '.srt' ? filename : filename.replace(/\.[^.]+$/, '.srt'),
        contentType: 'application/x-subrip',
      });
    }
  }

  return new Promise((resolve, reject) => {
    const req = form.submit(
      {
        protocol: 'https:',
        host: 'rumble.com',
        path: '/api/simple-upload.php',
        method: 'POST',
      },
      (err, res) => {
        if (err) return reject(err);
        let body = '';
        res.on('data', (chunk: Buffer) => (body += chunk.toString('utf8')));
        res.on('end', () => {
          try {
            const json = JSON.parse(body) as RumbleUploadResponse;
            resolve(json);
          } catch {
            // Sometimes Rumble returns non-JSON on error
            resolve({ success: false, error: body.slice(0, 2000) });
          }
        });
        res.on('error', reject);
      }
    );

    if (onProgress && req && typeof (req as any).on === 'function') {
      // Track upload progress using form-data / underlying socket if possible
      req.on('error', reject);
      // form-data doesn't expose progress directly, but we can get bytes written vs expected
      // Get total size
      form.getLength((err, total) => {
        if (err || !total) return;
        let uploaded = 0;
        req.on('drain', () => {
          // Rough approximation
        });
        // Better approach: use http req 'socket' and track bytes
        req.on('socket', (socket) => {
          if (!socket) return;
          const onData = (chunk: Buffer) => {
            uploaded += chunk.length;
            const pct = Math.min(99, Math.floor((uploaded / total) * 100));
            onProgress(pct);
          };
          socket.on('data', onData);
          req.on('close', () => {
            socket.off('data', onData);
          });
        });
      });
    }
  });
}

/**
 * Attempt to extract an HLS m3u8 URL from a Rumble video page.
 * First checks if the upload response already contains stream info; if not,
 * fetches the page and parses embed data.
 */
/** Resolve a relative HLS URI against a parent playlist URL. */
function resolveHlsUrl(base: string, uri: string): string {
  if (/^https?:\/\//i.test(uri)) return uri;
  try {
    return new URL(uri, base).toString();
  } catch {
    return uri;
  }
}

/**
 * Given HTML from a Rumble video page, find m3u8 URLs and pick the highest
 * resolution rendition from any master playlists. Returns the best URL.
 */
export async function extractBestStreamUrlFromHtml(
  html: string,
  pageUrl: string
): Promise<string | null> {
  if (!html) return null;
  const candidates = new Set<string>();
  const raw = html.match(/https?:[^"'\\\s<>]+\.m3u8[^"'\\\s<>]*/gi) || [];
  for (const u of raw) candidates.add(decodeHtml(u));
  // Also match escaped JSON URLs
  const escaped = html.match(/https?:[^"'\\\s<>]+m3u8[^"'\\\s<>]*/gi) || [];
  for (const u of escaped) candidates.add(decodeHtml(u.replace(/\\\//g, '/')));

  let best: { url: string; height: number; bandwidth: number } | null = null;

  for (const url of Array.from(candidates).slice(0, 12)) {
    try {
      const res = await fetch(url, { headers: { 'User-Agent': USER_AGENT }, signal: AbortSignal.timeout(15_000) });
      if (!res.ok) continue;
      const text = await res.text();
      if (!text.includes('#EXTM3U')) continue;
      // Master playlist: choose the highest RESOLUTION / BANDWIDTH variant.
      if (text.includes('#EXT-X-STREAM-INF')) {
        const lines = text.split(/\r?\n/);
        for (let i = 0; i < lines.length; i++) {
          const line = lines[i];
          if (!line.startsWith('#EXT-X-STREAM-INF')) continue;
          const resMatch = line.match(/RESOLUTION=(\d+)x(\d+)/);
          const bwMatch = line.match(/BANDWIDTH=(\d+)/);
          const height = resMatch ? Number(resMatch[2]) : 0;
          const bandwidth = bwMatch ? Number(bwMatch[1]) : 0;
          // Next non-comment line is the variant URL
          let uri = '';
          for (let j = i + 1; j < lines.length; j++) {
            const l = lines[j].trim();
            if (l && !l.startsWith('#')) {
              uri = l;
              break;
            }
          }
          if (!uri) continue;
          const variantUrl = resolveHlsUrl(url, uri);
          if (!best || height > best.height || (height === best.height && bandwidth > best.bandwidth)) {
            best = { url: variantUrl, height, bandwidth };
          }
        }
      } else if (!best) {
        // Media playlist with no variants — use it as-is.
        best = { url, height: 0, bandwidth: 0 };
      }
    } catch {
      /* ignore unreachable playlist */
    }
  }

  if (best) return best.url;
  // Fall back to the usual page-based extraction.
  return extractStreamUrl(pageUrl);
}

const USER_AGENT =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36';


export async function extractStreamUrl(videoUrl: string): Promise<string | null> {
  if (!videoUrl) return null;
  try {
    const res = await fetch(videoUrl, {
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept-Language': 'en-US,en;q=0.9',
      },
    });
    if (!res.ok) return null;
    const html = await res.text();

    // Try "video":[{"url":"..."}] pattern in the player JSON
    let m =
      html.match(/https?:\/\/[^"'\s]+rumble\.cloud[^"'\s]+\.m3u8[^"'\s]*/i) ||
      html.match(/"(https?:\/\/[^"]+\.m3u8[^"]*)"/i);
    if (m) return decodeHtml(m[1]);

    // Try "hls_url":"..." or "mp4_url":"..."
    m =
      html.match(/"hls_url"\s*:\s*"([^"]+)"/i) ||
      html.match(/"m3u8"\s*:\s*"([^"]+)"/i) ||
      html.match(/"videoUrl"\s*:\s*"([^"]+)"/i);
    if (m) return decodeHtml(m[1].replace(/\\\//g, '/'));

    // Try embeds
    m = html.match(/src="([^"]*rumble\.com\/embed[^"]+)"/i);
    if (m) {
      const embedUrl = decodeHtml(m[1]);
      const embedRes = await fetch(embedUrl.startsWith('//') ? `https:${embedUrl}` : embedUrl, {
        headers: { 'User-Agent': 'Mozilla/5.0' },
      });
      if (embedRes.ok) {
        const embedHtml = await embedRes.text();
        const m2 =
          embedHtml.match(/https?:\/\/[^"'\s]+rumble\.cloud[^"'\s]+\.m3u8[^"'\s]*/i) ||
          embedHtml.match(/"(https?:\/\/[^"]+\.m3u8[^"]*)"/i);
        if (m2) return decodeHtml(m2[1]);
      }
    }
    return null;
  } catch (e) {
    console.warn('[rumble] extractStreamUrl failed:', (e as Error).message);
    return null;
  }
}

function decodeHtml(s: string): string {
  return s
    .replace(/\\u002F/g, '/')
    .replace(/\\u0026/g, '&')
    .replace(/%3A/g, ':')
    .replace(/%2F/g, '/')
    .replace(/%3F/g, '?')
    .replace(/%3D/g, '=')
    .replace(/%26/g, '&')
    .replace(/&amp;/g, '&');
}

export function buildTitle(template: string, vars: Record<string, string | undefined>): string {
  return template.replace(/\{(\w+)\}/g, (_, k) => (vars[k] ? String(vars[k]) : `{${k}}`));
}
