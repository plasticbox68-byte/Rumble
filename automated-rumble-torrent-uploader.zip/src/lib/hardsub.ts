import { spawn } from 'child_process';
import ffmpegStatic from 'ffmpeg-static';
import path from 'path';
import fs from 'fs/promises';

function ffmpegPath(): string {
  const raw = ffmpegStatic as unknown as string | { default?: string } | null;
  if (typeof raw === 'string') return raw;
  if (raw && typeof raw === 'object' && raw.default) return raw.default;
  return 'ffmpeg';
}

/** Escape a path for ffmpeg's subtitles filter (Windows drive colons and quotes). */
function escapeFilterPath(p: string): string {
  return p.replace(/\\/g, '/').replace(/:/g, '\\:').replace(/'/g, "\\'");
}

export type BurnResult = { outPath: string; lang: string; size: number };

/**
 * Burn one SRT into a new MP4 with libass. Video is re-encoded (H.264 CRF 20),
 * audio is copied when already AAC/MP3, otherwise converted to AAC.
 */
export async function burnSubtitles(
  videoPath: string,
  srtPath: string,
  lang: string,
  outDir: string
): Promise<BurnResult> {
  await fs.mkdir(outDir, { recursive: true });
  const outPath = path.join(outDir, `hardsub_${lang}.mp4`);
  const filter = `subtitles='${escapeFilterPath(srtPath)}'`;

  const args = [
    '-y',
    '-i', videoPath,
    '-vf', filter,
    '-c:v', 'libx264',
    '-preset', 'veryfast',
    '-crf', '20',
    '-pix_fmt', 'yuv420p',
    '-c:a', 'aac',
    '-b:a', '192k',
    '-movflags', '+faststart',
    '-map_metadata', '-1',
    outPath,
  ];

  await new Promise<void>((resolve, reject) => {
    const proc = spawn(ffmpegPath(), args);
    let stderr = '';
    proc.stderr.on('data', (d: Buffer) => {
      stderr += d.toString();
      if (stderr.length > 100_000) stderr = stderr.slice(-100_000);
    });
    proc.on('error', reject);
    proc.on('close', (code) => {
      if (code !== 0) reject(new Error(`ffmpeg hardsub failed (${code}): ${stderr.slice(-2000)}`));
      else resolve();
    });
  });

  const st = await fs.stat(outPath);
  return { outPath, lang, size: st.size };
}
