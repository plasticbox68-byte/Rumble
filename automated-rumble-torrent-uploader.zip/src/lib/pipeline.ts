import { db } from '@/db';
import { feedItems, downloads, uploads } from '@/db/schema';
import { eq, desc, and, inArray } from 'drizzle-orm';
import { fetchNyaaRss, storeFeedItems, parseSizeToBytes, passesSourceFilters, type NyaaRssItem } from './rss';
import { getConfig, isRumbleConfigured, isBrowserMode } from './config';
import { startTorrentDownload, isVideoFile, isSubtitleFile } from './torrent';
import { extractSubtitles, ensureSrt, probeVideoInfo } from './ffmpeg';
import { uploadToRumble, extractStreamUrl, buildTitle } from './rumble';
import { uploadToRumbleViaBrowser } from './rumble-browser';
import path from 'path';
import fs from 'fs/promises';
import { getTmpPath, getFreeDiskBytes, removeDownloadDir } from './storage';
import { burnSubtitles } from './hardsub';
import { mirrorToPlatforms } from './providers';
import { decideDownload, hasActive1080Sibling, isAcceptedResolution, titleResolution } from './quality';

export async function pollFeed(): Promise<{ fetched: number; newItems: number; excluded: number }> {
  const cfg = await getConfig();
  const items = await fetchNyaaRss(cfg.rssUrl);
  const before = items.length;
  let filtered = items.filter((it) => passesSourceFilters(it, cfg));
  const excluded = before - filtered.length;
  if (excluded > 0) {
    console.log(`[rss] excluded ${excluded}/${before} item(s): donghua or untrusted provider`);
  }

  // Resolution policy: only 1080p, with 720p as a fallback. Untagged titles are
  // kept and verified by probing the actual file after download.
  filtered = filtered.filter((it) => {
    const res = it.resolution || titleResolution(it.title);
    return !res || isAcceptedResolution(res);
  });
  if (cfg.rssFilterFansub) {
    const g = cfg.rssFilterFansub.toLowerCase();
    filtered = filtered.filter((it) =>
      it.fansubGroup ? it.fansubGroup.toLowerCase().includes(g) : false
    );
  }
  if (cfg.rssFilterKeywords) {
    const kws = cfg.rssFilterKeywords
      .split(',')
      .map((k) => k.trim().toLowerCase())
      .filter(Boolean);
    if (kws.length > 0) {
      filtered = filtered.filter((it) => {
        const t = it.title.toLowerCase();
        return kws.some((kw) => t.includes(kw));
      });
    }
  }
  if (cfg.rssMinSeeders > 0) {
    filtered = filtered.filter((it) => (it.seeders || 0) >= cfg.rssMinSeeders);
  }
  // Skip batch packs / BD ISOs that would fill the disk.
  if (cfg.rssMaxSizeGb > 0) {
    const maxBytes = cfg.rssMaxSizeGb * 1024 ** 3;
    filtered = filtered.filter((it) => {
      const bytes = parseSizeToBytes(it.size);
      return bytes === 0 || bytes <= maxBytes;
    });
  }

  const inserted = await storeFeedItems(filtered, cfg.rssUrl);
  return { fetched: items.length, newItems: inserted, excluded };
}

/**
 * Process all discovered items if autoDownload/autoUpload enabled.
 * Returns IDs processed.
 */
export async function processBacklog(
  opts: { download?: boolean; upload?: boolean; force?: boolean } = {}
): Promise<{ downloaded: number; uploaded: number; errors: string[] }> {
  const cfg = await getConfig();
  const shouldDownload = opts.download ?? cfg.autoDownload;
  const shouldUpload = opts.upload ?? cfg.autoUpload;
  const errors: string[] = [];
  let downloaded = 0;
  let uploaded = 0;

  if (shouldDownload) {
    const queued = await db
      .select()
      .from(feedItems)
      .where(inArray(feedItems.status, ['discovered', 'error']))
      .orderBy(desc(feedItems.pubDate), desc(feedItems.seeders))
      .limit(60);

    // 1080p first, 720p only as a fallback, one release per episode.
    const pending: typeof queued = [];
    for (const item of queued) {
      if (pending.length >= 5) break;
      const decision = await decideDownload(item);
      if (decision.action === 'download') {
        // Avoid picking two releases of the same episode in one batch.
        if (item.episodeKey && pending.some((p) => p.episodeKey === item.episodeKey)) continue;
        pending.push(item);
      } else if (decision.action === 'skip') {
        await db
          .update(feedItems)
          .set({ status: 'skipped', errorMessage: `Skipped: ${decision.reason}`, updatedAt: new Date() })
          .where(eq(feedItems.id, item.id));
      }
      // 'defer' leaves the item queued for a later cycle.
    }

    // Download up to 3 torrents in parallel: each swarm is independent, so total throughput rises.
    const CONCURRENCY = 3;
    let next = 0;
    const worker = async () => {
      while (next < pending.length) {
        const item = pending[next++];
        try {
          await processItemDownload(item.id);
          downloaded++;
          // Upload immediately after this torrent finishes — don't wait for the
          // rest of the download batch or the next scheduler cycle.
          if (shouldUpload && isRumbleConfigured(cfg)) {
            try {
              await processItemUpload(item.id);
              uploaded++;
            } catch (e) {
              errors.push(`Auto-upload after download #${item.id}: ${(e as Error).message}`);
            }
          }
        } catch (e) {
          errors.push(`Download #${item.id}: ${(e as Error).message}`);
        }
      }
    };
    await Promise.all(Array.from({ length: Math.min(CONCURRENCY, pending.length) }, worker));
  }

  if (shouldUpload) {
    if (!isRumbleConfigured(cfg)) {
      if (cfg.rumbleUploadMode === 'none') {
        errors.push('Rumble upload mode is "None". Set it to API (Pro token) or Browser (free) in Settings.');
      } else if (cfg.rumbleUploadMode === 'api') {
        errors.push('Rumble API mode selected but access token (40 chars) missing.');
      } else {
        errors.push('Rumble Browser mode selected but email/password are missing.');
      }
    } else {
      const ready = await db
        .select()
        .from(feedItems)
        .where(eq(feedItems.status, 'downloaded'))
        .orderBy(desc(feedItems.pubDate))
        .limit(3);

      for (const item of ready) {
        try {
          await processItemUpload(item.id);
          uploaded++;
        } catch (e) {
          errors.push(`Upload #${item.id}: ${(e as Error).message}`);
        }
      }
    }
  }

  return { downloaded, uploaded, errors };
}

/** Remove already-discovered items that violate the current anime-only / provider rules. */
export async function purgeNonAnimeItems(): Promise<{ deleted: number; sample: string[] }> {
  const cfg = await getConfig();
  const rows = await db
    .select()
    .from(feedItems)
    .where(inArray(feedItems.status, ['discovered', 'error', 'skipped', 'downloading', 'downloaded', 'uploading']))
    .limit(5000);
  const sample: string[] = [];
  const ids: number[] = [];
  for (const r of rows) {
    const fake: NyaaRssItem = {
      title: r.title,
      seeders: r.seeders ?? 0,
      leechers: r.leechers ?? 0,
      downloads: 0,
      infoHash: r.infoHash ?? '',
      category: r.category ?? '',
      size: r.fileSize ?? '',
      description: r.description ?? '',
      torrentUrl: r.torrentUrl ?? '',
      magnetUri: r.magnetUri ?? '',
      link: r.link ?? '',
      guid: r.guid,
      pubDate: r.pubDate?.toISOString() ?? '',
      ...(r.fansubGroup ? { fansubGroup: r.fansubGroup } : {}),
    };
    if (!passesSourceFilters(fake, cfg)) {
      ids.push(r.id);
      if (sample.length < 5) sample.push(r.title.slice(0, 90));
    }
  }
  // Drop queued items, but keep a record of anything already downloaded/uploading.
  const toDelete = rows.filter((r) => ids.includes(r.id) && ['discovered', 'error', 'skipped'].includes(r.status)).map((r) => r.id);
  const toSkip = rows.filter((r) => ids.includes(r.id) && !toDelete.includes(r.id)).map((r) => r.id);
  for (let i = 0; i < toDelete.length; i += 200) {
    await db.delete(feedItems).where(inArray(feedItems.id, toDelete.slice(i, i + 200)));
  }
  for (let i = 0; i < toSkip.length; i += 200) {
    await db
      .update(feedItems)
      .set({ status: 'skipped', errorMessage: 'Excluded: donghua or untrusted provider', updatedAt: new Date() })
      .where(inArray(feedItems.id, toSkip.slice(i, i + 200)));
  }
  return { deleted: toDelete.length + toSkip.length, sample };
}

export async function processItemDownload(feedItemId: number) {
  const item = await db
    .select()
    .from(feedItems)
    .where(eq(feedItems.id, feedItemId))
    .then((r) => r[0]);
  if (!item) throw new Error(`Feed item ${feedItemId} not found`);

  // Guard: refuse torrents bigger than the configured cap or the free disk space.
  const cfg = await getConfig();
  const bytes = parseSizeToBytes(item.fileSize);
  const maxBytes = cfg.rssMaxSizeGb > 0 ? cfg.rssMaxSizeGb * 1024 ** 3 : Infinity;
  const free = await getFreeDiskBytes();
  // Keep a 2 GB safety margin so the upload/subtitle extraction never hits ENOSPC.
  const usable = Math.max(0, free - 2 * 1024 ** 3);
  if (bytes > 0 && (bytes > maxBytes || bytes > usable)) {
    const reason =
      bytes > maxBytes
        ? `torrent is ${item.fileSize}, above the ${cfg.rssMaxSizeGb} GB limit (batch packs/ISOs are skipped)`
        : `torrent is ${item.fileSize} but only ${(usable / 1024 ** 3).toFixed(1)} GB of disk is free`;
    await db
      .update(feedItems)
      .set({ status: 'skipped', errorMessage: `Skipped: ${reason}`, updatedAt: new Date() })
      .where(eq(feedItems.id, feedItemId));
    throw new Error(`Skipped #${feedItemId}: ${reason}`);
  }

  const handle = await startTorrentDownload(
    feedItemId,
    item.magnetUri || '',
    item.torrentUrl || undefined
  );

  // Pick the BEST video by actual decoded height, not by file size.
  // Torrents often contain a sample clip or an alternate lower-resolution file.
  let videoCandidates = handle.videoFiles;
  if (videoCandidates.length === 0) {
    videoCandidates = handle.files.filter((f) => isVideoFile(f.name));
  }
  if (videoCandidates.length === 0) throw new Error('No video file found in torrent');

  const probed: { file: (typeof videoCandidates)[number]; height: number; width: number; resolution: string }[] = [];
  for (const vf of videoCandidates) {
    try {
      const info = await probeVideoInfo(vf.path);
      probed.push({ file: vf, height: info.height, width: info.width, resolution: info.resolution });
    } catch (e) {
      console.warn(`[pipeline] could not probe ${vf.name}: ${(e as Error).message}`);
    }
  }
  probed.sort((a, b) => b.height - a.height || b.file.size - a.file.size);
  const primaryVideo = probed[0]?.file;
  if (!primaryVideo) throw new Error('No decodable video file found in torrent');
  const actual = probed[0];
  await db
    .update(feedItems)
    .set({ actualResolution: actual.resolution, updatedAt: new Date() })
    .where(eq(feedItems.id, feedItemId));
  console.log(
    `[pipeline] #${feedItemId} selected ${primaryVideo.name} — ${actual.width}x${actual.height} (${actual.resolution})`
  );

  // Collect subtitle entries: both external files in torrent and extracted from video
  const extracted: { lang: string; path: string; codec: string; title?: string }[] = [];

  // External subs from torrent
  for (const sf of handle.subtitleFiles) {
    const lang = guessLangFromFilename(sf.name);
    let srtPath = sf.path;
    try {
      srtPath = await ensureSrt(sf.path);
    } catch {
      // if conversion fails, use original
    }
    extracted.push({ lang, path: srtPath, codec: path.extname(sf.name).slice(1) });
  }

  // Embedded subs from video
  try {
    const subOutDir = path.join(path.dirname(primaryVideo.path), '._extracted_subs');
    const emb = await extractSubtitles(primaryVideo.path, subOutDir);
    for (const s of emb) {
      // MKV tags use ISO 639-2 ("eng", "jpn"); normalize to 2-letter codes so
      // English is always "en". Fall back to the track title ("English (US)").
      let lang = normalizeLang(s.lang);
      if (lang === 'und' && s.title) lang = guessLangFromFilename(`${s.title}.srt`);
      // Keep every track (e.g. "Signs & Songs" AND full dialogue) — the best
      // one per language is chosen at upload time.
      extracted.push({ ...s, lang });
    }
  } catch (e) {
    console.warn(
      `[pipeline] Could not extract embedded subs from ${primaryVideo.path}: ${(e as Error).message}`
    );
  }

  // Update downloads record with subtitles
  const dl = await db
    .select()
    .from(downloads)
    .where(eq(downloads.feedItemId, feedItemId))
    .limit(1)
    .then((r) => r[0]);
  if (dl) {
    await db
      .update(downloads)
      .set({
        subtitles: extracted,
        videoPath: primaryVideo.path,
        actualWidth: actual.width,
        actualHeight: actual.height,
        updatedAt: new Date(),
      })
      .where(eq(downloads.id, dl.id));
  }

  await db
    .update(feedItems)
    .set({ status: 'downloaded', updatedAt: new Date() })
    .where(eq(feedItems.id, feedItemId));

  return { primaryVideo: primaryVideo.path, subtitles: extracted };
}

export type UploadVariantOptions = {
  /** Use an alternate video file (e.g. a hard-subbed encode). */
  videoPathOverride?: string;
  /** Extra text appended to the video title, e.g. "[Hardsub EN]". */
  titleSuffix?: string;
  variant?: 'soft' | 'hard';
  hardLang?: string;
  /** Subtitles to attach; omit to use the ones extracted from the torrent. */
  subtitlesOverride?: Record<string, string>;
  /** Don't mark the feed item, don't spawn hard-sub variants, don't delete local files. */
  markItemStatus?: boolean;
  skipCleanup?: boolean;
};

export async function processItemUpload(feedItemId: number, opts: UploadVariantOptions = {}) {
  const cfg = await getConfig();
  if (!isRumbleConfigured(cfg)) {
    if (cfg.rumbleUploadMode === 'none') {
      throw new Error('Upload method is set to "Do Not Upload". Choose "Free Browser Sign-In" in Settings.');
    }
    if (cfg.rumbleUploadMode === 'api') {
      throw new Error('Rumble Pro API selected, but the 40-character access token or Channel ID is missing in Settings.');
    }
    throw new Error('Free Browser Sign-In selected, but no session cookies or email/password are saved in Settings.');
  }

  const item = await db
    .select()
    .from(feedItems)
    .where(eq(feedItems.id, feedItemId))
    .then((r) => r[0]);
  if (!item) throw new Error(`Feed item ${feedItemId} not found`);

  const dl = await db
    .select()
    .from(downloads)
    .where(eq(downloads.feedItemId, feedItemId))
    .limit(1)
    .then((r) => r[0]);
  const videoPath = opts.videoPathOverride || dl?.videoPath;
  if (!dl || !videoPath) throw new Error('No downloaded video for this item');
  try {
    await fs.access(videoPath);
  } catch {
    throw new Error(`Video file is missing on disk: ${videoPath}`);
  }

  // Quality gate: Rumble only builds renditions UP TO the uploaded quality, so
  // only real 1080p is uploaded — or real 720p when no 1080p release exists.
  let actualRes: string | undefined;
  if ((!opts.variant || opts.variant === 'soft') && cfg.enforceResolution) {
    let info: Awaited<ReturnType<typeof probeVideoInfo>>;
    try {
      info = await probeVideoInfo(videoPath);
    } catch (e) {
      throw new Error(`Quality check failed: could not read the video stream (${(e as Error).message})`);
    }
    actualRes = info.resolution;
    let reason: string | null = null;
    if (!isAcceptedResolution(info.resolution)) {
      reason = `the video is ${info.resolution} (${info.width}x${info.height}); only 1080p or 720p is uploaded`;
    } else if (info.resolution === '720p') {
      const better = await hasActive1080Sibling(item);
      if (better) reason = `the video is 720p but a 1080p release of this episode exists (#${better.id})`;
    }
    if (reason) {
      await db
        .update(feedItems)
        .set({ status: 'skipped', actualResolution: info.resolution, errorMessage: `Quality check failed: ${reason}`, updatedAt: new Date() })
        .where(eq(feedItems.id, feedItemId));
      console.warn(`[pipeline] #${feedItemId} skipped upload: ${reason}`);
      throw new Error(`Quality check failed: ${reason}`);
    }
    console.log(`[pipeline] #${feedItemId} quality OK: ${info.width}x${info.height} → ${info.resolution}`);
  }

  if (opts.markItemStatus !== false) {
    await db
      .update(feedItems)
      .set({ status: 'uploading', updatedAt: new Date() })
      .where(eq(feedItems.id, feedItemId));
  }

  // Create upload record
  const [uploadRow] = await db
    .insert(uploads)
    .values({
      feedItemId,
      downloadId: dl.id,
      title: `${item.title}${opts.titleSuffix ? ` ${opts.titleSuffix}` : ''}`.slice(0, 100),
      description: buildDescription(item),
      channelId: cfg.rumbleChannelId,
      variant: opts.variant || 'soft',
      hardLang: opts.hardLang || null,
      status: 'uploading',
      progress: 0,
      subtitlesUploaded: [],
    })
    .returning();

  // Build title
  const title = buildTitle(cfg.rumbleDefaultTitleTemplate || '{title}', {
    title: item.title,
    group: item.fansubGroup ?? undefined,
    episode: item.episodeNumber ?? undefined,
    resolution: actualRes || item.actualResolution || item.resolution || undefined,
  }).slice(0, 100);
  const finalTitle = `${title}${opts.titleSuffix ? ` ${opts.titleSuffix}` : ''}`.slice(0, 100);

  // Prepare subtitles map
  const subtitlesMap: Record<string, string> = {};
  const uploadedSubs: { lang: string; filename: string }[] = [];
  const existingSubs = opts.subtitlesOverride
    ? Object.entries(opts.subtitlesOverride).map(([lang, p]) => ({ lang, path: p }))
    : ((dl.subtitles || []) as { lang: string; path: string }[]);
  const subsToAttach = opts.subtitlesOverride || (cfg.bulkSoftSub === false ? {} : undefined);
  // One caption track per language: the full-dialogue track wins over signs/songs.
  const langs = Array.from(new Set(existingSubs.map((t) => normalizeLang(t.lang))));
  const normalizedSubs = existingSubs.map((t) => ({ ...t, lang: normalizeLang(t.lang) }));
  for (const lang of langs) {
    if (lang === 'und') continue;
    if (subsToAttach && !(lang in subsToAttach)) continue;
    const best = await pickBestTrack(normalizedSubs, lang);
    if (!best) continue;
    subtitlesMap[lang] = best.path;
    uploadedSubs.push({ lang, filename: path.basename(best.path) });
  }

  let rumbleUrl: string | null = null;
  let rumbleVideoId: string | null = null;
  let embedUrl: string | null = null;
  let thumbnailUrl: string | null = null;
  let streamUrl: string | null = null;
  let errorMessage: string | null = null;
  let isSuccess = false;
  let rawResp: Record<string, unknown> = {};
  const finalUploadedSubs = [...uploadedSubs];

  try {
    if (isBrowserMode(cfg)) {
      // === Browser (free) mode ===
      const browserResult = await uploadToRumbleViaBrowser({
        email: cfg.rumbleEmail,
        password: cfg.rumblePassword,
        sessionCookies: cfg.rumbleSessionCookies,
        videoPath,
        title: finalTitle,
        description: buildDescription(item),
        tags: buildTags(item),
        primaryCategory: cfg.rumblePrimaryCategory || 'Entertainment',
        subtitles: Object.keys(subtitlesMap).length > 0 ? subtitlesMap : undefined,
        headless: true,
        onProgress: async (stage, pct) => {
          await db
            .update(uploads)
            .set({
              progress: typeof pct === 'number' ? pct : 50,
              errorMessage: `stage: ${stage}`,
              updatedAt: new Date(),
            })
            .where(eq(uploads.id, uploadRow.id));
        },
      });
      rumbleUrl = browserResult.videoUrl;
      rumbleVideoId = browserResult.videoId || null;
      embedUrl = browserResult.embedUrl || null;
      thumbnailUrl = browserResult.thumbnailUrl || null;
      streamUrl = browserResult.streamUrl || null;
      isSuccess = true;
      // merge subs with actual results
      for (const s of browserResult.subtitlesAttached) {
        const existing = finalUploadedSubs.find((x) => x.lang === s.lang);
        if (!existing) finalUploadedSubs.push({ lang: s.lang, filename: subtitlesMap[s.lang] ? path.basename(subtitlesMap[s.lang]) : s.lang });
      }
      rawResp = { mode: 'browser', ...browserResult };
    } else {
      // === API (Pro) mode ===
      const resp = await uploadToRumble(
        {
          accessToken: cfg.rumbleAccessToken,
          title: finalTitle,
          description: buildDescription(item),
          licenseType: cfg.rumbleLicenseType ?? 0,
          channelId: cfg.rumbleChannelId || undefined,
          videoPath,
          subtitles: Object.keys(subtitlesMap).length > 0 ? subtitlesMap : undefined,
          tags: buildTags(item),
        },
        async (pct) => {
          await db
            .update(uploads)
            .set({ progress: pct, updatedAt: new Date() })
            .where(eq(uploads.id, uploadRow.id));
        }
      );

      isSuccess = !!resp.success && !resp.error;
      rumbleUrl = resp.url || resp.iFrameUrl || null;
      rumbleVideoId = resp.video_id ?? null;
      embedUrl = resp.embed_url ?? resp.iFrameUrl ?? null;
      thumbnailUrl = resp.thumbnail_url ?? null;
      errorMessage = resp.error ?? resp.msg ?? null;
      rawResp = resp as Record<string, unknown>;

      if (isSuccess && rumbleUrl) {
        streamUrl = await extractStreamUrl(rumbleUrl);
      }
    }
  } catch (e) {
    isSuccess = false;
    errorMessage = (e as Error).message;
    rawResp = { error: errorMessage };
  }

  await db
    .update(uploads)
    .set({
      rumbleVideoId,
      rumbleUrl: rumbleUrl,
      rumbleEmbedUrl: embedUrl,
      rumbleStreamUrl: streamUrl,
      rumbleThumbnail: thumbnailUrl,
      rumbleResponse: rawResp,
      status: isSuccess ? 'processing' : 'error',
      progress: 100,
      errorMessage,
      subtitlesUploaded: finalUploadedSubs,
      updatedAt: new Date(),
    })
    .where(eq(uploads.id, uploadRow.id));

  if (isSuccess) {
    if (opts.markItemStatus !== false) {
      await db
        .update(feedItems)
        .set({ status: 'uploaded', updatedAt: new Date() })
        .where(eq(feedItems.id, feedItemId));
    }
    // Copy the same verified file to every enabled extra platform (Dailymotion, OK.ru, ...).
    let mirrorFailures = 0;
    if (!opts.variant) {
      try {
        const m = await mirrorToPlatforms({
          feedItemId,
          uploadId: uploadRow.id,
          videoPath,
          title: finalTitle,
          description: buildDescription(item),
          tags: buildTags(item),
          subtitles: subtitlesMap,
        });
        mirrorFailures = m.failed;
      } catch (e) {
        console.error(`[pipeline] platform mirroring failed for #${feedItemId}:`, (e as Error).message);
      }
    }
    // Generate burned-in subtitle variants while the source files still exist.
    if (!opts.variant && cfg.bulkHardSub && opts.skipCleanup !== true) {
      try {
        await uploadHardSubVariants(feedItemId, dl, item, finalTitle);
      } catch (e) {
        console.error(`[pipeline] hard-sub variants failed for #${feedItemId}:`, (e as Error).message);
      }
    }
    // Reclaim disk: the video now lives on Rumble, so drop the local torrent folder.
    // Keep it when a platform upload failed, so "Retry failed platforms" can resend it.
    if (mirrorFailures > 0) {
      console.log(`[pipeline] keeping local files for #${feedItemId}: ${mirrorFailures} platform upload(s) failed`);
    } else if (opts.skipCleanup !== true) {
      const removed = await removeDownloadDir(dl.infoHash || item.infoHash);
      if (removed) {
        await db
          .update(downloads)
          .set({ status: 'cleaned', videoPath: null, updatedAt: new Date() })
          .where(eq(downloads.id, dl.id));
        console.log(`[pipeline] cleaned up local files for feed item #${feedItemId}`);
      }
    }
  } else {
    if (opts.markItemStatus !== false) {
      await db
        .update(feedItems)
        .set({
          status: 'error',
          errorMessage: errorMessage || 'Upload failed',
          updatedAt: new Date(),
        })
        .where(eq(feedItems.id, feedItemId));
    }
    throw new Error(errorMessage || 'Rumble upload failed');
  }

  return { uploadId: uploadRow.id, rumbleUrl, streamUrl, resp: rawResp };
}

type SubTrack = { lang: string; path: string; codec?: string; title?: string };

/** A "signs/songs" or "forced" track only translates on-screen text, not dialogue. */
function isPartialTrack(t: SubTrack): boolean {
  const label = `${t.title || ''} ${path.basename(t.path)}`.toLowerCase();
  return /sign|song|forced|karaoke|\bs&s\b|op\/ed|commentary|lyrics/.test(label);
}

/**
 * Pick the best track for a language: prefer full dialogue over signs/forced
 * tracks, then the largest file (more lines = complete translation).
 */
async function pickBestTrack(tracks: SubTrack[], lang: string): Promise<SubTrack | null> {
  const candidates = tracks.filter((t) => t.lang === lang);
  const scored: { t: SubTrack; partial: boolean; size: number }[] = [];
  for (const t of candidates) {
    try {
      const st = await fs.stat(t.path);
      scored.push({ t, partial: isPartialTrack(t), size: st.size });
    } catch {
      /* file missing */
    }
  }
  scored.sort((a, b) => Number(a.partial) - Number(b.partial) || b.size - a.size);
  return scored[0]?.t || null;
}

/**
 * Burn ENGLISH subtitles into a separate video and upload it.
 * Hard subs are always English-only; other languages are never burned in.
 */
async function uploadHardSubVariants(
  feedItemId: number,
  dl: typeof downloads.$inferSelect,
  item: typeof feedItems.$inferSelect,
  baseTitle: string
) {
  void baseTitle;
  const allSubs = ((dl.subtitles || []) as SubTrack[]).map((t) => {
    let lang = normalizeLang(t.lang);
    if (lang === 'und' && t.title) lang = guessLangFromFilename(`${t.title}.srt`);
    return { ...t, lang };
  });
  const english = await pickBestTrack(allSubs, 'en');
  if (!english) {
    console.warn(
      `[pipeline] #${feedItemId} has no English subtitle track (found: ${
        Array.from(new Set(allSubs.map((s) => s.lang))).join(', ') || 'none'
      }); skipping hardsub — non-English hardsubs are never created`
    );
    return;
  }
  if (isPartialTrack(english)) {
    console.warn(`[pipeline] #${feedItemId} only has an English signs/songs track; skipping hardsub`);
    return;
  }

  const outDir = path.join(path.dirname(dl.videoPath || ''), '._hardsubs');
  console.log(
    `[pipeline] burning ENGLISH hardsub for #${feedItemId} using "${english.title || path.basename(english.path)}"...`
  );
  const burned = await burnSubtitles(dl.videoPath!, english.path, 'en', outDir);
  await processItemUpload(feedItemId, {
    videoPathOverride: burned.outPath,
    titleSuffix: '[English Hardsub]',
    variant: 'hard',
    hardLang: 'en',
    subtitlesOverride: {}, // subtitles are already burned in
    markItemStatus: false,
    skipCleanup: true,
  });
}

/**
 * Re-queue failed uploads: verify the local video still exists, clear the
 * error state, and upload again. Useful after fixing a Rumble/browser issue.
 */
export async function retryFailedUploads(limit = 50, feedItemId?: number): Promise<{ retried: number; errors: string[] }> {
  const failed = await db
    .select()
    .from(uploads)
    .where(
      feedItemId
        ? and(eq(uploads.status, 'error'), eq(uploads.feedItemId, feedItemId))
        : eq(uploads.status, 'error')
    )
    .orderBy(desc(uploads.id))
    .limit(limit);

  const seen = new Set<number>();
  const errors: string[] = [];
  let retried = 0;

  for (const u of failed) {
    if (!u.feedItemId || seen.has(u.feedItemId)) continue;
    seen.add(u.feedItemId);
    try {
      const dl = await db
        .select()
        .from(downloads)
        .where(eq(downloads.feedItemId, u.feedItemId))
        .orderBy(desc(downloads.id))
        .limit(1)
        .then((r) => r[0]);
      if (!dl?.videoPath) {
        errors.push(`Upload #${u.id}: local video is gone; feed item must be re-downloaded`);
        await db
          .update(feedItems)
          .set({ status: 'discovered', errorMessage: 'Retry skipped: local files missing', updatedAt: new Date() })
          .where(eq(feedItems.id, u.feedItemId));
        continue;
      }
      await fs.access(dl.videoPath);
      await db
        .update(uploads)
        .set({ status: 'pending', errorMessage: null, updatedAt: new Date() })
        .where(eq(uploads.id, u.id));
      await db
        .update(feedItems)
        .set({ status: 'downloaded', errorMessage: null, updatedAt: new Date() })
        .where(eq(feedItems.id, u.feedItemId));
      await processItemUpload(u.feedItemId);
      retried++;
    } catch (e) {
      errors.push(`Upload #${u.id}: ${(e as Error).message}`);
    }
  }
  return { retried, errors };
}

function buildDescription(item: {
  title: string;
  fansubGroup?: string | null;
  resolution?: string | null;
  link?: string | null;
}): string {
  const parts: string[] = [];
  parts.push(item.title);
  parts.push('');
  if (item.fansubGroup) parts.push(`Fansub: ${item.fansubGroup}`);
  if (item.resolution) parts.push(`Resolution: ${item.resolution}`);
  if (item.link) parts.push(`Source: ${item.link}`);
  parts.push('');
  parts.push('Uploaded automatically via Rumble Auto-Uploader.');
  return parts.join('\n');
}

function buildTags(item: { fansubGroup?: string | null; resolution?: string | null }): string[] {
  const tags = ['anime'];;
  if (item.fansubGroup) tags.push(item.fansubGroup);
  if (item.resolution) tags.push(item.resolution);
  return tags;
}

// Map common 3-letter codes to 2-letter ISO 639-1
const LANG_MAP: Record<string, string> = {
  eng: 'en',
  english: 'en',
  enm: 'en',
  jpn: 'ja',
  japanese: 'ja',
  jp: 'ja',
  spa: 'es',
  spanish: 'es',
  es: 'es',
  fre: 'fr',
  french: 'fr',
  fra: 'fr',
  deu: 'de',
  german: 'de',
  ger: 'de',
  por: 'pt',
  portuguese: 'pt',
  ita: 'it',
  italian: 'it',
  kor: 'ko',
  korean: 'ko',
  zho: 'zh',
  chi: 'zh',
  chinese: 'zh',
  chs: 'zh',
  cht: 'zh',
  rus: 'ru',
  russian: 'ru',
  ara: 'ar',
  arabic: 'ar',
  hin: 'hi',
  hindi: 'hi',
  tha: 'th',
  thai: 'th',
  vie: 'vi',
  vietnamese: 'vi',
  dut: 'nl',
  dutch: 'nl',
  nld: 'nl',
  pol: 'pl',
  polish: 'pl',
  tur: 'tr',
  turkish: 'tr',
  swe: 'sv',
  swedish: 'sv',
  dan: 'da',
  danish: 'da',
  nor: 'no',
  norwegian: 'no',
  fin: 'fi',
  finnish: 'fi',
  ukr: 'uk',
  ukrainian: 'uk',
  ces: 'cs',
  cze: 'cs',
  czech: 'cs',
  hun: 'hu',
  hungarian: 'hu',
  rum: 'ro',
  ron: 'ro',
  romanian: 'ro',
  ell: 'el',
  greek: 'el',
  grc: 'el',
  heb: 'he',
  hebrew: 'he',
  ind: 'id',
  indonesian: 'id',
  may: 'ms',
  msa: 'ms',
  malay: 'ms',
  bul: 'bg',
  bulgarian: 'bg',
  hrvatski: 'hr',
  hrv: 'hr',
  croatian: 'hr',
  srp: 'sr',
  serbian: 'sr',
  slv: 'sl',
  slovenian: 'sl',
  lav: 'lv',
  latvian: 'lv',
  lit: 'lt',
  lithuanian: 'lt',
  est: 'et',
  estonian: 'et',
  und: 'und',
  mis: 'und',
};

function normalizeLang(code: string): string {
  if (!code) return 'und';
  const c = code.toLowerCase().trim();
  if (LANG_MAP[c]) return LANG_MAP[c];
  if (c.length === 2) return c;
  // Extract 2-letter code if present
  const m = c.match(/\b([a-z]{2})\b/);
  if (m) return m[1];
  return 'und';
}

export function guessLangFromFilename(filename: string): string {
  const base = path.basename(filename, path.extname(filename)).toLowerCase();
  // Look for language tags like ".en", ".eng", ".english" in the name
  // Common patterns: "[Eng]" ".en.", "eng.", "english"
  const patterns = [
    /\b(english|eng|en)\b/i,
    /\b(japanese|jpn|jp|ja)\b/i,
    /\b(spanish|spa|es)\b/i,
    /\b(french|fre|fra|fr)\b/i,
    /\b(german|deu|ger|de)\b/i,
    /\b(portuguese|por|pt)\b/i,
    /\b(italian|ita|it)\b/i,
    /\b(korean|kor|ko)\b/i,
    /\b(chinese|zho|chi|zh|chs|cht)\b/i,
    /\b(russian|rus|ru)\b/i,
    /\b(arabic|ara|ar)\b/i,
  ];
  for (const p of patterns) {
    const m = base.match(p);
    if (m) return normalizeLang(m[1]);
  }
  // Also look for suffixes like "file.en.srt"
  const m = base.match(/\.([a-z]{2,3})$/);
  if (m) return normalizeLang(m[1]);
  return 'und';
}
