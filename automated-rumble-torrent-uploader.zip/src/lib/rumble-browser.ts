import { chromium, type Browser, type BrowserContext, type Page, type Cookie } from 'playwright';
import path from 'path';
import fs from 'fs/promises';
import { spawn } from 'child_process';
import { DATA_DIR, ensureDirs } from './storage';
import { extractStreamUrl, extractBestStreamUrlFromHtml } from './rumble';

const LAUNCH_ARGS = ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage'];

// Keep the browser in the project directory: the sandbox periodically clears
// ~/.cache/ms-playwright and the OS libraries along with it.
const BROWSERS_DIR = path.join(process.cwd(), '.playwright-browsers');
process.env.PLAYWRIGHT_BROWSERS_PATH = BROWSERS_DIR;

let installPromise: Promise<void> | null = null;

/** Install the Chromium binary AND its system libraries (self-healing after sandbox resets). */
function installChromium(withDeps: boolean): Promise<void> {
  if (!installPromise) {
    installPromise = (async () => {
      const cli = path.join(process.cwd(), 'node_modules', 'playwright', 'cli.js');
      const args = ['install', 'chromium-headless-shell'];
      if (withDeps) args.push('--with-deps');
      console.log(`[rumble-browser] Repairing Chromium install: playwright ${args.join(' ')}`);
      await new Promise<void>((resolve, reject) => {
        const proc = spawn(process.execPath, [cli, ...args], {
          stdio: 'inherit',
          env: { ...process.env, PLAYWRIGHT_BROWSERS_PATH: BROWSERS_DIR },
        });
        proc.on('error', reject);
        proc.on('close', (code) =>
          code === 0 ? resolve() : reject(new Error(`playwright install exited with code ${code}`))
        );
      });
    })().finally(() => {
      installPromise = null;
    });
  }
  return installPromise;
}

/**
 * Launch headless Chromium, repairing a missing binary or missing OS libraries
 * automatically (both happen when the sandbox cache is reset).
 */
function executablePath(): string {
  return path.join(
    BROWSERS_DIR,
    'chromium_headless_shell-1255',
    'chrome-headless-shell-linux64',
    'chrome-headless-shell'
  );
}

export async function launchBrowser(headless = true): Promise<Browser> {
  // Always pass the explicit binary path: Playwright otherwise resolves against
  // ~/.cache/ms-playwright, which the sandbox clears on every reset.
  const launch = () =>
    chromium.launch({ headless, args: LAUNCH_ARGS, executablePath: executablePath() });
  try {
    return await launch();
  } catch (e) {
    const msg = (e as Error).message || '';
    const missingBinary = /Executable doesn't exist|ENOENT|no such file/i.test(msg);
    const missingLibs = /error while loading shared libraries|libnspr4|libnss3|\.so.*cannot open/i.test(msg);
    if (!missingBinary && !missingLibs) throw e;
    await installChromium(true);
    return await launch();
  }
}

const SESSION_FILE = path.join(DATA_DIR, 'rumble_session.json');
const UPLOAD_URL = 'https://rumble.com/upload.php';
const LOGIN_URL = 'https://rumble.com/login.php';

// Human-ish viewport / UA
const VIEWPORT = { width: 1440, height: 900 };
const USER_AGENT =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36';

export type BrowserUploadOptions = {
  email?: string;
  password?: string;
  sessionCookies?: string;
  videoPath: string;
  title: string;
  description?: string;
  tags?: string[];
  /**
   * Rumble's upload page requires a primary category. Defaults to
   * "Entertainment" which is safe for anime. You can override per upload.
   */
  primaryCategory?: string;
  /** 2-letter language code -> absolute srt/vtt path */
  subtitles?: Record<string, string>;
  /** If true, keep the Chromium window open for debugging (needs display; only for local dev). */
  headless?: boolean;
  onProgress?: (stage: string, pct?: number) => void;
};

export function parseRawCookies(raw: string): Cookie[] {
  if (!raw || !raw.trim()) return [];
  const trimmed = raw.trim();

  // Try JSON first (from extensions like Cookie-Editor)
  if (trimmed.startsWith('[') || trimmed.startsWith('{')) {
    try {
      const parsed = JSON.parse(trimmed);
      const arr: any[] = Array.isArray(parsed) ? parsed : parsed.cookies || [parsed];
      const result: Cookie[] = [];
      for (const c of arr) {
        if (!c || (!c.name && !c.key) || c.value == null) continue;
        let domain = String(c.domain || '.rumble.com');
        if (!domain.includes('rumble.com')) domain = '.rumble.com';
        // Cookie-Editor / browser exports use expirationDate (seconds) and
        // sameSite values like "no_restriction" / "lax" / "unspecified".
        const rawExp = typeof c.expires === 'number' ? c.expires : typeof c.expirationDate === 'number' ? c.expirationDate : -1;
        const ss = String(c.sameSite ?? '').toLowerCase();
        const sameSite: 'Strict' | 'Lax' | 'None' =
          ss === 'strict' ? 'Strict' : ss === 'no_restriction' || ss === 'none' ? 'None' : 'Lax';
        result.push({
          name: String(c.name || c.key),
          value: String(c.value),
          domain,
          path: String(c.path || '/'),
          expires: rawExp > 0 ? Math.floor(rawExp) : -1,
          httpOnly: !!c.httpOnly,
          // SameSite=None requires Secure
          secure: sameSite === 'None' ? true : c.secure !== false,
          sameSite,
        });
      }
      if (result.length > 0) return result;
    } catch {
      // not JSON
    }
  }

  // Try Netscape cookies.txt format (tab-separated)
  if (trimmed.includes('\t')) {
    const lines = trimmed.split(/\r?\n/);
    const cookies: Cookie[] = [];
    for (const line of lines) {
      if (line.startsWith('#') || !line.trim()) continue;
      const parts = line.split('\t');
      if (parts.length >= 7) {
        let domain = parts[0];
        if (!domain.includes('rumble.com')) domain = '.rumble.com';
        cookies.push({
          domain,
          path: parts[2] || '/',
          secure: parts[3] === 'TRUE',
          expires: Number(parts[4]) || -1,
          name: parts[5],
          value: parts[6],
          httpOnly: false,
          sameSite: 'Lax',
        });
      }
    }
    if (cookies.length > 0) return cookies;
  }

  // Try key=value; format
  const cookies: Cookie[] = [];
  const pairs = trimmed.split(/;\s*/);
  for (const pair of pairs) {
    const eq = pair.indexOf('=');
    if (eq > 0) {
      const name = pair.slice(0, eq).trim();
      const value = pair.slice(eq + 1).trim();
      if (name && value && !['path', 'domain', 'expires', 'samesite'].includes(name.toLowerCase())) {
        cookies.push({
          name,
          value,
          domain: '.rumble.com',
          path: '/',
          expires: -1,
          httpOnly: false,
          secure: true,
          sameSite: 'Lax',
        });
      }
    }
  }
  return cookies;
}

export type BrowserUploadResult = {
  videoUrl: string;
  embedUrl?: string | null;
  streamUrl?: string | null;
  thumbnailUrl?: string | null;
  videoId?: string | null;
  subtitlesAttached: { lang: string; ok: boolean; error?: string }[];
};

type PersistedCookies = {
  cookies: Cookie[];
  savedAt: string;
};

async function saveCookies(context: BrowserContext) {
  await ensureDirs();
  const cookies = await context.cookies();
  const data: PersistedCookies = { cookies, savedAt: new Date().toISOString() };
  await fs.writeFile(SESSION_FILE, JSON.stringify(data, null, 2));
}

async function loadCookies(context: BrowserContext): Promise<boolean> {
  try {
    const raw = await fs.readFile(SESSION_FILE, 'utf-8');
    const data: PersistedCookies = JSON.parse(raw);
    if (!data.cookies || !Array.isArray(data.cookies)) return false;
    // Cookie expiry may have passed; filter them out
    const now = Math.floor(Date.now() / 1000);
    const valid = data.cookies.filter(
      (c) => !c.expires || c.expires === -1 || c.expires > now
    );
    await context.addCookies(valid);
    return true;
  } catch {
    return false;
  }
}

/**
 * Reliable login check: the upload page only stays on /upload.php for signed-in
 * users. Homepage avatar selectors are unreliable (they change per theme/layout).
 */
async function isLoggedIn(page: Page): Promise<boolean> {
  try {
    await page.goto(UPLOAD_URL, { waitUntil: 'domcontentloaded', timeout: 30_000 });
    await page.waitForTimeout(1500);
    const url = page.url();
    if (url.includes('/login') || url.includes('auth.rumble.com')) return false;
    return url.includes('/upload.php');
  } catch {
    return false;
  }
}

async function login(page: Page, email: string, password: string, onProgress?: (s: string) => void) {
  onProgress?.('Navigating to login page...');
  await page.goto(LOGIN_URL, { waitUntil: 'domcontentloaded' });

  // Dismiss any cookie consent popups
  try {
    const acceptBtn = await page.$('button:has-text("Accept"), button:has-text("I agree"), button[aria-label="Accept all"]');
    if (acceptBtn) await acceptBtn.click({ timeout: 2000 });
  } catch {
    /* ignore */
  }

  // Fill in email / password; Rumble's login form uses "email" and "password"
  // but naming varies; try both by placeholder / name / id.
  const emailSelectors = [
    'input[name="email"]',
    'input[type="email"]',
    'input[id*="email" i]',
    'input[placeholder*="email" i]',
  ];
  const pwdSelectors = [
    'input[name="password"]',
    'input[type="password"]',
    'input[id*="password" i]',
    'input[placeholder*="password" i]',
  ];

  let filled = false;
  for (const sel of emailSelectors) {
    const el = await page.$(sel);
    if (el) {
      await el.click();
      await el.fill(email);
      filled = true;
      break;
    }
  }
  if (!filled) throw new Error('Could not find email input on login page');

  let pwdFilled = false;
  for (const sel of pwdSelectors) {
    const el = await page.$(sel);
    if (el) {
      await el.click();
      await el.fill(password);
      pwdFilled = true;
      break;
    }
  }
  if (!pwdFilled) throw new Error('Could not find password input on login page');

  // Submit: click button with text "Sign in" / "Log in"
  onProgress?.('Submitting login...');
  const submitBtn = await page.$(
    'button[type="submit"], input[type="submit"], button:has-text("Log in"), button:has-text("Sign in"), button:has-text("Login")'
  );
  if (submitBtn) {
    await Promise.all([
      page.waitForNavigation({ waitUntil: 'domcontentloaded' }).catch(() => {}),
      submitBtn.click(),
    ]);
  } else {
    await page.keyboard.press('Enter');
    await page.waitForNavigation({ waitUntil: 'domcontentloaded' }).catch(() => {});
  }

  // Wait for a bit; check for 2FA / captcha
  await page.waitForTimeout(2000);

  // If we're still on login page, check for error message
  const errorBox = await page.$('.error-message, .alert-danger, [class*="error"], .form-error');
  if (errorBox) {
    const text = (await errorBox.textContent()) || '';
    if (text.trim()) throw new Error(`Login error: ${text.trim()}`);
  }

  // Check for 2FA / verification code prompt
  const twoFA = await page.$('input[name*="code" i], input[placeholder*="code" i], input[autocomplete*="otp" i]');
  if (twoFA) {
    throw new Error(
      'Two-factor authentication / email code is required. Please log in once manually via a headed browser and save the session file at ' +
        SESSION_FILE
    );
  }
}

/**
 * Rumble's upload page can be temperamental. Try to locate the primary video
 * file input on the upload page. It's usually an <input type="file"> inside the
 * upload area. We also set a listener for the upload progress if possible.
 */
/** Rumble's floating support-chat widget overlays the submit buttons; remove it. */
async function removeOverlays(page: Page) {
  await page
    .evaluate(() => {
      document
        .querySelectorAll('[id^="groove-container"], #groove-iframe-element, iframe[title*="support" i], .cookie-banner, [id*="onetrust"]')
        .forEach((el) => el.remove());
    })
    .catch(() => {});
}

/** Click via the DOM so overlays/iframes can't intercept pointer events. */
async function hardClick(page: Page, selector: string) {
  await removeOverlays(page);
  await page.waitForSelector(selector, { state: 'visible', timeout: 60_000 });
  await page.locator(selector).first().scrollIntoViewIfNeeded().catch(() => {});
  try {
    await page.locator(selector).first().click({ timeout: 5000 });
  } catch {
    await page.locator(selector).first().dispatchEvent('click');
  }
}

async function performBrowserUpload(
  opts: BrowserUploadOptions
): Promise<BrowserUploadResult> {
  const {
    email,
    password,
    videoPath,
    title,
    description,
    tags,
    primaryCategory = 'Entertainment',
    subtitles = {},
    headless = true,
    onProgress,
  } = opts;

  onProgress?.('Launching browser...');
  const browser = await launchBrowser(headless);
  const context = await browser.newContext({
    viewport: VIEWPORT,
    userAgent: USER_AGENT,
    acceptDownloads: true,
  });
  const page = await context.newPage();
  page.setDefaultTimeout(60_000);

  const subtitlesAttached: BrowserUploadResult['subtitlesAttached'] = [];

  try {
    // ---------- 1. Authenticate ----------
    let loggedIn = false;
    if (opts.sessionCookies) {
      const parsed = parseRawCookies(opts.sessionCookies);
      if (parsed.length > 0) {
        await context.addCookies(parsed);
        loggedIn = await isLoggedIn(page);
        if (loggedIn) onProgress?.('Logged in using saved session cookies.');
      }
    }
    if (!loggedIn) {
      const haveCookies = await loadCookies(context);
      if (haveCookies) {
        onProgress?.('Trying session saved on disk...');
        loggedIn = await isLoggedIn(page);
      }
    }
    if (!loggedIn) {
      if (email && password) {
        onProgress?.('Logging in with email/password...');
        await login(page, email, password, onProgress);
        loggedIn = await isLoggedIn(page);
      }
    }
    if (!loggedIn) {
      throw new Error(
        'Not logged in to Rumble. Your saved session cookies may have expired — export fresh cookies from your browser and paste them in Settings.'
      );
    }
    await saveCookies(context);

    // isLoggedIn() already navigated to the upload page.
    if (!page.url().includes('/upload.php')) {
      await page.goto(UPLOAD_URL, { waitUntil: 'domcontentloaded' });
    }
    await page.waitForSelector('#Filedata', { state: 'attached', timeout: 60_000 });

    // ---------- 2. Select the video file (starts the chunked upload immediately) ----------
    onProgress?.('Selecting video file...', 1);
    await page.setInputFiles('#Filedata', videoPath);

    // ---------- 3. Fill metadata while the file uploads ----------
    onProgress?.('Filling title, description, tags...', 2);
    await page.waitForSelector('#title', { state: 'visible', timeout: 60_000 });
    await page.fill('#title', title.slice(0, 100));
    if (description) await page.fill('#description', description.slice(0, 5000));
    if (tags && tags.length > 0) await page.fill('#tags', tags.join(', ').slice(0, 500));

    // Primary category is a typeahead widget, not a <select>.
    try {
      const catInput = page.locator('input[name="primary-category"]');
      await catInput.click();
      await catInput.fill(primaryCategory);
      await page.waitForTimeout(500);
      const option = page
        .locator(`.select-option[data-label="${primaryCategory}" i]`)
        .first();
      if ((await option.count()) > 0) {
        await option.click();
      } else {
        // Fall back to the first visible option matching the text.
        const fuzzy = page.locator('.select-option', { hasText: primaryCategory }).first();
        if ((await fuzzy.count()) > 0) await fuzzy.click();
        else console.warn(`[rumble-browser] category "${primaryCategory}" not found; leaving blank`);
      }
      await page.waitForTimeout(300);
    } catch (e) {
      console.warn('[rumble-browser] Could not set category:', (e as Error).message);
    }

    // Public visibility
    try {
      const pub = page.locator('#visibility_public');
      if ((await pub.count()) > 0 && !(await pub.isChecked())) await pub.check({ force: true });
    } catch {
      /* ignore */
    }

    // ---------- 4. Wait for the file upload to reach 100% ----------
    onProgress?.('Uploading video file to Rumble...', 5);
    const fileSize = (await fs.stat(videoPath)).size;
    const maxWaitMs = Math.max(20 * 60_000, (fileSize / (0.5 * 1024 * 1024)) * 1000); // >= 20 min, or 0.5 MB/s
    const started = Date.now();
    let lastPct = -1;
    for (;;) {
      const text = await page
        .locator('.top_percent')
        .first()
        .textContent()
        .catch(() => '');
      const pct = parseInt((text || '').replace(/[^0-9]/g, ''), 10);
      if (!isNaN(pct) && pct !== lastPct) {
        lastPct = pct;
        onProgress?.(`Uploading video file to Rumble... ${pct}%`, Math.min(90, 5 + Math.floor(pct * 0.85)));
      }
      // Upload errors surface in #error_files / #error_form
      const err = await page
        .locator('#error_files, #error_form, #error_unknown')
        .allTextContents()
        .then((arr) => arr.map((s) => s.trim()).filter(Boolean).join(' | '))
        .catch(() => '');
      if (err) throw new Error(`Rumble rejected the upload: ${err}`);
      if (pct >= 100) break;
      if (Date.now() - started > maxWaitMs) {
        throw new Error(`Timed out waiting for the file upload (stuck at ${lastPct}%)`);
      }
      await page.waitForTimeout(2000);
    }
    onProgress?.('File uploaded (100%). Submitting step 1...', 91);

    // ---------- 5. Step 1 -> click "Upload" ----------
    await hardClick(page, '#submitForm');
    await page.waitForSelector('#form2', { state: 'visible', timeout: 60_000 });

    // Surface validation errors (e.g. missing category)
    const step1Err = await page
      .locator('#form1 .error, .error__required')
      .allTextContents()
      .then((arr) => arr.map((s) => s.trim()).filter(Boolean))
      .catch(() => [] as string[]);
    if (step1Err.length > 0 && !(await page.locator('#form2').isVisible())) {
      throw new Error(`Rumble form errors: ${step1Err.join(' | ')}`);
    }

    // ---------- 6. Step 2 -> license + rights + submit ----------
    onProgress?.('Accepting rights/terms and submitting...', 93);
    // License: "Personal Use" is the first greenLink (crcval=0); it's selected by default,
    // but click it explicitly to be safe.
    try {
      const personal = page.locator('a.greenLink[crcval="0"]').first();
      if ((await personal.count()) > 0) await personal.click();
    } catch {
      /* ignore */
    }
    // The checkbox inputs are hidden; the visible <label for=...> is what gets clicked.
    for (const id of ['crights', 'cterms']) {
      const checked = await page.locator(`#${id}`).isChecked().catch(() => false);
      if (checked) continue;
      const label = page.locator(`label[for="${id}"]`).first();
      if ((await label.count()) > 0) {
        await label.scrollIntoViewIfNeeded().catch(() => {});
        await label.click({ timeout: 5000 }).catch(async () => {
          await label.dispatchEvent('click');
        });
      }
      // Fall back to setting it programmatically if the label click didn't take.
      const nowChecked = await page.locator(`#${id}`).isChecked().catch(() => false);
      if (!nowChecked) {
        await page.evaluate((cid) => {
          const el = document.getElementById(cid) as HTMLInputElement | null;
          if (el) {
            el.checked = true;
            el.dispatchEvent(new Event('change', { bubbles: true }));
            el.dispatchEvent(new Event('click', { bubbles: true }));
          }
        }, id);
      }
    }
    await page.waitForTimeout(500);
    await hardClick(page, '#submitForm2');

    // ---------- 7. Wait for the success panel with the video URL ----------
    onProgress?.('Waiting for Rumble to confirm the video...', 95);
    let videoUrl = '';
    const deadline = Date.now() + 5 * 60_000;
    while (Date.now() < deadline) {
      const direct = await page.locator('#direct').inputValue().catch(() => '');
      if (direct && /rumble\.com\//.test(direct)) {
        videoUrl = direct.trim();
        break;
      }
      const errText = await page
        .locator('#error_rights, #error_terms, #error_form_2, #error_files_2, #error_unknown_2, #error_form, #error_unknown')
        .allTextContents()
        .then((arr) => arr.map((s) => s.trim()).filter(Boolean).join(' | '))
        .catch(() => '');
      if (errText) throw new Error(`Rumble returned an error on submit: ${errText}`);
      // Fallback: a visible link to the new video
      const link = await page
        .locator('a[href*="rumble.com/v"]')
        .first()
        .getAttribute('href')
        .catch(() => null);
      if (link) {
        videoUrl = link.startsWith('/') ? `https://rumble.com${link}` : link;
        break;
      }
      await page.waitForTimeout(2000);
    }
    if (!videoUrl) {
      throw new Error('Submitted, but Rumble did not return a video URL within 5 minutes. Check your Rumble account — the video may still be processing.');
    }
    videoUrl = videoUrl.split('?')[0];
    const idMatch = videoUrl.match(/rumble\.com\/(v[a-z0-9]+)/i);
    const videoId = idMatch ? idMatch[1] : null;
    const embedRaw = await page.locator('#embed').inputValue().catch(() => '');
    const embedMatch = embedRaw.match(/src="([^"]+)"/);
    const embedUrl = embedMatch ? embedMatch[1] : null;

    onProgress?.(`Video live at ${videoUrl}`, 97);

    // ---------- 8. Subtitles ----------
    const subEntries = Object.entries(subtitles);
    if (subEntries.length > 0) {
      onProgress?.(`Attaching ${subEntries.length} subtitle track(s)...`, 98);
      const subResult = await attachSubtitles(page, videoId, videoUrl, subtitles);
      subtitlesAttached.push(...subResult);
    }

    await saveCookies(context);

    onProgress?.('Extracting HLS stream URL (best rendition)...', 99);
    const pageHtml = await page.content();
    const streamUrl =
      (await extractBestStreamUrlFromHtml(pageHtml, videoUrl)) ||
      (await extractStreamUrl(videoUrl));
    const thumbnailUrl = await fetchOgImage(videoUrl);

    await browser.close();
    return { videoUrl, embedUrl, streamUrl, thumbnailUrl, videoId, subtitlesAttached };
  } catch (e) {
    try {
      await ensureDirs();
      await page.screenshot({ path: path.join(DATA_DIR, 'rumble_failure.png'), fullPage: true });
      await fs.writeFile(path.join(DATA_DIR, 'rumble_failure.html'), await page.content());
    } catch {
      /* ignore */
    }
    await browser.close();
    throw e;
  }
}

async function fetchOgImage(videoUrl: string): Promise<string | null> {
  try {
    const res = await fetch(videoUrl, { headers: { 'User-Agent': USER_AGENT } });
    if (!res.ok) return null;
    const html = await res.text();
    const m = html.match(/<meta[^>]+property="og:image"[^>]+content="([^"]+)"/i);
    return m ? m[1] : null;
  } catch {
    return null;
  }
}

/**
 * Rumble's caption manager lives on the video's edit page. The markup is not
 * fully known, so this is best-effort: it tries common patterns and records
 * per-language success/failure without failing the whole upload.
 */
async function attachSubtitles(
  page: Page,
  videoId: string | null,
  videoUrl: string,
  subtitles: Record<string, string>
): Promise<{ lang: string; ok: boolean; error?: string }[]> {
  const results: { lang: string; ok: boolean; error?: string }[] = [];
  // Try to find the edit page for this video.
  const candidates = [
    videoId ? `https://rumble.com/account/content?type=video&v=${videoId}` : null,
    videoId ? `https://rumble.com/edit-video.php?video=${videoId}` : null,
    'https://rumble.com/account/content?type=video',
  ].filter(Boolean) as string[];

  let editReady = false;
  for (const url of candidates) {
    try {
      await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60_000 });
      await page.waitForTimeout(1500);
      // Open the newest video's edit view if we're on a list page.
      const editLink = page.locator(`a[href*="edit"][href*="${videoId ?? ''}"], a:has-text("Edit")`).first();
      if ((await editLink.count()) > 0) {
        await editLink.click().catch(() => {});
        await page.waitForTimeout(1500);
      }
      const tab = page.locator(
        'a:has-text("Captions"), button:has-text("Captions"), a:has-text("Closed Captions"), [role="tab"]:has-text("Caption"), a:has-text("Subtitles")'
      ).first();
      if ((await tab.count()) > 0) {
        await tab.click().catch(() => {});
        await page.waitForTimeout(1000);
        editReady = true;
        break;
      }
    } catch {
      /* try next */
    }
  }

  for (const [lang, srtPath] of Object.entries(subtitles)) {
    if (!editReady) {
      results.push({ lang, ok: false, error: 'Caption manager not found on edit page' });
      continue;
    }
    try {
      // Language selector (select or text input)
      const sel = page.locator('select[name*="lang" i], select[id*="lang" i]').first();
      if ((await sel.count()) > 0) {
        await sel.selectOption({ value: lang }).catch(async () => {
          await sel.selectOption({ label: new RegExp(`^${lang}`, 'i') as unknown as string }).catch(() => {});
        });
      }
      const fileInput = page
        .locator('input[type="file"][accept*=".srt"], input[type="file"][accept*=".vtt"], input[type="file"]:not(#Filedata):not(#customThumb)')
        .first();
      if ((await fileInput.count()) === 0) throw new Error('No caption file input found');
      await fileInput.setInputFiles(srtPath);
      await page.waitForTimeout(800);
      const save = page
        .locator('button:has-text("Upload"), button:has-text("Save"), input[type="submit"], input[type="button"][value*="Upload" i]')
        .first();
      if ((await save.count()) > 0) await save.click({ timeout: 5000 }).catch(() => {});
      await page.waitForTimeout(1500);
      results.push({ lang, ok: true });
    } catch (e) {
      results.push({ lang, ok: false, error: (e as Error).message });
    }
  }
  console.log(`[rumble-browser] subtitles for ${videoUrl}:`, JSON.stringify(results));
  return results;
}

export async function uploadToRumbleViaBrowser(
  opts: BrowserUploadOptions
): Promise<BrowserUploadResult> {
  return performBrowserUpload(opts);
}

export async function testRumbleLogin(opts: {
  email?: string;
  password?: string;
  cookies?: string;
}): Promise<{ ok: boolean; message: string; username?: string }> {
  let browser;
  try {
    browser = await launchBrowser(true);
    const context = await browser.newContext({
      viewport: VIEWPORT,
      userAgent: USER_AGENT,
    });
    const page = await context.newPage();

    let hasCookies = false;
    if (opts.cookies && opts.cookies.trim()) {
      const parsed = parseRawCookies(opts.cookies);
      if (parsed.length > 0) {
        await context.addCookies(parsed);
        hasCookies = true;
      }
    } else {
      hasCookies = await loadCookies(context);
    }

    if (hasCookies) {
      await page.goto('https://rumble.com/upload.php', {
        waitUntil: 'domcontentloaded',
        timeout: 25_000,
      });
      const currentUrl = page.url();

      if (currentUrl.includes('/upload.php')) {
        const username = await page.evaluate(() => {
          const el = document.querySelector('[class*="username"], .header-menu-name, [data-user]');
          return el ? (el.textContent || '').trim() : null;
        });
        await saveCookies(context);
        await browser.close();
        return {
          ok: true,
          message: `Connected to Rumble successfully!${username ? ` Logged in as: ${username}` : ''}`,
          username: username || undefined,
        };
      }
    }

    // Try logging in with email/password if supplied
    if (opts.email && opts.password) {
      try {
        await login(page, opts.email, opts.password);
        await page.goto('https://rumble.com/upload.php', {
          waitUntil: 'domcontentloaded',
          timeout: 25_000,
        });
        if (page.url().includes('/upload.php')) {
          await saveCookies(context);
          await browser.close();
          return { ok: true, message: 'Logged in successfully via email/password!' };
        }
      } catch (loginErr) {
        const msg = (loginErr as Error).message || '';
        await browser.close();
        if (
          msg.includes('Cloudflare') ||
          msg.includes('Just a moment') ||
          msg.includes('Turnstile') ||
          msg.includes('captcha')
        ) {
          return {
            ok: false,
            message:
              'Cloudflare security check blocked the headless login page. Solution: Log into Rumble in your regular browser, copy/export your session cookies (via Cookie-Editor extension), and paste them into the "Session Cookies" box.',
          };
        }
        return { ok: false, message: `Login failed: ${msg}` };
      }
    }

    await browser.close();
    return {
      ok: false,
      message:
        'Not authenticated. Paste your Rumble session cookies (from your browser) into the cookies box, or verify your email and password.',
    };
  } catch (e) {
    if (browser) await browser.close().catch(() => {});
    return { ok: false, message: `Test failed: ${(e as Error).message}` };
  }
}
