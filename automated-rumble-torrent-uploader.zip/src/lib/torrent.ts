import WebTorrent, { type Torrent } from 'webtorrent';
import path from 'path';
import fs from 'fs/promises';
import { ensureDirs, getDownloadDir } from './storage';
import { db } from '@/db';
import { downloads, feedItems } from '@/db/schema';
import { eq } from 'drizzle-orm';

// Global client
let client: WebTorrent | null = null;

// Public UDP/HTTP trackers that work in Node (browser-only wss:// trackers are useless here).
const EXTRA_TRACKERS = [
  'udp://tracker.opentrackr.org:1337/announce',
  'udp://open.stealth.si:80/announce',
  'udp://tracker.torrent.eu.org:451/announce',
  'udp://exodus.desync.com:6969/announce',
  'udp://open.demonii.com:1337/announce',
  'udp://tracker.moeking.me:6969/announce',
  'udp://explodie.org:6969/announce',
  'udp://tracker.dler.org:6969/announce',
  'udp://tracker.openbittorrent.com:6969/announce',
  'http://tracker.openbittorrent.com:80/announce',
  'udp://opentracker.i2p.rocks:6969/announce',
];

export function getClient(): WebTorrent {
  if (!client) {
    client = new WebTorrent({
      maxConns: 300, // default is 55 — far too few for a swarm
      dht: true, // find peers without trackers
      lsd: true, // local network discovery
      utp: true, // uTP congestion-friendly transport
      tracker: true,
    });
    client.on('error', (err: unknown) => {
      console.error('[torrent] client error:', err instanceof Error ? err.message : err);
    });
  }
  return client;
}

/** Fetch the .torrent file from Nyaa: it includes the full tracker list for the swarm. */
async function fetchTorrentFile(url: string): Promise<Buffer | null> {
  try {
    const res = await fetch(url, {
      headers: { 'User-Agent': 'RumbleAutoUploader/1.0' },
      signal: AbortSignal.timeout(30_000),
    });
    if (!res.ok) return null;
    return Buffer.from(await res.arrayBuffer());
  } catch (e) {
    console.warn('[torrent] could not fetch .torrent file:', (e as Error).message);
    return null;
  }
}

export async function shutdownClient() {
  return new Promise<void>((resolve) => {
    if (!client) return resolve();
    client.destroy((err?: Error) => {
      client = null;
      if (err) console.error('Error destroying webtorrent client:', err);
      resolve();
    });
  });
}

export type TorrentFile = {
  name: string;
  path: string;
  size: number;
};

export type DownloadHandle = {
  feedItemId: number;
  infoHash: string;
  downloadPath: string;
  files: TorrentFile[];
  videoFiles: TorrentFile[];
  subtitleFiles: TorrentFile[];
  name: string;
};

export async function startTorrentDownload(
  feedItemId: number,
  magnetUri: string,
  torrentUrl?: string
): Promise<DownloadHandle> {
  await ensureDirs();
  const c = getClient();

  const feedItem = await db
    .select()
    .from(feedItems)
    .where(eq(feedItems.id, feedItemId))
    .then((rows) => rows[0]);
  if (!feedItem) throw new Error(`Feed item ${feedItemId} not found`);

  type DbFile = { path: string; size: number; type: 'video' | 'subtitle' | 'other' };
  // If already downloaded we can reuse
  if (feedItem.status === 'downloaded' || feedItem.status === 'uploaded' || feedItem.status === 'processing') {
    const dl = await db
      .select()
      .from(downloads)
      .where(eq(downloads.feedItemId, feedItemId))
      .limit(1)
      .then((r) => r[0]);
    if (dl && dl.files) {
      const dbFiles = dl.files as DbFile[];
      const files: TorrentFile[] = dbFiles.map((f) => ({
        name: f.path.split(/[\\/]/).pop() || f.path,
        path: f.path,
        size: f.size,
      }));
      return {
        feedItemId,
        infoHash: dl.infoHash || feedItem.infoHash || '',
        downloadPath: dl.downloadPath || '',
        files,
        videoFiles: files.filter((f) => isVideoFile(f.name)),
        subtitleFiles: files.filter((f) => isSubtitleFile(f.name)),
        name: dl.name,
      };
    }
  }

  const uri = magnetUri || torrentUrl;
  if (!uri) throw new Error('No magnet or torrent URL available');

  const infoHash = feedItem.infoHash || `pending_${feedItemId}`;
  const downloadPath = getDownloadDir(infoHash);
  await fs.mkdir(downloadPath, { recursive: true });

  await db
    .update(feedItems)
    .set({ status: 'downloading', updatedAt: new Date() })
    .where(eq(feedItems.id, feedItemId));

  const [downloadRow] = await db
    .insert(downloads)
    .values({
      feedItemId,
      infoHash: feedItem.infoHash || null,
      name: feedItem.title,
      downloadPath,
      status: 'downloading',
      totalSize: 0,
      downloaded: 0,
      progress: 0,
      files: [],
      subtitles: [],
      videoPath: null,
    })
    .returning();

  // Prefer the Nyaa .torrent file (has the real swarm tracker list); fall back to magnet.
  const torrentBuffer = torrentUrl ? await fetchTorrentFile(torrentUrl) : null;
  const input: string | Buffer = torrentBuffer ?? uri;
  const extraAnnounce = EXTRA_TRACKERS;

  return new Promise<DownloadHandle>((resolve, reject) => {
    const torrent: Torrent = c.add(
      input,
      {
        path: downloadPath,
        announce: extraAnnounce,
        maxWebConns: 16,
      },
      (t: Torrent) => {
        // Torrent metadata available
        console.log(`[torrent] metadata received: ${t.name} (${t.infoHash})`);
        if (!feedItem.infoHash && t.infoHash) {
          db.update(feedItems)
            .set({ infoHash: t.infoHash })
            .where(eq(feedItems.id, feedItemId))
            .catch(() => {});
          db.update(downloads)
            .set({ infoHash: t.infoHash })
            .where(eq(downloads.id, downloadRow.id))
            .catch(() => {});
        }
      }
    );

    torrent.on('done', async () => {
      try {
        const files: TorrentFile[] = torrent.files.map((f) => {
          const filePath = path.join(downloadPath, f.path);
          return { name: f.name, path: filePath, size: f.length };
        });

        const videoFiles = files.filter((f) => isVideoFile(f.name));
        const subtitleFiles = files.filter((f) => isSubtitleFile(f.name));
        const otherFiles = files.filter(
          (f) => !isVideoFile(f.name) && !isSubtitleFile(f.name)
        );

        const primaryVideo = videoFiles.sort((a, b) => b.size - a.size)[0];

        const dbFiles = [
          ...videoFiles.map((f) => ({ path: f.path, size: f.size, type: 'video' as const })),
          ...subtitleFiles.map((f) => ({
            path: f.path,
            size: f.size,
            type: 'subtitle' as const,
          })),
          ...otherFiles.map((f) => ({
            path: f.path,
            size: f.size,
            type: 'other' as const,
          })),
        ];

        await db
          .update(downloads)
          .set({
            infoHash: torrent.infoHash,
            name: torrent.name,
            totalSize: torrent.length,
            downloaded: torrent.downloaded,
            progress: 100,
            status: 'done',
            files: dbFiles,
            videoPath: primaryVideo?.path || null,
            updatedAt: new Date(),
          })
          .where(eq(downloads.id, downloadRow.id));

        await db
          .update(feedItems)
          .set({ status: 'downloaded', updatedAt: new Date() })
          .where(eq(feedItems.id, feedItemId));

        resolve({
          feedItemId,
          infoHash: torrent.infoHash,
          downloadPath,
          files,
          videoFiles,
          subtitleFiles,
          name: torrent.name,
        });
      } catch (e) {
        reject(e);
      }
    });

    torrent.on('error', async (err: string | Error) => {
      const msg = typeof err === 'string' ? err : err.message || String(err);
      console.error(`[torrent] error: ${msg}`);
      await db
        .update(feedItems)
        .set({ status: 'error', errorMessage: msg, updatedAt: new Date() })
        .where(eq(feedItems.id, feedItemId));
      await db
        .update(downloads)
        .set({ status: 'error', updatedAt: new Date() })
        .where(eq(downloads.id, downloadRow.id));
      reject(new Error(msg));
    });

    // Save progress at most every 3 seconds (time-based, not modulo-based).
    let lastSave = 0;
    let lastLog = 0;
    let lastBytes = 0;
    let lastTick = Date.now();
    torrent.on('download', () => {
      const now = Date.now();
      if (now - lastSave < 3000) return;
      lastSave = now;
      const progress = Math.floor(torrent.progress * 100);
      const seconds = Math.max(0.001, (now - lastTick) / 1000);
      const speedMBs = (torrent.downloaded - lastBytes) / seconds / 1024 / 1024;
      lastBytes = torrent.downloaded;
      lastTick = now;
      db.update(downloads)
        .set({ downloaded: torrent.downloaded, progress, updatedAt: new Date() })
        .where(eq(downloads.id, downloadRow.id))
        .catch(() => {});
      if (now - lastLog > 30_000) {
        lastLog = now;
        console.log(
          `[torrent] ${torrent.name?.slice(0, 50)} ${progress}% @ ${speedMBs.toFixed(2)} MB/s, peers ${torrent.numPeers}`
        );
      }
    });
  });
}

export function isVideoFile(name: string): boolean {
  const ext = path.extname(name).toLowerCase();
  return ['.mkv', '.mp4', '.avi', '.mov', '.wmv', '.flv', '.webm', '.m4v', '.ts'].includes(ext);
}

export function isSubtitleFile(name: string): boolean {
  const ext = path.extname(name).toLowerCase();
  return ['.srt', '.ass', '.ssa', '.vtt', '.sub', '.idx', '.ttxt'].includes(ext);
}
