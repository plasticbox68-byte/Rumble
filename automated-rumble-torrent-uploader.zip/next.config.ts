import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  serverExternalPackages: [
    'webtorrent',
    'bittorrent-protocol',
    'utp-native',
    'ffmpeg-static',
    'ffprobe-static',
    'fluent-ffmpeg',
    'playwright',
    'playwright-core',
  ],
  turbopack: {},
  // Keep the build's file tracer out of the multi-GB torrent/browser folders,
  // otherwise `next build` runs out of memory scanning them.
  outputFileTracingExcludes: {
    '*': ['./data/**', './.playwright-browsers/**'],
  },
};

export default nextConfig;
